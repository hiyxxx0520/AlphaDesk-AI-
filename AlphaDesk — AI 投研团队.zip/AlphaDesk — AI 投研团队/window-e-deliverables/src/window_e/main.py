import asyncio

from src.feishu.bridge import start_listener
from src.window_e.orchestrator import handle_user_message


def main() -> None:
    asyncio.run(start_listener(handle_user_message))


if __name__ == "__main__":
    main()

