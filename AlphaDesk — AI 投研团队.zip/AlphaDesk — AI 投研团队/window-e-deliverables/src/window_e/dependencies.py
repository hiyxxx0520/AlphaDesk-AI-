import importlib.util
import inspect
import sys
from functools import lru_cache
from pathlib import Path
from typing import Any, Callable

from src.agents.types import AgentResponse

WINDOW_E_ROOT = Path(__file__).resolve().parents[2]
WORKSPACE_ROOT = WINDOW_E_ROOT.parent
WINDOW_A_ROOT = WORKSPACE_ROOT / "window-a-deliverables"
WINDOW_B_ROOT = WORKSPACE_ROOT / "window-b-deliverables"


def _load_module(module_name: str, file_path: Path) -> Any | None:
    if not file_path.exists():
        return None

    spec = importlib.util.spec_from_file_location(module_name, file_path)
    if spec is None or spec.loader is None:
        return None

    module = importlib.util.module_from_spec(spec)
    sys.modules[module_name] = module
    spec.loader.exec_module(module)
    return module


def get_dependency_status() -> dict[str, bool]:
    return {
        "window_a": WINDOW_A_ROOT.exists(),
        "window_b_sender": (WINDOW_B_ROOT / "src/feishu/sender.py").exists(),
        "window_b_listener": (WINDOW_B_ROOT / "src/feishu/listener.py").exists(),
    }


def window_b_available() -> bool:
    status = get_dependency_status()
    return status["window_b_sender"] and status["window_b_listener"]


@lru_cache(maxsize=1)
def get_window_b_sender() -> Callable[..., Any] | None:
    module = _load_module("window_b_sender", WINDOW_B_ROOT / "src/feishu/sender.py")
    if module is None:
        return None
    return getattr(module, "send_to_group", None)


@lru_cache(maxsize=1)
def get_window_b_listener() -> Callable[..., Any] | None:
    module = _load_module("window_b_listener", WINDOW_B_ROOT / "src/feishu/listener.py")
    if module is None:
        return None
    return getattr(module, "start_listener", None)


@lru_cache(maxsize=1)
def get_window_a_response_provider() -> Callable[[str], Any] | None:
    candidates = [
        WINDOW_A_ROOT / "src/orchestrator.py",
        WINDOW_A_ROOT / "src/main.py",
        WINDOW_A_ROOT / "src/demo.py",
    ]
    attribute_names = [
        "get_agent_responses",
        "generate_responses",
        "run_orchestrator",
        "handle_user_message",
    ]

    for index, file_path in enumerate(candidates):
        module = _load_module(f"window_a_candidate_{index}", file_path)
        if module is None:
            continue
        for attribute_name in attribute_names:
            provider = getattr(module, attribute_name, None)
            if callable(provider):
                return provider

    return None


async def get_window_a_responses(user_message: str) -> list[AgentResponse] | None:
    provider = get_window_a_response_provider()
    if provider is None:
        return None

    responses = provider(user_message)
    if inspect.isawaitable(responses):
        responses = await responses

    if not responses:
        return None

    return responses

