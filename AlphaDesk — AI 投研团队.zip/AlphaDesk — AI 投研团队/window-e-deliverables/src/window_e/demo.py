from src.agents.types import AgentResponse


def _get_demo_responses(user_message: str) -> list[AgentResponse]:
    topic = user_message.strip() or "市场动态"

    return [
        {
            "role": "macro_analyst",
            "content": f"宏观面观察显示，当前与“{topic}”相关的外部冲击仍在发酵，需要先确认流动性与政策预期。",
            "tags": ["ALERT"],
        },
        {
            "role": "sector_analyst",
            "content": f"行业层面建议把“{topic}”拆成受益链条和承压链条分别跟踪，优先看交易量与盈利修正。",
            "tags": ["ACTION"],
        },
        {
            "role": "risk_manager",
            "content": "短期风险主要来自情绪定价过快、信息不完整和仓位拥挤，结论不应直接放大为重仓信号。",
            "tags": ["RISK"],
        },
        {
            "role": "chief_strategist",
            "content": "综合判断先给出演示版结论：保持观察、分步验证、等待更高置信度的确认信号。",
            "tags": ["ACTION"],
        },
    ]

