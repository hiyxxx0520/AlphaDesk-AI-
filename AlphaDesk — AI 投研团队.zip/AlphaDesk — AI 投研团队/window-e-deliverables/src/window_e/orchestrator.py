from src.agents.types import AgentResponse
from src.feishu.bridge import send_to_group
from src.window_e.demo import _get_demo_responses
from src.window_e.dependencies import get_window_a_responses


def _format_message(response: AgentResponse) -> str:
    if not response["tags"]:
        return response["content"]

    prefix = " ".join(f"[{tag}]" for tag in response["tags"])
    return f"{prefix} {response['content']}"


async def collect_responses(user_message: str) -> list[AgentResponse]:
    responses = await get_window_a_responses(user_message)
    if responses is not None:
        return responses
    return _get_demo_responses(user_message)


async def dispatch_responses(
    group_id: str,
    responses: list[AgentResponse],
) -> list[bool]:
    results: list[bool] = []

    for response in responses:
        result = await send_to_group(
            group_id=group_id,
            message=_format_message(response),
            identity=response["role"],
        )
        results.append(result)

    return results


async def handle_user_message(user_message: str, group_id: str) -> None:
    responses = await collect_responses(user_message)
    await dispatch_responses(group_id, responses)

