import json
from pathlib import Path
from typing import Any

from src.window_e.dependencies import get_dependency_status
from src.window_e.orchestrator import collect_responses


async def prepare_demo_bundle(user_message: str, group_id: str) -> dict[str, Any]:
    responses = await collect_responses(user_message)

    return {
        "group_id": group_id,
        "user_message": user_message,
        "dependency_status": get_dependency_status(),
        "response_count": len(responses),
        "responses": responses,
    }


async def write_demo_bundle(
    output_path: str | Path,
    user_message: str,
    group_id: str,
) -> Path:
    target = Path(output_path)
    target.parent.mkdir(parents=True, exist_ok=True)

    bundle = await prepare_demo_bundle(user_message, group_id)
    target.write_text(
        json.dumps(bundle, ensure_ascii=False, indent=2) + "\n",
        encoding="utf-8",
    )
    return target

