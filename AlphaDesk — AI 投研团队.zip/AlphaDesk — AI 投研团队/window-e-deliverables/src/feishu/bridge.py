import asyncio
import os
import sys
from typing import Awaitable, Callable

from src.agents.types import RoleType
from src.window_e.dependencies import get_window_b_listener, get_window_b_sender


def _is_mock_mode() -> bool:
    return os.getenv("FEISHU_MOCK", "false").lower() == "true"


async def send_to_group(
    group_id: str,
    message: str,
    identity: RoleType,
    message_type: str = "text",
) -> bool:
    """
    Send one message to a Feishu chat with a role prefix.

    The interface matches docs/INTERFACE-CONTRACT.md exactly.
    """
    sender = get_window_b_sender()
    if sender is not None:
        return await sender(
            group_id=group_id,
            message=message,
            identity=identity,
            message_type=message_type,
        )

    if _is_mock_mode():
        print(f"[MOCK→{group_id}] {identity}: {message}")
        return True

    print("[send_to_group] Error: Window B sender is unavailable")
    return False


async def start_listener(
    callback: Callable[[str, str], Awaitable[None]],
) -> None:
    """
    Start Feishu message listening and invoke callback(user_message, group_id)
    when the bot is mentioned.
    """
    listener = get_window_b_listener()
    if listener is not None:
        await listener(callback)
        return

    if not _is_mock_mode():
        raise RuntimeError("Window B listener is unavailable and FEISHU_MOCK is false")

    print("[Listener] Mock mode: reading from stdin. Format: group_id::message")
    while True:
        line = await asyncio.to_thread(sys.stdin.readline)
        if not line:
            await asyncio.sleep(0.05)
            continue

        line = line.strip()
        if not line:
            continue
        if "::" not in line:
            print("[Listener] Invalid format. Use: group_id::message")
            continue

        group_id, user_message = line.split("::", 1)
        await callback(user_message, group_id)

