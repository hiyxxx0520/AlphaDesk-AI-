"""Shared agent types for Window E."""

from src.agents.types import AgentResponse, RoleType, TagType

__all__ = ["AgentResponse", "RoleType", "TagType"]

