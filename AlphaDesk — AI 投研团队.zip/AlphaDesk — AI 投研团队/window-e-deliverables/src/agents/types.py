from typing import Literal, TypedDict

RoleType = Literal[
    "macro_analyst",
    "sector_analyst",
    "risk_manager",
    "chief_strategist",
]

TagType = Literal[
    "ALERT",
    "DISAGREE",
    "COUNTER",
    "RISK",
    "ACTION",
]


class AgentResponse(TypedDict):
    role: RoleType
    content: str
    tags: list[TagType]

