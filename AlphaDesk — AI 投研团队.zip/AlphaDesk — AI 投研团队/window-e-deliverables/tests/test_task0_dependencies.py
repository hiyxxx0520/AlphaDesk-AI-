import asyncio
import sys
from pathlib import Path


PROJECT_ROOT = Path(__file__).resolve().parents[1]
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))


def test_window_b_is_available() -> None:
    from src.window_e.dependencies import get_dependency_status, window_b_available

    status = get_dependency_status()

    assert status["window_b_sender"] is True
    assert status["window_b_listener"] is True
    assert window_b_available() is True


def test_window_a_missing_uses_demo_fallback() -> None:
    from src.window_e.demo import _get_demo_responses
    from src.window_e.dependencies import get_dependency_status, get_window_a_responses

    status = get_dependency_status()
    responses = asyncio.run(get_window_a_responses("分析一下美联储"))

    assert status["window_a"] is False
    assert responses is None

    demo_responses = _get_demo_responses("分析一下美联储")
    assert len(demo_responses) == 4
    assert demo_responses[0]["role"] == "macro_analyst"
    assert demo_responses[-1]["role"] == "chief_strategist"
