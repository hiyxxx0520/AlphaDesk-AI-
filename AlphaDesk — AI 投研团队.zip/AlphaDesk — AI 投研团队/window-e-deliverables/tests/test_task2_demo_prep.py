import asyncio
import json
import sys
from pathlib import Path


PROJECT_ROOT = Path(__file__).resolve().parents[1]
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))


def test_prepare_demo_bundle_contains_dependency_status() -> None:
    from src.window_e.demo_prep import prepare_demo_bundle

    bundle = asyncio.run(prepare_demo_bundle("分析一下美股", "oc_demo"))

    assert bundle["group_id"] == "oc_demo"
    assert bundle["response_count"] == 4
    assert bundle["dependency_status"]["window_a"] is False
    assert bundle["dependency_status"]["window_b_sender"] is True


def test_write_demo_bundle_creates_json_file(tmp_path: Path) -> None:
    from src.window_e.demo_prep import write_demo_bundle

    output_path = tmp_path / "demo_bundle.json"
    written = asyncio.run(
        write_demo_bundle(output_path, "分析一下黄金", "oc_demo")
    )

    assert written == output_path
    payload = json.loads(output_path.read_text(encoding="utf-8"))
    assert payload["user_message"] == "分析一下黄金"
    assert payload["responses"][0]["role"] == "macro_analyst"
