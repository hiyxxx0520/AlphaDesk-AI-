import asyncio
import sys
from pathlib import Path


PROJECT_ROOT = Path(__file__).resolve().parents[1]
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))


def test_collect_responses_uses_demo_when_window_a_missing() -> None:
    from src.window_e.orchestrator import collect_responses

    responses = asyncio.run(collect_responses("分析一下英伟达"))

    assert len(responses) == 4
    assert responses[1]["role"] == "sector_analyst"


def test_handle_user_message_dispatches_all_responses(monkeypatch) -> None:
    from src.window_e import orchestrator

    sent: list[tuple[str, str, str, str]] = []

    async def fake_send_to_group(
        group_id: str,
        message: str,
        identity: str,
        message_type: str = "text",
    ) -> bool:
        sent.append((group_id, message, identity, message_type))
        return True

    monkeypatch.setattr(orchestrator, "send_to_group", fake_send_to_group)

    asyncio.run(orchestrator.handle_user_message("分析一下黄金", "oc_demo"))

    assert len(sent) == 4
    assert all(item[0] == "oc_demo" for item in sent)
    assert sent[0][2] == "macro_analyst"
    assert sent[-1][2] == "chief_strategist"
    assert sent[0][1].startswith("[ALERT]")
