from crewai import LLM

from config.settings import LLM_API_KEY, LLM_BASE_URL, LLM_MODEL


def get_llm() -> LLM:
    """返回配置好的 DeepSeek LLM 实例。"""
    return LLM(
        model=LLM_MODEL,
        base_url=LLM_BASE_URL,
        api_key=LLM_API_KEY,
    )
