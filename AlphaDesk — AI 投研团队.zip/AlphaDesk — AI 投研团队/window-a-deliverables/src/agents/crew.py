import json
import os
import re

from crewai import Crew, Process

from src.agents.agents import (
    get_chief_strategist,
    get_macro_analyst,
    get_risk_manager,
    get_sector_analyst,
)
from src.agents.tasks import (
    get_macro_task,
    get_risk_task,
    get_sector_task,
    get_strategy_task,
)
from src.agents.types import AgentResponse, RoleType, TagType


def _load_tools() -> list:
    """懒加载 Tools，避免窗口 C 未完成时报错。"""
    try:
        from src.tools import get_all_tools

        return get_all_tools()
    except ImportError:
        return []


def _extract_tags(content: str) -> list[TagType]:
    """从消息内容中提取 [TAG] 标签。"""
    valid_tags = {"ALERT", "DISAGREE", "COUNTER", "RISK", "ACTION"}
    found = re.findall(r"\[([A-Z]+)\]", content)
    return [tag for tag in found if tag in valid_tags]  # type: ignore[return-value]


def _mock_analysis(trigger_event: str, market_data: dict | None = None) -> list[AgentResponse]:
    """无 API Key 时返回固定结构的 mock 响应，便于本地联调。"""
    market_hint = f" Market snapshot: {market_data}." if market_data else ""
    return [
        {
            "role": "macro_analyst",
            "content": (
                "[ALERT] Trigger captured: "
                f"{trigger_event}.{market_hint} US rates remain elevated and liquidity is tightening."
            ),
            "tags": ["ALERT"],
        },
        {
            "role": "sector_analyst",
            "content": (
                "[DISAGREE] Broad de-risking may be overdone. Weakness is likely concentrated "
                "in duration-heavy sectors while cash-flow resilient growth could hold up better."
            ),
            "tags": ["DISAGREE"],
        },
        {
            "role": "risk_manager",
            "content": (
                "[RISK] Estimated portfolio duration sensitivity is high under this shock. "
                "Stress drawdown could reach -8% in a further yield spike. Cut long-duration exposure by 50%."
            ),
            "tags": ["RISK"],
        },
        {
            "role": "chief_strategist",
            "content": (
                "[ACTION] Team synthesis complete. 1) Reduce duration risk 2) Rotate toward defensive quality "
                "3) Add hedge on rate-sensitive assets. Full report is being prepared for Feishu Docs."
            ),
            "tags": ["ACTION"],
        },
    ]


def run_analysis(trigger_event: str, market_data: dict | None = None) -> list[AgentResponse]:
    """触发一轮完整的 4-Agent 投研分析。"""
    deepseek_api_key = os.getenv("DEEPSEEK_API_KEY", "").strip()
    if (
        not deepseek_api_key
        or "placeholder" in deepseek_api_key.lower()
        or deepseek_api_key.endswith("xxxx")
    ):
        return _mock_analysis(trigger_event, market_data)

    tools = _load_tools()

    macro_agent = get_macro_analyst(tools)
    sector_agent = get_sector_analyst(tools)
    risk_agent = get_risk_manager(tools)
    strategy_agent = get_chief_strategist(tools)

    macro_task = get_macro_task(macro_agent, trigger_event, market_data)
    sector_task = get_sector_task(sector_agent, trigger_event, [macro_task])
    risk_task = get_risk_task(risk_agent, trigger_event, [macro_task, sector_task])
    strategy_task = get_strategy_task(strategy_agent, trigger_event, [macro_task, sector_task, risk_task])

    crew = Crew(
        agents=[macro_agent, sector_agent, risk_agent, strategy_agent],
        tasks=[macro_task, sector_task, risk_task, strategy_task],
        process=Process.sequential,
        verbose=True,
    )

    try:
        crew_output = crew.kickoff()
    except Exception:
        return _mock_analysis(trigger_event, market_data)

    role_order: list[RoleType] = [
        "macro_analyst",
        "sector_analyst",
        "risk_manager",
        "chief_strategist",
    ]

    task_outputs = getattr(crew_output, "tasks_output", [])
    responses: list[AgentResponse] = []
    for index, task_output in enumerate(task_outputs):
        content = str(getattr(task_output, "raw", task_output))
        responses.append(
            {
                "role": role_order[index],
                "content": content,
                "tags": _extract_tags(content),
            }
        )

    return responses


if __name__ == "__main__":
    results = run_analysis(
        trigger_event="Fed released hawkish FOMC minutes. 10Y yield jumped to 4.8%.",
        market_data={"sp500_change_pct": -0.8, "us_10y_yield": 4.8, "vix": 18.5},
    )
    print("\n=== ANALYSIS RESULTS ===")
    for response in results:
        print(f"\n[{response['role'].upper()}] tags={response['tags']}")
        print(response["content"])

    print("\n=== JSON OUTPUT ===")
    print(json.dumps(results, indent=2))
