"""在没有 API Key 时验证 crew.py 的代码结构和类型正确性。"""

import sys
from pathlib import Path

PROJECT_ROOT = Path(__file__).resolve().parents[1]
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

from src.agents.types import AgentResponse


def test_mock_response_structure() -> None:
    """验证 AgentResponse TypedDict 结构正确。"""
    mock_responses: list[AgentResponse] = [
        {"role": "macro_analyst", "content": "[ALERT] Test macro signal.", "tags": ["ALERT"]},
        {"role": "sector_analyst", "content": "[DISAGREE] Counter view.", "tags": ["DISAGREE"]},
        {"role": "risk_manager", "content": "[RISK] Drawdown -8%.", "tags": ["RISK"]},
        {"role": "chief_strategist", "content": "[ACTION] Step 1: ...", "tags": ["ACTION"]},
    ]

    assert len(mock_responses) == 4
    for response in mock_responses:
        assert "role" in response
        assert "content" in response
        assert "tags" in response

    print("✅ AgentResponse structure test passed")


def test_role_coverage() -> None:
    """验证 4 个角色都有定义。"""
    from src.agents.agents import (
        get_chief_strategist,
        get_macro_analyst,
        get_risk_manager,
        get_sector_analyst,
    )

    agents = [
        get_macro_analyst(),
        get_sector_analyst(),
        get_risk_manager(),
        get_chief_strategist(),
    ]
    assert len(agents) == 4
    print("✅ All 4 agents instantiated successfully")


if __name__ == "__main__":
    test_mock_response_structure()
    test_role_coverage()
    print("\n✅ All mock tests passed")
