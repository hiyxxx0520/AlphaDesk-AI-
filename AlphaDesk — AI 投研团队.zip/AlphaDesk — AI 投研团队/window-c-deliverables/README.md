# Window C Deliverables

This folder is the dedicated delivery package for Window C.

Included from the current repository:
- `src/tools/__init__.py`
- `src/tools/_crewai_compat.py`
- `src/tools/akshare_tool.py`
- `src/tools/yfinance_tool.py`
- `tests/test_tools.py`
- `data/demo_data.json`
- shared `pyproject.toml`, `requirements.txt`, and `config/settings.py`

Spec reference:
- `docs/windows/WINDOW-C-tools.md`
