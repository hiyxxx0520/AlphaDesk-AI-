import json
import os
import sys
from pathlib import Path


sys.path.insert(0, str(Path(__file__).resolve().parents[1]))


def test_tools_import() -> None:
    from src.tools import get_all_tools

    tools = get_all_tools()
    assert len(tools) == 2, f"Expected 2 tools, got {len(tools)}"
    names = [tool.name for tool in tools]
    assert "AKShare Market Data" in names
    assert "yFinance Global Market Data" in names
    print("✅ Tool import test passed")


def test_demo_mode() -> None:
    os.environ["DEMO_MODE"] = "true"

    from src.tools.akshare_tool import AKShareTool

    tool = AKShareTool()
    result = tool._run("get_price:000001")
    data = json.loads(result)
    assert data["symbol"] == "000001"
    print(f"✅ Demo mode test passed: {data}")

    os.environ["DEMO_MODE"] = "false"


def test_tool_error_handling() -> None:
    from src.tools.akshare_tool import AKShareTool

    tool = AKShareTool()
    result = tool._run("invalid_query")
    assert "Error" in result or "error" in result
    print(f"✅ Error handling test passed: {result[:50]}...")


if __name__ == "__main__":
    test_tools_import()
    test_demo_mode()
    test_tool_error_handling()
    print("\n✅ All tool tests passed")
