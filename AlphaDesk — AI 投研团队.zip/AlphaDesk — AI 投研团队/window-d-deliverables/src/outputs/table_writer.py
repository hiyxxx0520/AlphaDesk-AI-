import os

from src.outputs.feishu_client import append_bitable_record


async def update_risk_matrix(risk_data: dict) -> str:
    """
    Write one risk snapshot into Feishu Bitable or local mock storage.

    Interface must stay aligned with docs/INTERFACE-CONTRACT.md.
    """
    app_token = os.getenv("FEISHU_BITABLE_APP_TOKEN", "")
    table_id = os.getenv("FEISHU_BITABLE_TABLE_ID", "")

    fields = {
        "触发事件": risk_data.get("trigger", ""),
        "时间戳": risk_data.get("timestamp", ""),
        "久期敏感度": risk_data.get("duration_sensitivity", 0),
        "预估最大回撤": risk_data.get("estimated_drawdown", 0),
        "建议操作": risk_data.get("recommendation", ""),
        "VIX": risk_data.get("vix", 0),
        "标普变动%": risk_data.get("sp500_change", 0),
    }

    return await append_bitable_record(app_token, table_id, fields)
