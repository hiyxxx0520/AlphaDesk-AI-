from src.agents.types import RoleType, TagType

ROLE_COLOR: dict[RoleType, str] = {
    "macro_analyst": "blue",
    "sector_analyst": "green",
    "risk_manager": "red",
    "chief_strategist": "orange",
}

ROLE_DISPLAY: dict[RoleType, str] = {
    "macro_analyst": "🔭 Macro Analyst",
    "sector_analyst": "💡 Sector Analyst",
    "risk_manager": "⚠️ Risk Manager",
    "chief_strategist": "🎯 Chief Strategist",
}

TAG_STYLE: dict[TagType, dict[str, str]] = {
    "ALERT": {"color": "red", "text": "[ALERT]"},
    "DISAGREE": {"color": "yellow", "text": "[DISAGREE]"},
    "COUNTER": {"color": "yellow", "text": "[COUNTER]"},
    "RISK": {"color": "red", "text": "[RISK]"},
    "ACTION": {"color": "green", "text": "[ACTION]"},
}


def build_agent_card(
    role: RoleType,
    content: str,
    tags: list[TagType],
) -> dict:
    """
    Build a Feishu interactive card payload for one agent message.

    Interface must stay aligned with docs/INTERFACE-CONTRACT.md.
    """
    card_tags = [
        {
            "tag": "tag",
            "text": {"tag": "plain_text", "content": TAG_STYLE[tag]["text"]},
            "color": TAG_STYLE[tag]["color"],
        }
        for tag in tags
    ]

    elements: list[dict] = [
        {
            "tag": "div",
            "text": {
                "tag": "lark_md",
                "content": content,
            },
        }
    ]

    if card_tags:
        elements.append({"tag": "action", "actions": card_tags})

    return {
        "config": {"wide_screen_mode": True},
        "header": {
            "title": {
                "tag": "plain_text",
                "content": ROLE_DISPLAY[role],
            },
            "template": ROLE_COLOR[role],
        },
        "elements": elements,
    }
