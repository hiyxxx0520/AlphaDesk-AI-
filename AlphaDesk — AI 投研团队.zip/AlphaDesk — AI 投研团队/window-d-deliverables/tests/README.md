Window D tests have not been split out yet.

Recommended first checks:
- `build_agent_card` structure test
- mock document generation test
- mock risk table write test
