# Window D Deliverables

This folder is the dedicated delivery package for Window D.

Included from the current repository:
- `src/outputs/__init__.py`
- `src/outputs/card_builder.py`
- `src/outputs/doc_generator.py`
- `src/outputs/table_writer.py`
- `src/outputs/feishu_client.py`
- `src/agents/types.py` and `src/agents/__init__.py` for output-module type imports
- shared `pyproject.toml`, `requirements.txt`, and `config/settings.py`

Spec reference:
- `docs/windows/WINDOW-D-outputs.md`
