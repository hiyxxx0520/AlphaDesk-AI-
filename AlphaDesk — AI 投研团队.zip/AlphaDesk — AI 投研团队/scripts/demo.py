"""
AlphaDesk Demo Script

Runs the full 4-agent pipeline with:
  DEMO_MODE=true   → financial tools return cached data
  FEISHU_MOCK=true → messages printed to terminal, not sent to Feishu

Usage:
    python scripts/demo.py
    python scripts/demo.py "分析美联储最新议息会议结果"
"""
import asyncio
import os
import sys
from pathlib import Path

# Ensure project root is on sys.path
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

# Override env before any imports that read it
os.environ["DEMO_MODE"] = "true"
os.environ["FEISHU_MOCK"] = "true"
os.environ.setdefault("MESSAGE_DELAY", "0")

from src.agents.crew import run_analysis
from src.feishu.sender import ROLE_PREFIX

DEMO_TRIGGER = (
    sys.argv[1]
    if len(sys.argv) > 1
    else "Fed released hawkish FOMC minutes. 10Y yield jumped to 4.8%. "
         "S&P500 dropped 0.8%, VIX spiked to 18.5."
)
DEMO_GROUP_ID = os.getenv("FEISHU_GROUP_ID", "oc_demo")
DEMO_MARKET_DATA = {
    "sp500_change_pct": -0.8,
    "nasdaq_change_pct": -1.2,
    "us_10y_yield": 4.8,
    "usd_cny": 7.25,
    "vix": 18.5,
    "gold_price": 2320.5,
    "crude_oil_price": 82.3,
}

SEP = "=" * 65


def print_header() -> None:
    print(SEP)
    print("  AlphaDesk — AI 投研团队 Demo")
    print(SEP)
    print(f"  触发事件 : {DEMO_TRIGGER}")
    print(f"  飞书群   : {DEMO_GROUP_ID}")
    print(f"  模式     : DEMO_MODE=true, FEISHU_MOCK=true")
    print(SEP)


async def run_demo() -> None:
    print_header()
    print("\n[Step 1] 启动 4-Agent 分析...\n")

    responses = run_analysis(DEMO_TRIGGER, DEMO_MARKET_DATA)

    print(f"\n[Step 2] 发送 {len(responses)} 条分析消息到飞书群 {DEMO_GROUP_ID}\n")

    from src.orchestrator import handle_trigger
    await handle_trigger(DEMO_TRIGGER, DEMO_GROUP_ID)

    print(f"\n{SEP}")
    print("  分析结果摘要")
    print(SEP)
    for resp in responses:
        prefix = ROLE_PREFIX[resp["role"]]
        tags = " ".join(f"[{t}]" for t in resp["tags"])
        print(f"\n{prefix}  {tags}")
        print(f"  {resp['content']}")

    print(f"\n{SEP}")
    print("  Demo 完成！全链路运行正常。")
    print(SEP)


if __name__ == "__main__":
    asyncio.run(run_demo())
