# AlphaDesk 并行开发执行计划

> **用途**：多窗口 Claude Code 并行开发的分工方案 + Superpowers 最佳实践
> **日期**：2026-04-16

---

## 一、整体架构：4 个独立开发轨道

AlphaDesk 项目可以拆分为 **4 个高度独立的模块**，每个模块由一个 Claude Code 窗口负责。模块之间通过**约定好的接口（函数签名 + 数据格式）**来对接，最后在第 5 个窗口做集成。

```
窗口 A: CrewAI 多 Agent 核心（纯 Python，本地可运行）
窗口 B: 飞书消息收发连接器（飞书 API / LarkAgentX）
窗口 C: 金融数据工具层（AKShare / yfinance 封装）
窗口 D: 飞书输出集成（文档生成 + 多维表格 + 卡片消息）
窗口 E: 集成 + Demo（最后启动，拼装 A+B+C+D）
```

---

## 二、各窗口详细任务分配

### 窗口 A — CrewAI 多 Agent 核心

**负责人**：最核心模块，建议自己重点关注
**预计时间**：3-4 小时
**依赖**：无外部依赖，可立即启动
**产出目录**：`src/agents/`

#### 任务清单

1. 初始化项目结构：
   ```
   alphadesk/
   ├── pyproject.toml
   ├── requirements.txt
   ├── src/
   │   ├── __init__.py
   │   ├── agents/          ← 窗口 A 负责
   │   │   ├── __init__.py
   │   │   ├── macro_analyst.py
   │   │   ├── sector_analyst.py
   │   │   ├── risk_manager.py
   │   │   ├── chief_strategist.py
   │   │   └── crew.py        # CrewAI Crew 编排
   │   ├── tools/            ← 窗口 C 负责
   │   ├── feishu/           ← 窗口 B 负责
   │   ├── outputs/          ← 窗口 D 负责
   │   └── orchestrator.py   ← 窗口 E 负责
   ├── config/
   │   └── settings.py       # API keys, 配置
   ├── tests/
   └── CLAUDE.md
   ```

2. 编写 4 个 Agent 的 system prompt（参照项目文档 Section 6）
3. 定义 CrewAI Tasks：每个 Agent 对应一个 Task
4. 编写 `crew.py`：Crew 编排逻辑（Sequential process）
5. 本地跑通一轮完整的 4 Agent 对话
6. **关键输出接口**（供窗口 E 集成用）：
   ```python
   # crew.py 必须暴露这个函数
   def run_analysis(trigger_event: str, market_data: dict = None) -> list[AgentResponse]:
       """
       返回值格式：
       [
           {"role": "macro_analyst", "content": "...", "tags": ["ALERT"]},
           {"role": "sector_analyst", "content": "...", "tags": ["DISAGREE"]},
           {"role": "risk_manager", "content": "...", "tags": ["RISK"]},
           {"role": "chief_strategist", "content": "...", "tags": ["ACTION"]},
       ]
       """
   ```

---

### 窗口 B — 飞书消息收发连接器

**预计时间**：2-3 小时
**依赖**：需要飞书开放平台 App ID / App Secret（你手动配置）
**产出目录**：`src/feishu/`

#### 任务清单

1. 评估 LarkAgentX vs 飞书官方 Bot SDK（`larksuite/oapi-sdk-python`），选择更稳定的方案
2. 实现飞书群消息发送（支持多身份/多头像发送）：
   ```python
   # feishu/sender.py 必须暴露这个接口
   async def send_to_group(
       group_id: str,
       message: str,
       identity: str,          # "macro_analyst" | "sector_analyst" | ...
       message_type: str = "text"  # "text" | "interactive"（卡片）
   ) -> bool:
   ```
3. 实现飞书群消息监听（@机器人 触发）：
   ```python
   # feishu/listener.py 必须暴露这个接口
   async def on_message(callback: Callable[[str, str], None]):
       """callback(user_message, group_id)"""
   ```
4. 测试：能在飞书群里收发消息

---

### 窗口 C — 金融数据工具层

**预计时间**：1.5-2 小时
**依赖**：无外部依赖，可立即启动
**产出目录**：`src/tools/`

#### 任务清单

1. 封装 AKShare 为 CrewAI Tool：
   ```python
   # tools/market_data.py
   class MarketDataTool(BaseTool):
       """CrewAI 可直接调用的工具"""
       name = "market_data"
       description = "获取实时行情数据..."
       
       def _run(self, query: str) -> str:
           # 支持：股票行情、指数、宏观数据、汇率
   ```
2. 封装 yfinance 作为备选（美股数据）
3. 封装新闻获取工具（RSS / NewsAPI）
4. **关键输出接口**：
   ```python
   # tools/__init__.py 暴露
   def get_all_tools() -> list[BaseTool]:
       """返回所有可用的 CrewAI Tools"""
   ```
5. 准备一组示范数据（JSON 缓存），以防 API 不稳定时 Demo 用

---

### 窗口 D — 飞书输出集成

**预计时间**：2-3 小时（P1 优先级，窗口 A/B/C 完成后再启动也可）
**依赖**：需要飞书开放平台权限配置
**产出目录**：`src/outputs/`

#### 任务清单

1. 飞书文档自动生成（策略报告模板）：
   ```python
   # outputs/doc_generator.py
   async def generate_strategy_doc(
       responses: list[AgentResponse],
       doc_title: str
   ) -> str:  # 返回文档链接
   ```
2. 飞书多维表格写入（风险矩阵）：
   ```python
   # outputs/table_writer.py
   async def update_risk_matrix(
       risk_data: dict
   ) -> str:  # 返回表格链接
   ```
3. 飞书卡片消息模板（美化每个 Agent 的发言）：
   ```python
   # outputs/card_builder.py
   def build_agent_card(
       role: str, content: str, tags: list[str]
   ) -> dict:  # 返回飞书 interactive 消息 JSON
   ```
4. （可选）日历事件创建

---

### 窗口 E — 集成 + Orchestrator + Demo

**启动时机**：窗口 A + B 基本完成后启动
**预计时间**：2-3 小时
**产出目录**：`src/orchestrator.py` + `README.md`

#### 任务清单

1. 编写 Orchestrator 主流程：
   ```python
   async def handle_trigger(user_message: str, group_id: str):
       # 1. 调用 crew.run_analysis(user_message)
       # 2. 逐条通过 feishu.send_to_group() 发到飞书群
       # 3. （可选）生成飞书文档 + 更新多维表格
   ```
2. 接入触发机制：飞书 @机器人 → Orchestrator
3. 添加定时触发逻辑（可选）
4. 编写 README.md + Demo 演示脚本
5. 录制 Demo 视频（如需要）
6. 打包提交

---

## 三、CLAUDE.md 配置（所有窗口共用）

在项目根目录创建 `CLAUDE.md`，让每个窗口的 Claude Code 都能理解项目全貌：

```markdown
# AlphaDesk — AI 投研团队

## 项目概述
飞书群里的 4 个 AI Agent 自主讨论投研观点。

## 技术栈
- Python 3.11+, CrewAI, AKShare, yfinance
- 飞书 Bot SDK (larksuite/oapi-sdk-python) 或 LarkAgentX
- LLM: DeepSeek API (主力) / 豆包 (备选)

## 目录结构
- src/agents/    → CrewAI 4 Agent 定义 + Crew 编排
- src/tools/     → 金融数据获取工具（CrewAI Tool）
- src/feishu/    → 飞书消息收发
- src/outputs/   → 飞书文档/表格/卡片生成
- src/orchestrator.py → 主编排入口

## 模块间接口约定
- agents/crew.py → run_analysis(trigger_event, market_data) → list[AgentResponse]
- feishu/sender.py → send_to_group(group_id, message, identity, message_type)
- feishu/listener.py → on_message(callback)
- tools/__init__.py → get_all_tools() → list[BaseTool]
- outputs/doc_generator.py → generate_strategy_doc(responses, title)
- outputs/card_builder.py → build_agent_card(role, content, tags)

## AgentResponse 数据格式
{"role": str, "content": str, "tags": list[str]}

## 代码风格
- MVP 优先，能跑就行
- 类型提示用 Python 3.11 语法
- 配置通过环境变量 + config/settings.py

## 注意事项
- 网络环境在日本东京，部分 API 可能需要代理
- LLM 优先 DeepSeek API，如比赛要求则切换豆包
- 飞书凭证在 .env 文件中，不要提交到 git
```

---

## 四、Superpowers 使用策略

### 4.1 能不能用？

**可以用，而且非常推荐。** 但需要注意你的场景和 Superpowers 的设计假设有一些差异，需要做策略调整。

### 4.2 哪些 Superpowers 技能适合本项目

| Superpowers 技能 | 适用场景 | 本项目怎么用 |
|---|---|---|
| **brainstorming** | 设计 Agent prompt、讨论架构决策 | ✅ 窗口 A 在设计 4 个 Agent 的 prompt 时使用，让 Claude 帮你苏格拉底式地细化角色设定 |
| **writing-plans** | 为复杂模块写详细实施计划 | ✅ 每个窗口在正式写代码前，先让 Claude 出一份细化的 plan |
| **subagent-driven-development** | 在单个窗口内自动化执行多个任务 | ✅ **最推荐**。每个窗口内，Claude 会 dispatch 子 agent 逐个完成任务清单 |
| **test-driven-development** | 写测试 → 写代码 → 通过 | ⚠️ 建议简化使用。MVP 项目不需要严格 TDD，但可以为关键接口写简单测试 |
| **systematic-debugging** | Debug 时不要瞎猜 | ✅ 遇到 bug 时非常有用，尤其是飞书 API 调试 |
| **dispatching-parallel-agents** | 同一个窗口内并行处理多个独立问题 | ⚠️ 本项目更适合用多窗口而非窗口内并行 |
| **using-git-worktrees** | 创建独立开发分支 | ✅ 每个窗口在自己的 worktree 上工作，最后 merge |
| **finishing-a-development-branch** | 完成后合并分支 | ✅ 窗口 E 集成阶段使用 |

### 4.3 每个窗口的 Superpowers 使用流程

**推荐的统一工作流**：

```
第 1 步：/superpowers:brainstorm
  → 让 Claude 理解这个模块要做什么
  → 细化设计（特别是接口约定）
  → 产出 design doc

第 2 步：/superpowers:write-plan
  → 把 design doc 转成具体的实施任务
  → 每个任务 2-5 分钟可完成
  → 包含具体的文件路径、函数签名、验证步骤

第 3 步：让 Claude 执行（自动进入 subagent-driven-development）
  → Claude 会逐个 dispatch 子 agent 完成任务
  → 每个子 agent 有 spec 审查 + 代码质量审查
  → 你可以放手让它跑，定期检查进度
```

### 4.4 Superpowers 使用的具体优化建议

#### 建议 1：在 CLAUDE.md 中声明 MVP 模式

在 CLAUDE.md 中加入以下内容，让 Superpowers 的行为适配你的 MVP 节奏：

```markdown
## Superpowers 调整
- TDD 简化模式：只对 **模块间接口** 写测试，内部实现不强求测试覆盖
- 代码审查简化：spec compliance 审查保留，code quality 审查放宽标准（不阻塞 style 问题）
- brainstorming 限时：设计讨论控制在 15 分钟内，不追求完美设计
- plan 粒度：每个 task 控制在 5-10 分钟（而非默认的 2-5 分钟），减少 overhead
```

#### 建议 2：用 git worktree 隔离每个窗口

```bash
# 在项目根目录执行（只需一次）
git init
git add -A && git commit -m "init"

# 为每个窗口创建 worktree
git worktree add ../alphadesk-agents   agents-dev
git worktree add ../alphadesk-feishu   feishu-dev
git worktree add ../alphadesk-tools    tools-dev
git worktree add ../alphadesk-outputs  outputs-dev
```

每个窗口在自己的 worktree 目录下工作，不会产生 git 冲突。最后窗口 E 在主分支上 merge 所有分支。

#### 建议 3：给每个窗口写专属的启动 Prompt

不要只说"开发飞书模块"，而是给一个结构化的启动指令：

**窗口 A 的启动 Prompt 示例**：
```
请阅读 CLAUDE.md 了解项目全貌。

你负责的是 src/agents/ 模块——CrewAI 多 Agent 核心。

目标：
1. 用 CrewAI 框架创建 4 个投研 Agent（Macro Analyst, Sector Analyst, Risk Manager, Chief Strategist）
2. 每个 Agent 有独立的 system prompt，参照 AlphaDesk-Project-Brief.md 的 Section 6
3. 编写 crew.py，暴露 run_analysis() 函数
4. 在本地跑通一轮完整对话

接口约定（其他模块会调用这个函数）：
def run_analysis(trigger_event: str, market_data: dict = None) -> list[dict]:
    # 返回 [{"role": "macro_analyst", "content": "...", "tags": ["ALERT"]}, ...]

请先 /superpowers:brainstorm 确认设计，再 /superpowers:write-plan，然后开始执行。
```

#### 建议 4：利用 subagent-driven-development 的状态信号

Superpowers 的 subagent 执行完任务后会报告 4 种状态：
- **DONE** → 正常继续
- **DONE_WITH_CONCERNS** → 读一下顾虑，通常可以继续
- **NEEDS_CONTEXT** → 提供缺失的上下文（比如接口约定）
- **BLOCKED** → 需要你介入（比如飞书 API 配置问题）

你只需要在 BLOCKED 时介入，其他情况让 Claude 自己跑。

#### 建议 5：不需要用的 Superpowers 功能

- **dispatching-parallel-agents**：你已经手动开了多窗口，不需要在窗口内再并行
- **严格 TDD**：MVP 不需要。在 CLAUDE.md 里声明简化模式即可
- **requesting-code-review / receiving-code-review**：多人协作才需要，你是 AI + 个人开发，省略

---

## 五、时间线与里程碑

```
T+0h ~ T+0.5h   准备阶段
  ├── 创建项目目录 + CLAUDE.md
  ├── git init + worktree 设置
  ├── 配置飞书开放平台 App（手动完成）
  └── 同时启动窗口 A / B / C

T+0.5h ~ T+4h   并行开发阶段
  ├── 窗口 A: CrewAI Agent 核心（brainstorm → plan → execute）
  ├── 窗口 B: 飞书连接器（brainstorm → plan → execute）
  └── 窗口 C: 数据工具层（brainstorm → plan → execute）

T+3h ~ T+5h     窗口 D 启动 + 窗口 E 开始集成
  ├── 窗口 D: 飞书输出集成（如有余力）
  └── 窗口 E: Orchestrator 拼装（A + B + C 完成后）

T+5h ~ T+7h     Demo 准备
  ├── 完整链路测试
  ├── 准备示范数据（以防 API 不稳定）
  ├── 录制 Demo 视频
  └── 撰写 README + 提交材料
```

---

## 六、风险应对速查

| 遇到的问题 | 处理方案 |
|---|---|
| 窗口之间接口不匹配 | 回到 CLAUDE.md 检查接口约定，以 CLAUDE.md 为准 |
| LarkAgentX 不稳定 | 窗口 B 切换到 `larksuite/oapi-sdk-python`（官方 SDK） |
| DeepSeek API 太慢 | 切换更快的模型，或预缓存一轮对话结果用于 Demo |
| 多 Agent 发言太长/太同质 | 回到窗口 A 调整 prompt，加强字数限制和观点差异化 |
| 飞书多身份发送不可行 | 改为单机器人发送，用 [Macro Analyst] 前缀区分角色 |
| Git merge 冲突 | 每个窗口只修改自己目录内的文件，冲突概率极低 |
| Superpowers plan 太细碎 | 在 CLAUDE.md 中调整 task 粒度到 5-10 分钟 |

---

## 七、快速启动清单

开工前完成这些（手动操作，约 15 分钟）：

- [ ] 在飞书开放平台创建应用，获取 App ID + App Secret
- [ ] 创建飞书测试群
- [ ] 获取 DeepSeek API Key
- [ ] 在项目根目录创建 `.env` 文件：
  ```
  DEEPSEEK_API_KEY=xxx
  FEISHU_APP_ID=xxx
  FEISHU_APP_SECRET=xxx
  FEISHU_GROUP_ID=xxx
  ```
- [ ] 确认 Claude Code 已安装 Superpowers 插件：
  ```
  /plugin install superpowers@superpowers-marketplace
  ```
- [ ] 执行 git init + worktree 设置
- [ ] 将 `CLAUDE.md` 和 `AlphaDesk-Project-Brief.md` 放入项目根目录
- [ ] 启动 4 个 Claude Code 窗口，分别 cd 到各自的 worktree
