import asyncio

from src.feishu.listener import start_listener
from src.orchestrator import handle_trigger


def main() -> None:
    asyncio.run(start_listener(handle_trigger))


if __name__ == "__main__":
    main()
