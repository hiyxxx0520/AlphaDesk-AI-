import os

from dotenv import load_dotenv

load_dotenv()

# LLM
LLM_API_KEY = os.getenv("DEEPSEEK_API_KEY", "")
LLM_BASE_URL = os.getenv("LLM_BASE_URL", "https://api.deepseek.com")
LLM_MODEL = os.getenv("LLM_MODEL", "deepseek-chat")

# 飞书
FEISHU_GROUP_ID = os.getenv("FEISHU_GROUP_ID", "")
FEISHU_MOCK = os.getenv("FEISHU_MOCK", "false").lower() == "true"

# 模式控制
DEMO_MODE = os.getenv("DEMO_MODE", "false").lower() == "true"
MESSAGE_DELAY = float(os.getenv("MESSAGE_DELAY", "1.5"))
ENABLE_DOC = os.getenv("ENABLE_DOC", "false").lower() == "true"
