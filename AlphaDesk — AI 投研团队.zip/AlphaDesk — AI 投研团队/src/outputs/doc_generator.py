from datetime import datetime

from src.agents.types import AgentResponse
from src.outputs.feishu_client import create_document

ROLE_DISPLAY_NAME = {
    "macro_analyst": "🔭 Macro Analyst",
    "sector_analyst": "💡 Sector Analyst",
    "risk_manager": "⚠️ Risk Manager",
    "chief_strategist": "🎯 Chief Strategist",
}


def _format_as_markdown(responses: list[AgentResponse]) -> str:
    date_str = datetime.now().strftime("%Y-%m-%d %H:%M")
    lines = [
        "## AlphaDesk Investment Research Report",
        f"*Generated at {date_str}*",
        "",
        "---",
        "",
    ]

    for response in responses:
        display_name = ROLE_DISPLAY_NAME.get(response["role"], response["role"])
        tags_str = " ".join(f"`[{tag}]`" for tag in response["tags"])
        heading = f"### {display_name}"
        if tags_str:
            heading = f"{heading} {tags_str}"
        lines.extend(
            [
                heading,
                "",
                response["content"],
                "",
                "---",
                "",
            ]
        )

    return "\n".join(lines)


async def generate_strategy_doc(
    responses: list[AgentResponse],
    doc_title: str,
) -> str:
    """Generate a strategy report document from agent responses."""
    content_markdown = _format_as_markdown(responses)
    return await create_document(doc_title, content_markdown)
