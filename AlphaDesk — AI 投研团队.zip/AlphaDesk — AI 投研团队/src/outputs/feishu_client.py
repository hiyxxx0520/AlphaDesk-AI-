import json
import os
import time
from pathlib import Path

from dotenv import load_dotenv

load_dotenv()

DATA_DIR = Path("data")
MOCK_TABLE_PATH = DATA_DIR / "mock_risk_matrix.json"

_client = None


def get_client():
    global _client
    if _client is None:
        import lark_oapi as lark
        app_id = os.getenv("FEISHU_APP_ID", "").strip()
        app_secret = os.getenv("FEISHU_APP_SECRET", "").strip()
        if not app_id or not app_secret:
            raise ValueError(
                "FEISHU_APP_ID and FEISHU_APP_SECRET must be set in .env."
            )
        _client = (
            lark.Client.builder()
            .app_id(app_id)
            .app_secret(app_secret)
            .build()
        )
    return _client


def is_feishu_available() -> bool:
    return bool(os.getenv("FEISHU_APP_ID", "").strip()) and bool(
        os.getenv("FEISHU_APP_SECRET", "").strip()
    )


async def create_document(title: str, content_markdown: str) -> str:
    """Create a Feishu document. Falls back to local mock if credentials absent."""
    if not is_feishu_available():
        return _mock_save_doc(title, content_markdown)

    try:
        import lark_oapi as lark
        from lark_oapi.api.docx.v1 import CreateDocumentRequest, CreateDocumentRequestBody

        client = get_client()
        request_body = CreateDocumentRequestBody.builder().title(title)
        folder_token = os.getenv("FEISHU_DOC_FOLDER_TOKEN", "").strip()
        if folder_token:
            request_body = request_body.folder_token(folder_token)

        request = (
            CreateDocumentRequest.builder()
            .request_body(request_body.build())
            .build()
        )
        response = client.docx.v1.document.create(request)
        if response.success() and response.data and response.data.document:
            doc_id = response.data.document.document_id
            return f"https://feishu.cn/docx/{doc_id}"
        print(f"[create_document] Error: {response.code} {response.msg}")
    except Exception as exc:
        print(f"[create_document] Exception: {exc}")

    return _mock_save_doc(title, content_markdown)


async def append_bitable_record(app_token: str, table_id: str, fields: dict) -> str:
    """Append one record to a Feishu Bitable table. Falls back to local mock."""
    if not is_feishu_available() or not app_token.strip() or not table_id.strip():
        return _mock_save_table(fields)

    try:
        from lark_oapi.api.bitable.v1 import AppTableRecord, CreateAppTableRecordRequest

        client = get_client()
        request = (
            CreateAppTableRecordRequest.builder()
            .app_token(app_token)
            .table_id(table_id)
            .request_body(AppTableRecord.builder().fields(fields).build())
            .build()
        )
        response = client.bitable.v1.app_table_record.create(request)
        if response.success():
            return f"https://feishu.cn/base/{app_token}?table={table_id}"
        print(f"[append_bitable_record] Error: {response.code} {response.msg}")
    except Exception as exc:
        print(f"[append_bitable_record] Exception: {exc}")

    return _mock_save_table(fields)


def _mock_save_doc(title: str, content: str) -> str:
    DATA_DIR.mkdir(parents=True, exist_ok=True)
    filepath = DATA_DIR / f"mock_doc_{int(time.time())}.md"
    filepath.write_text(f"# {title}\n\n{content}", encoding="utf-8")
    mock_path = str(filepath)
    print(f"[MOCK] Document saved to {mock_path}")
    return mock_path


def _mock_save_table(fields: dict) -> str:
    DATA_DIR.mkdir(parents=True, exist_ok=True)
    records: list[dict] = []
    if MOCK_TABLE_PATH.exists():
        records = json.loads(MOCK_TABLE_PATH.read_text(encoding="utf-8"))
    records.append({"timestamp": time.time(), "fields": fields})
    MOCK_TABLE_PATH.write_text(
        json.dumps(records, ensure_ascii=False, indent=2, default=str),
        encoding="utf-8",
    )
    mock_path = str(MOCK_TABLE_PATH)
    print(f"[MOCK] Record saved to {mock_path}")
    return mock_path
