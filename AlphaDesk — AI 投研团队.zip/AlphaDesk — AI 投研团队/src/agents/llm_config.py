from crewai import LLM

from config.settings import LLM_API_KEY, LLM_BASE_URL, LLM_MODEL


def get_llm() -> LLM:
    return LLM(
        model=LLM_MODEL,
        base_url=LLM_BASE_URL,
        api_key=LLM_API_KEY,
    )
