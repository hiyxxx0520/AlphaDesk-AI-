from crewai import Agent, Task


def get_macro_task(agent: Agent, trigger_event: str, market_data: dict | None = None) -> Task:
    market_context = f"\nAvailable market data: {market_data}" if market_data else ""
    return Task(
        description=(
            f"Analyze the following market event from a top-down macro perspective:\n\n"
            f"EVENT: {trigger_event}{market_context}\n\n"
            f"Instructions:\n"
            f"- Start with [ALERT] if this is an urgent development\n"
            f"- Cite specific data points (yield levels, rate probabilities, CPI numbers)\n"
            f"- Flag which asset classes are most affected\n"
            f"- Tag team members who need to weigh in: @Sector @Risk\n"
            f"- Keep response to 3-5 sentences maximum"
        ),
        expected_output=(
            "A concise macro analysis (3-5 sentences) starting with [ALERT] if urgent, "
            "citing specific data points, identifying affected asset classes."
        ),
        agent=agent,
    )


def get_sector_task(agent: Agent, trigger_event: str, context_tasks: list[Task]) -> Task:
    return Task(
        description=(
            f"The Macro Analyst has just delivered their assessment of: {trigger_event}\n\n"
            f"Your job is to provide a sector-specific counter-perspective:\n"
            f"- Read the Macro Analyst's analysis above\n"
            f"- CHALLENGE at least one key assumption with bottom-up evidence\n"
            f"- Cite specific tickers, P/E ratios, or sector ETFs\n"
            f"- Distinguish between what is already priced in vs genuine new risk\n"
            f"- Use [DISAGREE] or [COUNTER] tag if challenging the macro view\n"
            f"- Keep response to 3-5 sentences maximum"
        ),
        expected_output=(
            "A sector-specific analysis (3-5 sentences) that challenges or refines the macro view, "
            "citing specific securities or sector data."
        ),
        agent=agent,
        context=context_tasks,
    )


def get_risk_task(agent: Agent, trigger_event: str, context_tasks: list[Task]) -> Task:
    return Task(
        description=(
            f"The team has analyzed: {trigger_event}\n\n"
            f"Run a quantitative risk assessment based on all previous analyses:\n"
            f"- Calculate estimated portfolio sensitivity (use realistic numbers)\n"
            f"- Estimate drawdown scenario under stress conditions\n"
            f"- Provide a specific hedging recommendation with position sizing\n"
            f"- Use [RISK] tag for risk alerts\n"
            f"- Reference risk metrics: VaR, duration sensitivity, max drawdown\n"
            f"- End with ONE specific, actionable recommendation\n"
            f"- Keep response to 3-5 sentences maximum"
        ),
        expected_output=(
            "A quantitative risk assessment (3-5 sentences) with specific numbers, "
            "starting with [RISK], ending with one concrete recommendation."
        ),
        agent=agent,
        context=context_tasks,
    )


def get_strategy_task(agent: Agent, trigger_event: str, context_tasks: list[Task]) -> Task:
    return Task(
        description=(
            f"All team members have weighed in on: {trigger_event}\n\n"
            f"As Chief Strategist, synthesize all perspectives into a final decision:\n"
            f"- Acknowledge each team member's key insight (1 sentence each)\n"
            f"- State your overall assessment\n"
            f"- Produce a numbered action plan with 3-5 specific steps\n"
            f"- Mention that a full strategy report is being generated to Feishu Docs\n"
            f"- Use [ACTION] tag\n"
            f"- Keep response to 4-6 sentences maximum"
        ),
        expected_output=(
            "A strategic synthesis (4-6 sentences) with [ACTION] tag, acknowledging all team inputs, "
            "and a numbered action plan of 3-5 specific steps."
        ),
        agent=agent,
        context=context_tasks,
    )
