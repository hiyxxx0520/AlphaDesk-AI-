import asyncio
import os
from datetime import datetime

from src.agents.crew import run_analysis
from src.agents.types import AgentResponse
from src.feishu.sender import send_to_group

MESSAGE_DELAY = float(os.getenv("MESSAGE_DELAY", "1.5"))
ENABLE_DOC = os.getenv("ENABLE_DOC", "false").lower() == "true"


async def handle_trigger(user_message: str, group_id: str) -> None:
    """
    Main orchestration function per INTERFACE-CONTRACT.md section 2.5.

    1. run_analysis() → list[AgentResponse]
    2. send_to_group() for each response with MESSAGE_DELAY between them
    3. (optional) generate_strategy_doc() when ENABLE_DOC=true
    4. (optional) update_risk_matrix() when ENABLE_DOC=true
    """
    print(f"[orchestrator] Trigger: {user_message!r} → group {group_id}")

    responses: list[AgentResponse] = run_analysis(user_message)

    for response in responses:
        ok = await send_to_group(
            group_id=group_id,
            message=response["content"],
            identity=response["role"],
        )
        if not ok:
            print(f"[orchestrator] Warning: send failed for {response['role']}")
        await asyncio.sleep(MESSAGE_DELAY)

    if ENABLE_DOC:
        await _post_analysis_outputs(responses, user_message)


async def _post_analysis_outputs(responses: list[AgentResponse], trigger: str) -> None:
    from src.outputs.doc_generator import generate_strategy_doc
    from src.outputs.table_writer import update_risk_matrix

    doc_title = f"AlphaDesk Strategy Report - {datetime.now().strftime('%Y-%m-%d %H:%M')}"
    try:
        doc_url = await generate_strategy_doc(responses, doc_title)
        print(f"[orchestrator] Doc: {doc_url}")
    except Exception as exc:
        print(f"[orchestrator] Doc generation failed: {exc}")

    risk_response = next(
        (r for r in responses if r["role"] == "risk_manager"), None
    )
    if risk_response:
        try:
            risk_data = {
                "timestamp": datetime.now().isoformat(),
                "trigger": trigger,
                "recommendation": risk_response["content"],
            }
            table_url = await update_risk_matrix(risk_data)
            print(f"[orchestrator] Risk matrix: {table_url}")
        except Exception as exc:
            print(f"[orchestrator] Risk matrix update failed: {exc}")
