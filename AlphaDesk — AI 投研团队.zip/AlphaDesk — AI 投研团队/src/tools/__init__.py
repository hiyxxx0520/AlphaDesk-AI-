from src.tools._crewai_compat import BaseTool
from src.tools.akshare_tool import AKShareTool
from src.tools.yfinance_tool import YFinanceTool


def get_all_tools() -> list[BaseTool]:
    """Return all available CrewAI tool instances."""
    return [
        AKShareTool(),
        YFinanceTool(),
    ]
