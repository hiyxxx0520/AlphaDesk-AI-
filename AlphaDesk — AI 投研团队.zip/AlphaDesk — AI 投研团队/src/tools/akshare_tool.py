import json
import os
import time
from datetime import date
from pathlib import Path

from pydantic import BaseModel, Field

from src.tools._crewai_compat import BaseTool


class AKShareQueryInput(BaseModel):
    query: str = Field(
        description=(
            "Query in the format 'action:parameter', for example "
            "'get_price:000001', 'get_index:000300', "
            "'get_macro:cpi', or 'get_forex:USDCNY'."
        )
    )


class AKShareTool(BaseTool):
    name: str = "AKShare Market Data"
    description: str = (
        "Fetch Chinese market data with AKShare. "
        "Use 'get_price:000001' for A-share prices, "
        "'get_index:000300' for index data, "
        "'get_macro:cpi' for China macro indicators, and "
        "'get_forex:USDCNY' for USD/CNY exchange rate data. "
        "Returns a JSON string or an error message."
    )
    args_schema: type[BaseModel] = AKShareQueryInput

    def _run(self, query: str) -> str:
        import akshare as ak

        if self._demo_mode():
            return self._get_demo_data(query)

        try:
            action, param = self._parse_query(query)

            if action == "get_price":
                df = self._run_with_retry(
                    lambda: ak.stock_zh_a_hist(
                        symbol=param,
                        period="daily",
                        start_date="20260101",
                        end_date=self._today(),
                        adjust="",
                    )
                )
                if df.empty:
                    return f"No data found for stock {param}"
                latest = df.tail(1).to_dict("records")[0]
                return self._to_json(
                    {
                        "symbol": param,
                        "date": str(latest.get("日期", "N/A")),
                        "close": self._as_float(latest.get("收盘")),
                        "change_pct": self._as_float(latest.get("涨跌幅")),
                        "volume": self._as_float(latest.get("成交量")),
                    }
                )

            if action == "get_index":
                df = self._run_with_retry(
                    lambda: ak.index_zh_a_hist(
                        symbol=param,
                        period="daily",
                        start_date="20260101",
                        end_date=self._today(),
                    )
                )
                if df.empty:
                    return f"No data found for index {param}"
                latest = df.tail(1).to_dict("records")[0]
                return self._to_json(
                    {
                        "index": param,
                        "date": str(latest.get("日期", "N/A")),
                        "close": self._as_float(latest.get("收盘")),
                        "change_pct": self._as_float(latest.get("涨跌幅")),
                    }
                )

            if action == "get_macro":
                indicator = param.lower()
                if indicator == "cpi":
                    df = ak.macro_china_cpi_monthly()
                elif indicator == "ppi":
                    df = ak.macro_china_ppi_yearly()
                elif indicator == "gdp":
                    df = ak.macro_china_gdp_yearly()
                else:
                    return f"Unsupported macro indicator: {param}. Supported: cpi, ppi, gdp"

                if df.empty:
                    return f"No macro data found for indicator {param}"
                latest = df.tail(1).to_dict("records")[0]
                return self._to_json(latest)

            if action == "get_forex":
                if param.upper() != "USDCNY":
                    return f"Unsupported forex pair: {param}. Supported: USDCNY"
                df = self._run_with_retry(ak.currency_boc_safe)
                if df.empty:
                    return "No forex data available"
                latest = df.tail(1).to_dict("records")[0]
                usd_rate = self._as_float(latest.get("美元"))
                return self._to_json(
                    {
                        "pair": "USDCNY",
                        "date": str(latest.get("日期", "N/A")),
                        "usd_cny": round(usd_rate / 100, 4) if usd_rate else 0.0,
                    }
                )

            return (
                f"Unsupported action: {action}. Supported: "
                "get_price, get_index, get_macro, get_forex"
            )
        except ValueError as exc:
            return f"Error: {exc}"
        except Exception as exc:
            return self._get_demo_data(query, error=str(exc))

    @staticmethod
    def _today() -> str:
        return date.today().strftime("%Y%m%d")

    @staticmethod
    def _demo_mode() -> bool:
        return os.getenv("DEMO_MODE", "false").lower() == "true"

    @staticmethod
    def _parse_query(query: str) -> tuple[str, str]:
        parts = query.strip().split(":", 1)
        if len(parts) != 2 or not parts[0].strip() or not parts[1].strip():
            raise ValueError(
                f"Invalid query format. Expected 'action:parameter', got '{query}'"
            )
        return parts[0].strip(), parts[1].strip()

    @staticmethod
    def _as_float(value: object) -> float:
        if value in (None, "", "N/A"):
            return 0.0
        return float(value)

    @staticmethod
    def _to_json(payload: object) -> str:
        return json.dumps(payload, ensure_ascii=False, default=str)

    @staticmethod
    def _run_with_retry(func, attempts: int = 3, delay: float = 1.0):
        last_error = None
        for attempt in range(attempts):
            try:
                return func()
            except Exception as exc:
                last_error = exc
                if attempt < attempts - 1:
                    time.sleep(delay)
        raise last_error

    def _get_demo_data(self, query: str, error: str | None = None) -> str:
        try:
            with self._demo_path().open("r", encoding="utf-8") as file:
                demo = json.load(file)
            payload = demo.get(query, demo.get("default", {"demo": True}))
            if error and isinstance(payload, dict):
                payload = {**payload, "demo_fallback": True, "error": error}
            return self._to_json(payload)
        except FileNotFoundError:
            return self._to_json({"demo": True, "message": "Demo data file not found"})

    @staticmethod
    def _demo_path() -> Path:
        return Path(__file__).resolve().parents[2] / "data" / "demo_data.json"
