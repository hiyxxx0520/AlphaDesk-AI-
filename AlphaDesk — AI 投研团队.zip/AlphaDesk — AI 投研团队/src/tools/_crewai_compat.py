import os
from pathlib import Path


def _ensure_crewai_home() -> None:
    project_root = Path(__file__).resolve().parents[2]
    current_home = Path(os.environ.get("HOME", str(Path.home())))
    default_storage = (
        current_home / "Library" / "Application Support" / project_root.name
    )

    try:
        default_storage.mkdir(parents=True, exist_ok=True)
    except OSError:
        sandbox_home = project_root / ".crewai_home"
        sandbox_home.mkdir(parents=True, exist_ok=True)
        os.environ["HOME"] = str(sandbox_home)
        (sandbox_home / "Library" / "Application Support").mkdir(
            parents=True, exist_ok=True
        )


_ensure_crewai_home()

from crewai.tools import BaseTool

__all__ = ["BaseTool"]
