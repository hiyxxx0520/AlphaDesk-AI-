import json
import os
from pathlib import Path

from pydantic import BaseModel, Field

from src.tools._crewai_compat import BaseTool


class YFinanceQueryInput(BaseModel):
    query: str = Field(
        description=(
            "Query in the format 'action:ticker', for example "
            "'get_price:AAPL' or 'get_info:SPY'."
        )
    )


class YFinanceTool(BaseTool):
    name: str = "yFinance Global Market Data"
    description: str = (
        "Fetch US stock and ETF data with yfinance. "
        "Use 'get_price:AAPL', 'get_price:SPY', 'get_price:TLT', or "
        "'get_info:AAPL'. Returns a JSON string or an error message."
    )
    args_schema: type[BaseModel] = YFinanceQueryInput

    def _run(self, query: str) -> str:
        import yfinance as yf

        if self._demo_mode():
            return self._get_demo_data(query)

        try:
            action, ticker_symbol = self._parse_query(query)
            ticker_symbol = ticker_symbol.upper()
            ticker = yf.Ticker(ticker_symbol)

            if action == "get_price":
                hist = ticker.history(period="2d", interval="1d", auto_adjust=False)
                if hist.empty:
                    return f"No price data found for {ticker_symbol}"
                latest_close = float(hist["Close"].iloc[-1])
                prev_close = (
                    float(hist["Close"].iloc[-2])
                    if len(hist.index) > 1
                    else latest_close
                )
                change_pct = (
                    ((latest_close - prev_close) / prev_close) * 100
                    if prev_close
                    else 0.0
                )
                return self._to_json(
                    {
                        "ticker": ticker_symbol,
                        "price": round(latest_close, 2),
                        "change_pct": round(change_pct, 2),
                        "currency": "USD",
                    }
                )

            if action == "get_info":
                info = ticker.info
                if not info:
                    return f"No company info found for {ticker_symbol}"
                return self._to_json(
                    {
                        "ticker": ticker_symbol,
                        "name": info.get("longName", "N/A"),
                        "sector": info.get("sector", "N/A"),
                        "pe_ratio": info.get("trailingPE"),
                        "market_cap": info.get("marketCap"),
                        "52w_high": info.get("fiftyTwoWeekHigh"),
                        "52w_low": info.get("fiftyTwoWeekLow"),
                    }
                )

            return f"Unsupported action: {action}. Supported: get_price, get_info"
        except ValueError as exc:
            return f"Error: {exc}"
        except Exception as exc:
            return f"yfinance error for query '{query}': {exc}"

    @staticmethod
    def _demo_mode() -> bool:
        return os.getenv("DEMO_MODE", "false").lower() == "true"

    @staticmethod
    def _parse_query(query: str) -> tuple[str, str]:
        parts = query.strip().split(":", 1)
        if len(parts) != 2 or not parts[0].strip() or not parts[1].strip():
            raise ValueError(
                f"Invalid query format. Expected 'action:ticker', got '{query}'"
            )
        return parts[0].strip(), parts[1].strip()

    @staticmethod
    def _to_json(payload: object) -> str:
        return json.dumps(payload, ensure_ascii=False, default=str)

    def _get_demo_data(self, query: str) -> str:
        try:
            with self._demo_path().open("r", encoding="utf-8") as file:
                demo = json.load(file)
            fallback = demo.get(
                "yf_default",
                {"demo": True, "ticker": "AAPL", "price": 172.5, "change_pct": -0.8},
            )
            return self._to_json(demo.get(query, fallback))
        except FileNotFoundError:
            return self._to_json(
                {"demo": True, "ticker": "AAPL", "price": 172.5, "change_pct": -0.8}
            )

    @staticmethod
    def _demo_path() -> Path:
        return Path(__file__).resolve().parents[2] / "data" / "demo_data.json"
