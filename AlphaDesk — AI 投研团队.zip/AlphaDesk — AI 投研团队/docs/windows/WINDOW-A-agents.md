# WINDOW-A — CrewAI 多 Agent 核心

> **在开始之前**：先读 `CLAUDE.md` 和 `docs/INTERFACE-CONTRACT.md`，全部理解后再动手。

---

## 1. 模块职责

用 CrewAI Sequential Process 实现 4 个投研 Agent（Macro Analyst / Sector Analyst / Risk Manager / Chief Strategist），暴露 `run_analysis()` 函数供 Orchestrator 调用。本模块纯 Python，无飞书依赖，可完全独立运行。

**产出目录**：`src/agents/`  
**Git 分支**：`agents-dev`（worktree 在 `../alphadesk-agents/`）

---

## 2. 基座仓库

### 主要参考：botextractai/ai-crewai-multi-agent

这个项目已实现金融分析场景的多 Agent 协作（SEC 报告分析）。我们的改造路径：

| 原始文件 | 改造动作 |
|---------|---------|
| `agents.py` | 把 3 个 SEC 分析师 → 改为我们的 4 个投研角色 |
| `tasks.py` | 把 SEC 分析任务 → 改为投研分析任务（含辩论指令） |
| `crew.py` | 保留 Sequential Process，改造 `run_analysis()` 返回值 |
| `tools/sec_tools.py` | **忽略**，替换为 Window C 提供的 AKShare/yfinance Tools |
| `main.py` | 参考入口写法，最终在 `src/agents/crew.py` 中整合 |

### 辅助参考：wyne1/financial-analyst-crewai

这个项目的 4 Agent 设计与我们高度吻合（Data Analyst / Trading Strategy Developer / Trade Advisor / Risk Advisor），参考它的 Agent goal/backstory 写法。

---

## 3. 环境变量需求

```bash
# .env 文件中必须有以下字段（窗口 A 最小集）
DEEPSEEK_API_KEY=sk-xxxx          # 必须，LLM API Key
LLM_BASE_URL=https://api.deepseek.com  # 可选，默认值即可
LLM_MODEL=deepseek-chat            # 可选，默认值即可
DEMO_MODE=false                    # 可选，true 时 Tools 返回缓存数据
```

---

## 4. 依赖安装

```bash
# 在项目根目录执行
pip install crewai crewai-tools python-dotenv

# 如果 crewai 安装失败（依赖冲突），尝试：
pip install "crewai[tools]"

# 验证安装
python -c "import crewai; print(crewai.__version__)"
# 预期输出：0.x.x（任何版本均可）
```

---

## 5. 逐步任务列表

---

### Task 0：克隆基座仓库，跑通原始示例

**目的**：确认 CrewAI 框架本身能正常工作，再开始改造。

```bash
# Step A：克隆 botextractai 参考仓库到临时位置
git clone https://github.com/botextractai/ai-crewai-multi-agent /tmp/botextractai-ref
cd /tmp/botextractai-ref

# Step B：查看文件结构，了解代码组织
ls -la
cat agents.py   # 了解 Agent 定义方式
cat tasks.py    # 了解 Task 定义方式
cat crew.py     # 了解 Crew 编排方式

# Step C：安装原始项目依赖
pip install -r requirements.txt

# Step D：查看原始项目需要什么环境变量
cat .env.example  # 或 grep -r "os.getenv" .

# Step E：用 DeepSeek 替换 OpenAI（botextractai 默认用 OpenAI）
# 在 /tmp/botextractai-ref 创建 .env 文件：
echo "OPENAI_API_KEY=sk-placeholder" > .env
# 同时在 crew.py 或 agents.py 中找到 LLM 初始化的地方，改为 DeepSeek：
# llm = LLM(model="deepseek-chat", base_url="https://api.deepseek.com", api_key=os.getenv("DEEPSEEK_API_KEY"))

# Step F：跑通示例（可能需要修改 LLM 配置）
python main.py
```

**验证标准**：终端出现 Agent 的分析输出（哪怕是 SEC 分析也行），无 import 错误，无 API 错误。

```
# 预期看到类似输出：
> Entering new CrewAgentExecutor chain...
...
> Finished chain.
Final Answer: [某种金融分析文本]
```

---

### Task 1：搭建项目基础结构

**目的**：在项目根目录创建 Python 包结构。

```bash
# 在项目根目录（飞书AI校园挑战赛/）执行
cd "/Users/yyy/Desktop/飞书AI校园挑战赛"

# 创建目录结构
mkdir -p src/agents src/tools src/feishu src/outputs config data tests

# 创建 __init__.py
touch src/__init__.py src/agents/__init__.py src/tools/__init__.py
touch src/feishu/__init__.py src/outputs/__init__.py
```

创建 `pyproject.toml`（内容如下）：

```toml
[build-system]
requires = ["setuptools>=68"]
build-backend = "setuptools.backends.legacy:build"

[project]
name = "alphadesk"
version = "0.1.0"
requires-python = ">=3.11"
dependencies = [
    "crewai",
    "crewai-tools",
    "akshare",
    "yfinance",
    "python-dotenv",
    "lark-oapi",
]
```

创建 `requirements.txt`：

```
crewai
crewai-tools
akshare
yfinance
python-dotenv
lark-oapi
```

创建 `config/settings.py`：

```python
# config/settings.py
import os
from dotenv import load_dotenv

load_dotenv()

# LLM 配置
LLM_API_KEY  = os.getenv("DEEPSEEK_API_KEY", "")
LLM_BASE_URL = os.getenv("LLM_BASE_URL", "https://api.deepseek.com")
LLM_MODEL    = os.getenv("LLM_MODEL", "deepseek-chat")

# 飞书配置
FEISHU_GROUP_ID  = os.getenv("FEISHU_GROUP_ID", "")
FEISHU_MOCK      = os.getenv("FEISHU_MOCK", "false").lower() == "true"

# 模式控制
DEMO_MODE = os.getenv("DEMO_MODE", "false").lower() == "true"
```

**验证标准**：

```bash
python -c "from config.settings import LLM_MODEL; print(LLM_MODEL)"
# 预期输出：deepseek-chat
```

---

### Task 2：创建 AgentResponse 类型定义

**目的**：实现接口契约中定义的 TypedDict，所有模块共用。

创建 `src/agents/types.py`（**完全按照 INTERFACE-CONTRACT.md 第 1 节**）：

```python
# src/agents/types.py
from typing import TypedDict, Literal

RoleType = Literal[
    "macro_analyst",
    "sector_analyst",
    "risk_manager",
    "chief_strategist"
]

TagType = Literal[
    "ALERT",
    "DISAGREE",
    "COUNTER",
    "RISK",
    "ACTION"
]

class AgentResponse(TypedDict):
    role:    RoleType
    content: str
    tags:    list[TagType]
```

**验证标准**：

```bash
python -c "from src.agents.types import AgentResponse, RoleType; print('types OK')"
# 预期输出：types OK
```

---

### Task 3：创建 LLM 配置模块

**目的**：统一管理 DeepSeek LLM 实例，供所有 Agent 复用。

创建 `src/agents/llm_config.py`：

```python
# src/agents/llm_config.py
from crewai import LLM
from config.settings import LLM_API_KEY, LLM_BASE_URL, LLM_MODEL

def get_llm() -> LLM:
    """返回配置好的 DeepSeek LLM 实例。"""
    return LLM(
        model=LLM_MODEL,
        base_url=LLM_BASE_URL,
        api_key=LLM_API_KEY,
    )
```

**验证标准**：

```bash
python -c "from src.agents.llm_config import get_llm; llm = get_llm(); print(f'LLM ready: {llm.model}')"
# 预期输出：LLM ready: deepseek-chat
```

---

### Task 4：创建 4 个 Agent 定义

**目的**：基于 botextractai 的 `agents.py` 模式，创建我们的 4 个投研角色。

**参照步骤**：
1. 打开 `/tmp/botextractai-ref/agents.py`
2. 注意 `Agent(role=..., goal=..., backstory=..., llm=..., tools=..., verbose=True)` 的构造方式
3. 在此基础上，创建 4 个角色

创建 `src/agents/agents.py`：

```python
# src/agents/agents.py
from crewai import Agent
from src.agents.llm_config import get_llm

def get_macro_analyst(tools: list = []) -> Agent:
    return Agent(
        role="Senior Macro Analyst",
        goal=(
            "Monitor and analyze macroeconomic signals including central bank policies, "
            "yield curve movements, inflation data, geopolitical events, and cross-asset "
            "correlations. Identify systemic risks and flag actionable macro themes."
        ),
        backstory=(
            "You are a senior macro analyst with 15 years of experience at a top-tier "
            "investment bank. You specialize in top-down analysis and have a track record "
            "of calling major macro turning points. You are cautious, data-driven, and "
            "always focused on systemic risks. You speak in specific numbers and cite "
            "exact data points. You use [ALERT] tag for urgent developments."
        ),
        tools=tools,
        llm=get_llm(),
        verbose=True,
        max_iter=3,
    )

def get_sector_analyst(tools: list = []) -> Agent:
    return Agent(
        role="Sector Specialist and Equity Research Analyst",
        goal=(
            "Provide bottom-up, sector-specific analysis that challenges or refines "
            "the macro view. Focus on industry dynamics, company fundamentals, relative "
            "valuations, and what is already priced in vs genuine new risk."
        ),
        backstory=(
            "You are a contrarian sector analyst known for challenging consensus views. "
            "You cover 6 sectors deeply and always distinguish between what's already "
            "priced in and what represents genuine surprise. You cite specific tickers, "
            "P/E ratios, and sector ETFs. You frequently DISAGREE with macro analysts "
            "when their view is too broad. You use [DISAGREE] or [COUNTER] tags."
        ),
        tools=tools,
        llm=get_llm(),
        verbose=True,
        max_iter=3,
    )

def get_risk_manager(tools: list = []) -> Agent:
    return Agent(
        role="Portfolio Risk Manager",
        goal=(
            "Quantify portfolio risk exposure, run stress tests, estimate drawdowns, "
            "and provide concrete hedging recommendations with specific position sizes."
        ),
        backstory=(
            "You are a quantitative risk manager who speaks exclusively in numbers. "
            "You calculate VaR, duration sensitivity, drawdown estimates, and correlation "
            "breakdowns. You always lead with the downside scenario and provide a specific, "
            "actionable risk mitigation recommendation. You use [RISK] tag for alerts and "
            "always end with a concrete recommended action."
        ),
        tools=tools,
        llm=get_llm(),
        verbose=True,
        max_iter=3,
    )

def get_chief_strategist(tools: list = []) -> Agent:
    return Agent(
        role="Chief Investment Strategist",
        goal=(
            "Synthesize all team perspectives — macro, sector, and risk — into a coherent, "
            "actionable investment strategy. Resolve disagreements and produce a numbered "
            "action plan."
        ),
        backstory=(
            "You are the Chief Investment Strategist who has final decision authority. "
            "You are decisive and diplomatic, skilled at synthesizing conflicting views. "
            "You acknowledge each team member's key insight, clearly state where you "
            "agree/disagree, and produce a numbered action plan (3-5 specific steps). "
            "You always mention that a full report is being generated. You use [ACTION] tag."
        ),
        tools=tools,
        llm=get_llm(),
        verbose=True,
        max_iter=3,
    )
```

**验证标准**：

```bash
python -c "
from src.agents.agents import get_macro_analyst
agent = get_macro_analyst()
print(f'Agent created: {agent.role}')
"
# 预期输出：Agent created: Senior Macro Analyst
```

---

### Task 5：创建 4 个 Task 定义

**目的**：基于 botextractai 的 `tasks.py` 模式，定义每个 Agent 的任务（含辩论指令）。

**关键设计**：每个后续 Task 的 `description` 中必须包含"参考前面的分析"的指令，实现辩论效果。Task 的 `context` 参数传入前置任务，CrewAI 会自动注入前置输出。

创建 `src/agents/tasks.py`：

```python
# src/agents/tasks.py
from crewai import Task, Agent

def get_macro_task(agent: Agent, trigger_event: str, market_data: dict | None = None) -> Task:
    market_context = f"\nAvailable market data: {market_data}" if market_data else ""
    return Task(
        description=(
            f"Analyze the following market event from a top-down macro perspective:\n\n"
            f"EVENT: {trigger_event}{market_context}\n\n"
            f"Instructions:\n"
            f"- Start with [ALERT] if this is an urgent development\n"
            f"- Cite specific data points (yield levels, rate probabilities, CPI numbers)\n"
            f"- Flag which asset classes are most affected\n"
            f"- Tag team members who need to weigh in: @Sector @Risk\n"
            f"- Keep response to 3-5 sentences maximum"
        ),
        expected_output=(
            "A concise macro analysis (3-5 sentences) starting with [ALERT] if urgent, "
            "citing specific data points, identifying affected asset classes."
        ),
        agent=agent,
    )

def get_sector_task(agent: Agent, trigger_event: str, context_tasks: list) -> Task:
    return Task(
        description=(
            f"The Macro Analyst has just delivered their assessment of: {trigger_event}\n\n"
            f"Your job is to provide a sector-specific counter-perspective:\n"
            f"- Read the Macro Analyst's analysis above\n"
            f"- CHALLENGE at least one key assumption with bottom-up evidence\n"
            f"- Cite specific tickers, P/E ratios, or sector ETFs\n"
            f"- Distinguish between what is already priced in vs genuine new risk\n"
            f"- Use [DISAGREE] or [COUNTER] tag if challenging the macro view\n"
            f"- Keep response to 3-5 sentences maximum"
        ),
        expected_output=(
            "A sector-specific analysis (3-5 sentences) that challenges or refines the macro view, "
            "citing specific securities or sector data."
        ),
        agent=agent,
        context=context_tasks,
    )

def get_risk_task(agent: Agent, trigger_event: str, context_tasks: list) -> Task:
    return Task(
        description=(
            f"The team has analyzed: {trigger_event}\n\n"
            f"Run a quantitative risk assessment based on all previous analyses:\n"
            f"- Calculate estimated portfolio sensitivity (use realistic numbers)\n"
            f"- Estimate drawdown scenario under stress conditions\n"
            f"- Provide a specific hedging recommendation with position sizing\n"
            f"- Use [RISK] tag for risk alerts\n"
            f"- Reference risk metrics: VaR, duration sensitivity, max drawdown\n"
            f"- End with ONE specific, actionable recommendation\n"
            f"- Keep response to 3-5 sentences maximum"
        ),
        expected_output=(
            "A quantitative risk assessment (3-5 sentences) with specific numbers, "
            "starting with [RISK], ending with one concrete recommendation."
        ),
        agent=agent,
        context=context_tasks,
    )

def get_strategy_task(agent: Agent, trigger_event: str, context_tasks: list) -> Task:
    return Task(
        description=(
            f"All team members have weighed in on: {trigger_event}\n\n"
            f"As Chief Strategist, synthesize all perspectives into a final decision:\n"
            f"- Acknowledge each team member's key insight (1 sentence each)\n"
            f"- State your overall assessment\n"
            f"- Produce a numbered action plan with 3-5 specific steps\n"
            f"- Mention that a full strategy report is being generated to Feishu Docs\n"
            f"- Use [ACTION] tag\n"
            f"- Keep response to 4-6 sentences maximum"
        ),
        expected_output=(
            "A strategic synthesis (4-6 sentences) with [ACTION] tag, acknowledging all team inputs, "
            "and a numbered action plan of 3-5 specific steps."
        ),
        agent=agent,
        context=context_tasks,
    )
```

**验证标准**：

```bash
python -c "
from src.agents.agents import get_macro_analyst
from src.agents.tasks import get_macro_task
agent = get_macro_analyst()
task = get_macro_task(agent, 'Test event')
print(f'Task created: {task.description[:50]}...')
"
# 预期输出：Task created: Analyze the following market event...
```

---

### Task 6：创建 crew.py，暴露 run_analysis()

**目的**：组装 Crew，实现 Sequential Process，将 CrewAI 输出解析为 `list[AgentResponse]`。

创建 `src/agents/crew.py`：

```python
# src/agents/crew.py
import re
from crewai import Crew, Process
from src.agents.types import AgentResponse, RoleType, TagType
from src.agents.agents import (
    get_macro_analyst,
    get_sector_analyst,
    get_risk_manager,
    get_chief_strategist,
)
from src.agents.tasks import (
    get_macro_task,
    get_sector_task,
    get_risk_task,
    get_strategy_task,
)

# 懒加载 Tools（避免 Window C 未完成时报错）
def _load_tools() -> list:
    try:
        from src.tools import get_all_tools
        return get_all_tools()
    except ImportError:
        return []  # Window C 未完成时，使用空工具列表

def _extract_tags(content: str) -> list[TagType]:
    """从消息内容中提取 [TAG] 标签。"""
    valid_tags = {"ALERT", "DISAGREE", "COUNTER", "RISK", "ACTION"}
    found = re.findall(r'\[([A-Z]+)\]', content)
    return [t for t in found if t in valid_tags]  # type: ignore

def run_analysis(
    trigger_event: str,
    market_data: dict | None = None
) -> list[AgentResponse]:
    """
    触发一轮完整的 4-Agent 投研分析。
    接口定义见 docs/INTERFACE-CONTRACT.md 第 2.1 节。
    """
    tools = _load_tools()

    # 初始化 Agents
    macro_agent    = get_macro_analyst(tools)
    sector_agent   = get_sector_analyst(tools)
    risk_agent     = get_risk_manager(tools)
    strategy_agent = get_chief_strategist(tools)

    # 定义 Tasks（Sequential：每个 Task 的 context 包含前置 Task）
    macro_task  = get_macro_task(macro_agent, trigger_event, market_data)
    sector_task = get_sector_task(sector_agent, trigger_event, [macro_task])
    risk_task   = get_risk_task(risk_agent, trigger_event, [macro_task, sector_task])
    strategy_task = get_strategy_task(strategy_agent, trigger_event,
                                       [macro_task, sector_task, risk_task])

    # 创建并运行 Crew
    crew = Crew(
        agents=[macro_agent, sector_agent, risk_agent, strategy_agent],
        tasks=[macro_task, sector_task, risk_task, strategy_task],
        process=Process.sequential,
        verbose=True,
    )

    crew_output = crew.kickoff()

    # 解析输出 → list[AgentResponse]
    # CrewAI Sequential 的 task_outputs 按顺序对应每个 Task
    role_order: list[RoleType] = [
        "macro_analyst", "sector_analyst", "risk_manager", "chief_strategist"
    ]

    responses: list[AgentResponse] = []
    for i, task_output in enumerate(crew_output.tasks_output):
        content = str(task_output.raw)
        responses.append(AgentResponse(
            role=role_order[i],
            content=content,
            tags=_extract_tags(content),
        ))

    return responses


if __name__ == "__main__":
    # 快速测试
    import json
    results = run_analysis(
        trigger_event="Fed released hawkish FOMC minutes. 10Y yield jumped to 4.8%.",
        market_data={"sp500_change_pct": -0.8, "us_10y_yield": 4.8, "vix": 18.5}
    )
    print("\n=== ANALYSIS RESULTS ===")
    for r in results:
        print(f"\n[{r['role'].upper()}] tags={r['tags']}")
        print(r['content'])
    print("\n=== JSON OUTPUT ===")
    print(json.dumps(results, indent=2))
```

**验证标准**：

```bash
# 方法 1：直接运行（需要有效的 DEEPSEEK_API_KEY）
python -m src.agents.crew

# 预期输出：
# === ANALYSIS RESULTS ===
# [MACRO_ANALYST] tags=['ALERT']
# [ALERT] Fed minutes show hawkish pivot...
# [SECTOR_ANALYST] tags=['DISAGREE']
# ...
# === JSON OUTPUT ===
# [{"role": "macro_analyst", "content": "...", "tags": ["ALERT"]}, ...]
```

```bash
# 方法 2：仅测试 import（无需 API Key）
python -c "from src.agents.crew import run_analysis; print('crew.py import OK')"
# 预期输出：crew.py import OK
```

---

### Task 7：编写独立测试脚本（Mock 模式）

**目的**：允许在无 DeepSeek API Key 时验证代码结构。

创建 `tests/test_agents_mock.py`：

```python
# tests/test_agents_mock.py
"""在没有 API Key 时验证 crew.py 的代码结构和类型正确性。"""
from src.agents.types import AgentResponse

def test_mock_response_structure():
    """验证 AgentResponse TypedDict 结构正确。"""
    mock_responses: list[AgentResponse] = [
        {"role": "macro_analyst",    "content": "[ALERT] Test macro signal.", "tags": ["ALERT"]},
        {"role": "sector_analyst",   "content": "[DISAGREE] Counter view.",   "tags": ["DISAGREE"]},
        {"role": "risk_manager",     "content": "[RISK] Drawdown -8%.",       "tags": ["RISK"]},
        {"role": "chief_strategist", "content": "[ACTION] Step 1: ...",       "tags": ["ACTION"]},
    ]
    assert len(mock_responses) == 4
    for r in mock_responses:
        assert "role" in r
        assert "content" in r
        assert "tags" in r
    print("✅ AgentResponse structure test passed")

def test_role_coverage():
    """验证 4 个角色都有定义。"""
    from src.agents.agents import (
        get_macro_analyst, get_sector_analyst,
        get_risk_manager, get_chief_strategist
    )
    agents = [get_macro_analyst(), get_sector_analyst(),
              get_risk_manager(), get_chief_strategist()]
    assert len(agents) == 4
    print("✅ All 4 agents instantiated successfully")

if __name__ == "__main__":
    test_mock_response_structure()
    test_role_coverage()
    print("\n✅ All mock tests passed")
```

**验证标准**：

```bash
python tests/test_agents_mock.py
# 预期输出：
# ✅ AgentResponse structure test passed
# ✅ All 4 agents instantiated successfully
# ✅ All mock tests passed
```

---

## 6. 本模块暴露的接口

（与 `docs/INTERFACE-CONTRACT.md` 第 2.1 节完全一致，不得修改签名）

```python
# src/agents/crew.py
def run_analysis(
    trigger_event: str,
    market_data: dict | None = None
) -> list[AgentResponse]: ...

# src/agents/types.py（供其他模块 import）
class AgentResponse(TypedDict): ...
RoleType = Literal[...]
TagType  = Literal[...]
```

---

## 7. 本模块依赖的外部接口（当前用 Mock）

| 依赖 | 来源窗口 | Mock 方案 |
|------|---------|---------|
| `get_all_tools() -> list[BaseTool]` | 窗口 C | `crew.py` 中 `_load_tools()` 捕获 ImportError，返回 `[]`（空工具列表） |

> 当 Window C 完成后，只需确保 `src/tools/__init__.py` 正确导出 `get_all_tools`，Window A 无需任何改动。

---

## 8. 基座仓库中需要忽略的部分

以下文件/功能来自 botextractai，**不需要复制或修改**：

| 文件/功能 | 原因 |
|---------|------|
| `tools/sec_tools.py` | 专用于 SEC-API，替换为 Window C 的 AKShare 工具 |
| `tools/search_tools.py` | SEC 搜索工具，不需要 |
| `.env`（原仓库的） | 会包含别人的 API Key，用我们自己的 |
| `requirements.txt`（原仓库的） | 用我们自己的 |
| `README.md`（原仓库的） | 用我们自己写的 |

**参考但不复制的内容**：
- 原 `agents.py` 的 Agent 构造方式（看结构，写新的）
- 原 `tasks.py` 的 Task 传参方式（看 `context` 如何传递）
- 原 `crew.py` 的 `Process.sequential` 用法

---

## 完成标准（Checklist）

在进行窗口 E 集成前，确认以下全部通过：

- [ ] `python -c "from src.agents.crew import run_analysis; print('OK')"` 无报错
- [ ] `python tests/test_agents_mock.py` 全部通过
- [ ] `python -m src.agents.crew`（需要 API Key）输出 4 条 AgentResponse，包含 ALERT/DISAGREE/RISK/ACTION 标签
- [ ] 返回值是 `list[AgentResponse]`，每项包含 `role`, `content`, `tags` 字段
- [ ] 无硬编码的 API Key（全部从 `.env` 读取）
