# WINDOW-C — 金融数据工具层

> **在开始之前**：先读 `CLAUDE.md` 和 `docs/INTERFACE-CONTRACT.md`，全部理解后再动手。

---

## 1. 模块职责

将 AKShare（A 股 + 中国宏观数据）和 yfinance（美股 + 全球市场）封装为 CrewAI Tool，供窗口 A 的 Agents 调用。同时提供离线 Demo 数据缓存，确保在 API 不稳定时 Demo 可正常运行。

**产出目录**：`src/tools/`  
**Git 分支**：`tools-dev`（worktree 在 `../alphadesk-tools/`）

---

## 2. 基座仓库

### 参照：botextractai/ai-crewai-multi-agent 的 tools/ 目录

不是从零写 Tool，而是参照 botextractai 封装 SEC-API Tool 的相同模式：

```
botextractai 的 tools/sec_tools.py
    ↓ 参照封装模式
我们的 tools/akshare_tool.py
我们的 tools/yfinance_tool.py
```

**参照要点**：
- `BaseTool` 的子类定义方式（`name`, `description`, `_run(query: str) -> str`）
- Tool 的 `description` 写法（CrewAI Agent 靠这段文字决定何时调用 Tool）
- 错误处理方式（返回错误字符串，而非抛出异常）

```bash
# 克隆参考仓库（如果 Window A 没有克隆过的话）
git clone https://github.com/botextractai/ai-crewai-multi-agent /tmp/botextractai-ref

# 重点查看
cat /tmp/botextractai-ref/tools/sec_tools.py
# 注意：BaseTool 的 import 路径、name/description 字段、_run 方法签名
```

---

## 3. 环境变量需求

```bash
# .env 文件中（窗口 C 最小集）
DEMO_MODE=false   # 可选，true = 返回 data/demo_data.json 中的缓存数据

# AKShare 和 yfinance 默认不需要 API Key
# 如果网络需要代理（日本服务器访问 A 股数据）：
HTTP_PROXY=http://127.0.0.1:7890
HTTPS_PROXY=http://127.0.0.1:7890
```

---

## 4. 依赖安装

```bash
pip install akshare yfinance crewai python-dotenv

# 验证 AKShare
python -c "import akshare as ak; print(f'AKShare {ak.__version__} OK')"

# 验证 yfinance
python -c "import yfinance as yf; print('yfinance OK')"

# 验证 CrewAI BaseTool 可用
python -c "from crewai.tools import BaseTool; print('CrewAI BaseTool OK')"
```

---

## 5. 逐步任务列表

---

### Task 0：验证数据源可用性

**目的**：在写 Tool 之前，先确认 AKShare 和 yfinance 能在当前网络环境下正常获取数据。

```python
# 在项目根目录运行以下测试（保存为 /tmp/test_datasources.py）

import akshare as ak
import yfinance as yf
import json

print("=== Testing AKShare ===")

# Test 1: A 股股票数据（平安银行）
try:
    df = ak.stock_zh_a_hist(
        symbol="000001",
        period="daily",
        start_date="20260410",
        end_date="20260416",
        adjust=""
    )
    print(f"✅ A股数据 OK: {df.tail(1).to_dict('records')}")
except Exception as e:
    print(f"❌ A股数据失败: {e}")

# Test 2: 沪深300指数
try:
    df = ak.index_zh_a_hist(symbol="000300", period="daily",
                             start_date="20260410", end_date="20260416")
    print(f"✅ 指数数据 OK: {df.tail(1).to_dict('records')}")
except Exception as e:
    print(f"❌ 指数数据失败: {e}")

# Test 3: 汇率
try:
    df = ak.currency_boc_safe(symbol="美元")
    print(f"✅ 汇率数据 OK: 最新 = {df.tail(1).to_dict('records')}")
except Exception as e:
    print(f"❌ 汇率数据失败: {e}")

print("\n=== Testing yfinance ===")

# Test 4: 美股（苹果）
try:
    ticker = yf.Ticker("AAPL")
    info = ticker.info
    price = info.get("currentPrice") or info.get("regularMarketPrice")
    print(f"✅ 美股数据 OK: AAPL = ${price}")
except Exception as e:
    print(f"❌ 美股数据失败: {e}")

# Test 5: ETF（标普500 ETF）
try:
    ticker = yf.Ticker("SPY")
    hist = ticker.history(period="2d")
    print(f"✅ ETF数据 OK: SPY last = {hist['Close'].iloc[-1]:.2f}")
except Exception as e:
    print(f"❌ ETF数据失败: {e}")
```

```bash
python /tmp/test_datasources.py
```

**验证标准**：至少 3/5 的测试输出 ✅。如果全部失败，检查网络代理配置。记录哪些 API 可用，后续 Task 中针对可用 API 实现 Tool，不可用的用 Demo 数据替代。

---

### Task 1：研究 botextractai 的 Tool 封装模式

**目的**：理解 CrewAI BaseTool 的正确封装方式，再开始写。

```bash
cat /tmp/botextractai-ref/tools/sec_tools.py
```

**预期看到类似以下结构**：

```python
from crewai.tools import BaseTool
from pydantic import BaseModel, Field

class SECSearchInput(BaseModel):
    query: str = Field(description="The search query")

class SECSearchTool(BaseTool):
    name: str = "SEC Search"
    description: str = "Search SEC filings..."
    args_schema: type[BaseModel] = SECSearchInput

    def _run(self, query: str) -> str:
        # 实际调用 API
        ...
        return result_string
```

> **注意**：不同版本的 CrewAI 可能有不同的 BaseTool API。以实际 clone 后看到的代码为准。如果 botextractai 的写法和当前 crewai 版本不兼容，查阅 `crewai.tools.BaseTool` 的最新文档。

---

### Task 2：创建 AKShare Tool

**目的**：封装 AKShare 为 CrewAI Tool，支持多种查询类型。

创建 `src/tools/akshare_tool.py`：

```python
# src/tools/akshare_tool.py
import os
import json
from crewai.tools import BaseTool

class AKShareTool(BaseTool):
    name: str = "AKShare Market Data"
    description: str = (
        "Fetch real-time Chinese market data using AKShare. "
        "Supports the following query formats:\n"
        "  - 'get_price:000001' → A-share stock price (6-digit code)\n"
        "  - 'get_index:000300' → Index data (e.g., CSI 300)\n"
        "  - 'get_macro:cpi' → China macro data (cpi, ppi, gdp)\n"
        "  - 'get_forex:USDCNY' → Exchange rate\n"
        "Returns a JSON string with the data or an error message."
    )

    def _run(self, query: str) -> str:
        """执行 AKShare 查询，返回 JSON 字符串结果。"""
        import akshare as ak

        # 检查是否使用 Demo 数据
        if os.getenv("DEMO_MODE", "false").lower() == "true":
            return self._get_demo_data(query)

        try:
            parts = query.strip().split(":", 1)
            if len(parts) != 2:
                return f"Error: Invalid query format. Expected 'action:parameter', got '{query}'"

            action, param = parts[0].strip(), parts[1].strip()

            if action == "get_price":
                # A 股个股最新行情
                df = ak.stock_zh_a_hist(
                    symbol=param,
                    period="daily",
                    start_date="20260401",
                    end_date="20260416",
                    adjust=""
                )
                if df.empty:
                    return f"No data found for stock {param}"
                latest = df.tail(1).to_dict("records")[0]
                return json.dumps({
                    "symbol": param,
                    "date": str(latest.get("日期", "N/A")),
                    "close": float(latest.get("收盘", 0)),
                    "change_pct": float(latest.get("涨跌幅", 0)),
                    "volume": float(latest.get("成交量", 0)),
                }, ensure_ascii=False)

            elif action == "get_index":
                df = ak.index_zh_a_hist(
                    symbol=param,
                    period="daily",
                    start_date="20260401",
                    end_date="20260416"
                )
                if df.empty:
                    return f"No data found for index {param}"
                latest = df.tail(1).to_dict("records")[0]
                return json.dumps({
                    "index": param,
                    "date": str(latest.get("日期", "N/A")),
                    "close": float(latest.get("收盘", 0)),
                    "change_pct": float(latest.get("涨跌幅", 0)),
                }, ensure_ascii=False)

            elif action == "get_macro":
                param_lower = param.lower()
                if param_lower == "cpi":
                    df = ak.macro_china_cpi_monthly()
                    latest = df.tail(1).to_dict("records")[0]
                    return json.dumps(latest, ensure_ascii=False, default=str)
                elif param_lower == "ppi":
                    df = ak.macro_china_ppi_monthly()
                    latest = df.tail(1).to_dict("records")[0]
                    return json.dumps(latest, ensure_ascii=False, default=str)
                else:
                    return f"Unsupported macro indicator: {param}. Supported: cpi, ppi"

            elif action == "get_forex":
                df = ak.currency_boc_safe(symbol="美元")
                if df.empty:
                    return "No forex data available"
                latest = df.tail(1).to_dict("records")[0]
                return json.dumps(latest, ensure_ascii=False, default=str)

            else:
                return f"Unsupported action: {action}. Supported: get_price, get_index, get_macro, get_forex"

        except Exception as e:
            return f"AKShare error for query '{query}': {str(e)}"

    def _get_demo_data(self, query: str) -> str:
        """从 data/demo_data.json 返回预缓存数据。"""
        try:
            with open("data/demo_data.json", "r", encoding="utf-8") as f:
                demo = json.load(f)
            return json.dumps(demo.get(query, demo.get("default", {"demo": True})),
                              ensure_ascii=False)
        except FileNotFoundError:
            return json.dumps({"demo": True, "message": "Demo data file not found"})
```

**验证标准**：

```bash
python -c "
from src.tools.akshare_tool import AKShareTool
tool = AKShareTool()
print(f'Tool name: {tool.name}')
result = tool._run('get_price:000001')
print(f'Result: {result}')
"
# 预期输出：Tool name: AKShare Market Data
# Result: {"symbol": "000001", "date": "...", "close": ..., ...}
```

---

### Task 3：创建 yfinance Tool

**目的**：封装 yfinance 为 CrewAI Tool，支持美股查询。

创建 `src/tools/yfinance_tool.py`：

```python
# src/tools/yfinance_tool.py
import os
import json
from crewai.tools import BaseTool

class YFinanceTool(BaseTool):
    name: str = "yFinance Global Market Data"
    description: str = (
        "Fetch real-time global market data using yfinance. "
        "Supports the following query formats:\n"
        "  - 'get_price:AAPL' → US stock or ETF price\n"
        "  - 'get_price:SPY' → S&P 500 ETF\n"
        "  - 'get_price:TLT' → 20Y Treasury Bond ETF\n"
        "  - 'get_price:GLD' → Gold ETF\n"
        "  - 'get_info:AAPL' → Company info including P/E ratio\n"
        "Use US stock ticker symbols (e.g., AAPL, MSFT, SPY, QQQ, TLT, VNQ, XLU)."
    )

    def _run(self, query: str) -> str:
        """执行 yfinance 查询，返回 JSON 字符串结果。"""
        import yfinance as yf

        if os.getenv("DEMO_MODE", "false").lower() == "true":
            return self._get_demo_data(query)

        try:
            parts = query.strip().split(":", 1)
            if len(parts) != 2:
                return f"Error: Invalid query format. Expected 'action:ticker', got '{query}'"

            action, ticker_symbol = parts[0].strip(), parts[1].strip().upper()
            ticker = yf.Ticker(ticker_symbol)

            if action == "get_price":
                hist = ticker.history(period="2d")
                if hist.empty:
                    return f"No price data found for {ticker_symbol}"
                latest_close = float(hist["Close"].iloc[-1])
                prev_close = float(hist["Close"].iloc[-2]) if len(hist) > 1 else latest_close
                change_pct = ((latest_close - prev_close) / prev_close) * 100

                return json.dumps({
                    "ticker": ticker_symbol,
                    "price": round(latest_close, 2),
                    "change_pct": round(change_pct, 2),
                    "currency": "USD",
                })

            elif action == "get_info":
                info = ticker.info
                return json.dumps({
                    "ticker": ticker_symbol,
                    "name": info.get("longName", "N/A"),
                    "sector": info.get("sector", "N/A"),
                    "pe_ratio": info.get("trailingPE"),
                    "market_cap": info.get("marketCap"),
                    "52w_high": info.get("fiftyTwoWeekHigh"),
                    "52w_low": info.get("fiftyTwoWeekLow"),
                })

            else:
                return f"Unsupported action: {action}. Supported: get_price, get_info"

        except Exception as e:
            return f"yfinance error for query '{query}': {str(e)}"

    def _get_demo_data(self, query: str) -> str:
        """从 data/demo_data.json 返回预缓存数据。"""
        try:
            with open("data/demo_data.json", "r", encoding="utf-8") as f:
                demo = json.load(f)
            return json.dumps(demo.get(query, demo.get("yf_default", {"demo": True, "ticker": "AAPL", "price": 172.5, "change_pct": -0.8})))
        except FileNotFoundError:
            return json.dumps({"demo": True, "price": 172.5, "change_pct": -0.8})
```

**验证标准**：

```bash
python -c "
from src.tools.yfinance_tool import YFinanceTool
tool = YFinanceTool()
result = tool._run('get_price:AAPL')
import json; data = json.loads(result)
print(f'AAPL price: \${data[\"price\"]}')
"
# 预期输出：AAPL price: $xxx.xx
```

---

### Task 4：创建 Demo 数据缓存文件

**目的**：预缓存一组真实数据，在 API 不稳定时保障 Demo 正常运行。

```bash
mkdir -p data
```

创建 `data/demo_data.json`（先运行实际 API 获取，再保存为 JSON）：

```python
# /tmp/generate_demo_data.py
# 运行这个脚本获取真实数据并保存为缓存
import json
import akshare as ak
import yfinance as yf
from datetime import datetime

demo_data = {
    "generated_at": datetime.now().isoformat(),
    "scenario": "Fed hawkish minutes, 10Y yield at 4.8%",

    # AKShare 数据
    "get_price:000001": {
        "symbol": "000001", "date": "2026-04-15",
        "close": 12.53, "change_pct": -1.2, "volume": 45000000
    },
    "get_index:000300": {
        "index": "000300", "date": "2026-04-15",
        "close": 3842.5, "change_pct": -0.8
    },
    "get_macro:cpi": {
        "月份": "2026-03", "今值": 0.3, "预测值": 0.2, "前值": 0.1
    },
    "get_forex:USDCNY": {
        "date": "2026-04-15", "usd_cny": 7.25
    },

    # yfinance 数据
    "get_price:SPY": {
        "ticker": "SPY", "price": 512.3, "change_pct": -0.8, "currency": "USD"
    },
    "get_price:QQQ": {
        "ticker": "QQQ", "price": 432.1, "change_pct": -1.2, "currency": "USD"
    },
    "get_price:TLT": {
        "ticker": "TLT", "price": 88.5, "change_pct": -2.1, "currency": "USD"
    },
    "get_price:VNQ": {
        "ticker": "VNQ", "price": 78.2, "change_pct": -3.5, "currency": "USD"
    },
    "get_price:GLD": {
        "ticker": "GLD", "price": 218.4, "change_pct": 0.5, "currency": "USD"
    },
    "get_price:AAPL": {
        "ticker": "AAPL", "price": 172.5, "change_pct": -0.8, "currency": "USD"
    },
    "yf_default": {
        "ticker": "SPY", "price": 512.3, "change_pct": -0.8, "currency": "USD"
    },
    "default": {
        "demo": True, "message": "Demo data - real data unavailable"
    }
}

with open("data/demo_data.json", "w", encoding="utf-8") as f:
    json.dump(demo_data, f, ensure_ascii=False, indent=2)

print("✅ Demo data saved to data/demo_data.json")
print(json.dumps(demo_data, indent=2, ensure_ascii=False))
```

```bash
python /tmp/generate_demo_data.py
```

**验证标准**：

```bash
python -c "
import json
with open('data/demo_data.json') as f: d = json.load(f)
print(f'Demo keys: {list(d.keys())}')
print(f'SPY price: {d[\"get_price:SPY\"][\"price\"]}')
"
# 预期输出：Demo keys: [...] 包含 get_price:SPY 等键
# SPY price: 512.3
```

---

### Task 5：创建 src/tools/__init__.py，暴露 get_all_tools()

**目的**：实现接口契约中定义的 `get_all_tools()` 函数。

创建 `src/tools/__init__.py`：

```python
# src/tools/__init__.py
import os
from crewai.tools import BaseTool

def get_all_tools() -> list[BaseTool]:
    """
    返回所有可用的 CrewAI Tools 实例列表。
    接口定义见 docs/INTERFACE-CONTRACT.md 第 2.3 节。

    当 DEMO_MODE=true 时，Tools 会自动从 data/demo_data.json 读取数据。
    """
    from src.tools.akshare_tool import AKShareTool
    from src.tools.yfinance_tool import YFinanceTool

    return [
        AKShareTool(),
        YFinanceTool(),
    ]
```

**验证标准**：

```bash
python -c "
from src.tools import get_all_tools
tools = get_all_tools()
print(f'Tools count: {len(tools)}')
for t in tools:
    print(f'  - {t.name}')
"
# 预期输出：
# Tools count: 2
#   - AKShare Market Data
#   - yFinance Global Market Data
```

---

### Task 6：端到端测试（含 Demo 模式）

**目的**：验证所有 Tools 在真实模式和 Demo 模式下均可用。

创建 `tests/test_tools.py`：

```python
# tests/test_tools.py
import os
import json

def test_tools_import():
    from src.tools import get_all_tools
    tools = get_all_tools()
    assert len(tools) == 2, f"Expected 2 tools, got {len(tools)}"
    names = [t.name for t in tools]
    assert "AKShare Market Data" in names
    assert "yFinance Global Market Data" in names
    print("✅ Tool import test passed")

def test_demo_mode():
    os.environ["DEMO_MODE"] = "true"
    from src.tools.akshare_tool import AKShareTool
    tool = AKShareTool()
    result = tool._run("get_price:000001")
    data = json.loads(result)
    print(f"✅ Demo mode test passed: {data}")
    os.environ["DEMO_MODE"] = "false"

def test_tool_error_handling():
    from src.tools.akshare_tool import AKShareTool
    tool = AKShareTool()
    result = tool._run("invalid_query")
    assert "Error" in result or "error" in result
    print(f"✅ Error handling test passed: {result[:50]}...")

if __name__ == "__main__":
    test_tools_import()
    test_demo_mode()
    test_tool_error_handling()
    print("\n✅ All tool tests passed")
```

```bash
python tests/test_tools.py
# 预期输出：
# ✅ Tool import test passed
# ✅ Demo mode test passed: {...}
# ✅ Error handling test passed: Error: Invalid query...
# ✅ All tool tests passed
```

---

## 6. 本模块暴露的接口

（与 `docs/INTERFACE-CONTRACT.md` 第 2.3 节完全一致）

```python
# src/tools/__init__.py
from crewai.tools import BaseTool

def get_all_tools() -> list[BaseTool]: ...

# 各 Tool 的 _run 查询格式：
# "get_price:000001"  → AKShare A股价格
# "get_price:AAPL"    → yfinance 美股价格
# "get_index:000300"  → AKShare 指数
# "get_macro:cpi"     → AKShare 中国 CPI
# "get_forex:USDCNY"  → AKShare 汇率
# "get_info:AAPL"     → yfinance 公司信息
```

---

## 7. 本模块依赖的外部接口（当前用 Mock）

本模块**没有外部依赖**（AKShare 和 yfinance 都是 pip 包，直接 import 即可）。

唯一的跨模块依赖：
- Window A 需要 import `get_all_tools()`——Window A 已有兼容处理（找不到时返回空列表）

---

## 8. 基座仓库中需要忽略的部分

| botextractai 文件/功能 | 原因 |
|----------------------|------|
| `tools/sec_tools.py` 的 SEC-API 调用逻辑 | 替换为 AKShare/yfinance |
| `tools/search_tools.py` | SEC 搜索工具，不需要 |
| 任何需要 SERPER_API_KEY 的工具 | 不需要搜索引擎 API |

---

## 完成标准（Checklist）

在告知窗口 A/E 可以集成前，确认以下全部通过：

- [ ] `python tests/test_tools.py` 全部通过（包含 Demo 模式测试）
- [ ] `DEMO_MODE=true python -c "from src.tools import get_all_tools; tools = get_all_tools(); print([t._run('get_price:000001') for t in tools[:1]])"` 返回 demo 数据
- [ ] `data/demo_data.json` 存在且包含至少 8 个 key
- [ ] 真实模式下 AKShare 或 yfinance 至少有一个能获取到真实数据
- [ ] `from src.tools import get_all_tools` 无 ImportError
- [ ] 无硬编码 API Key
