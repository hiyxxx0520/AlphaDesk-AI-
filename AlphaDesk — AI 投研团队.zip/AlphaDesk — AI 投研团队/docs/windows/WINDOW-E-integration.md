# WINDOW-E — 集成 + Orchestrator + Demo

> **在开始之前**：先读 `CLAUDE.md` 和 `docs/INTERFACE-CONTRACT.md`，全部理解后再动手。

---

## 1. 模块职责

窗口 E **不写新的业务逻辑代码**，只负责：
1. 验证窗口 A/B/C 的接口已就位
2. 编写 `src/orchestrator.py`（胶水逻辑：接收触发 → 调用 Agent → 分批发送飞书消息）
3. 编写 `main.py` 入口（启动飞书监听器）
4. 端到端测试全链路
5. 写 README + 准备 Demo 脚本

**启动时机**：窗口 A 和窗口 B 基本完成后再启动（C 完成更好，但不是硬依赖）

**产出目录**：`src/orchestrator.py` + `main.py` + `README.md`  
**Git 分支**：`main`（直接在主分支工作，或从 main merge A/B/C 分支后工作）

---

## 2. 基座仓库

窗口 E 不需要克隆新的基座仓库。

**使用已完成的模块**：
- 窗口 A：`src/agents/crew.py` → `run_analysis()`
- 窗口 B：`src/feishu/sender.py` → `send_to_group()`
- 窗口 B：`src/feishu/listener.py` → `start_listener()`
- 窗口 C：`src/tools/__init__.py` → `get_all_tools()`（通过 A 间接使用）
- 窗口 D：`src/outputs/` → `generate_strategy_doc()` 等（P1，可选接入）

---

## 3. 环境变量需求

```bash
# .env 文件中（窗口 E 需要 A + B 的最小集）
DEEPSEEK_API_KEY=sk-xxxx          # 必须：LLM API Key
FEISHU_COOKIE=session=xxx; ...    # 必须：飞书 Cookie
FEISHU_GROUP_ID=oc_xxxxxxxxxx     # 必须：目标飞书群 ID

# 可选（开发调试时推荐设置）
FEISHU_MOCK=false                 # true = 不发真实飞书消息，只打印
DEMO_MODE=false                   # true = 金融工具返回缓存数据

# 窗口 D 相关（P1，可选）
FEISHU_APP_ID=cli_xxxxx
FEISHU_APP_SECRET=xxxxx
```

---

## 4. 依赖安装

窗口 E 不需要额外安装依赖，所有依赖已由 A/B/C 安装。

```bash
# 验证所有依赖都在
pip install crewai akshare yfinance python-dotenv lark-oapi

# 验证所有模块可以 import
python -c "
from src.agents.crew import run_analysis
from src.feishu.sender import send_to_group
from src.feishu.listener import start_listener
from src.tools import get_all_tools
print('All modules import OK')
"
```

---

## 5. 逐步任务列表

---

### Task 0：验证 A/B/C 接口已就位

**目的**：在写 Orchestrator 之前，确认所有依赖模块的接口符合契约。

```bash
# 检查 1：窗口 A 接口
python -c "
from src.agents.crew import run_analysis
import inspect
sig = inspect.signature(run_analysis)
print(f'run_analysis signature: {sig}')
# 预期：(trigger_event: str, market_data: dict | None = None) -> list[AgentResponse]
"

# 检查 2：窗口 B 发送接口
python -c "
from src.feishu.sender import send_to_group, ROLE_PREFIX
import inspect
sig = inspect.signature(send_to_group)
print(f'send_to_group signature: {sig}')
print(f'ROLE_PREFIX keys: {list(ROLE_PREFIX.keys())}')
# 预期 keys: ['macro_analyst', 'sector_analyst', 'risk_manager', 'chief_strategist']
"

# 检查 3：窗口 B 监听接口
python -c "
from src.feishu.listener import start_listener
import inspect
sig = inspect.signature(start_listener)
print(f'start_listener signature: {sig}')
"

# 检查 4：窗口 C 工具
python -c "
from src.tools import get_all_tools
tools = get_all_tools()
print(f'Tools: {[t.name for t in tools]}')
"
```

**验证标准**：全部 4 个检查无 ImportError，函数签名与 INTERFACE-CONTRACT.md 一致。

**如果某个模块未完成**：
- 窗口 A 未完成 → 使用 Mock（见 Task 1 的 Mock 策略）
- 窗口 B 未完成 → 设置 `FEISHU_MOCK=true` 跳过真实发送
- 窗口 C 未完成 → 工具为空列表，Agents 不使用 Tool 运行

---

### Task 1：编写 orchestrator.py

**目的**：实现主编排函数 `handle_trigger()`，将 CrewAI 输出逐条发送到飞书群。

创建 `src/orchestrator.py`：

```python
# src/orchestrator.py
import asyncio
import os
from datetime import datetime
from dotenv import load_dotenv

load_dotenv()

from src.agents.types import AgentResponse

# 每条 Agent 消息之间的延迟（秒），制造"正在思考"的感觉
MESSAGE_DELAY_SECONDS = float(os.getenv("MESSAGE_DELAY", "2.0"))

# 是否启用 P1 功能（文档生成 + 表格写入）
ENABLE_DOC_GENERATION   = os.getenv("ENABLE_DOC", "false").lower() == "true"
ENABLE_TABLE_UPDATE     = os.getenv("ENABLE_TABLE", "false").lower() == "true"
ENABLE_CARD_MESSAGES    = os.getenv("ENABLE_CARDS", "false").lower() == "true"


async def handle_trigger(user_message: str, group_id: str) -> None:
    """
    主编排函数。从飞书监听器回调，协调整个分析流程。
    接口定义见 docs/INTERFACE-CONTRACT.md 第 2.5 节。

    流程：
    1. 调用 run_analysis(user_message) → list[AgentResponse]
    2. 逐条调用 send_to_group()，每条之间 delay MESSAGE_DELAY_SECONDS 秒
    3. （P1）生成飞书文档
    4. （P1）更新多维表格
    """
    from src.agents.crew import run_analysis
    from src.feishu.sender import send_to_group

    print(f"\n[Orchestrator] Trigger received: '{user_message}' in group {group_id}")
    print(f"[Orchestrator] Starting AlphaDesk analysis...")

    # Step 1: 运行 CrewAI 分析
    try:
        responses: list[AgentResponse] = run_analysis(
            trigger_event=user_message,
            market_data=None  # 让 Agents 自己通过 Tools 获取数据
        )
    except Exception as e:
        print(f"[Orchestrator] Analysis failed: {e}")
        # 降级：使用预设的 demo 响应
        responses = _get_demo_responses(user_message)

    print(f"[Orchestrator] Analysis complete. Sending {len(responses)} messages...")

    # Step 2: 逐条发送到飞书群（含延迟）
    for i, response in enumerate(responses):
        success = await send_to_group(
            group_id=group_id,
            message=response["content"],
            identity=response["role"],
            message_type="interactive" if ENABLE_CARD_MESSAGES else "text",
        )
        if success:
            print(f"[Orchestrator] [{i+1}/{len(responses)}] {response['role']} message sent.")
        else:
            print(f"[Orchestrator] [{i+1}/{len(responses)}] {response['role']} message FAILED.")

        # 在最后一条消息之前都加延迟（最后一条不加）
        if i < len(responses) - 1:
            await asyncio.sleep(MESSAGE_DELAY_SECONDS)

    # Step 3: P1 功能（文档生成）
    if ENABLE_DOC_GENERATION:
        try:
            from src.outputs.doc_generator import generate_strategy_doc
            doc_title = f"AlphaDesk Report — {datetime.now().strftime('%Y-%m-%d %H:%M')}"
            doc_link = await generate_strategy_doc(responses, doc_title)
            print(f"[Orchestrator] Strategy doc generated: {doc_link}")
            # 通知群里文档已生成
            await send_to_group(
                group_id=group_id,
                message=f"📄 Full strategy report generated: {doc_link}",
                identity="chief_strategist",
            )
        except Exception as e:
            print(f"[Orchestrator] Doc generation failed (non-critical): {e}")

    # Step 4: P1 功能（表格更新）
    if ENABLE_TABLE_UPDATE:
        try:
            from src.outputs.table_writer import update_risk_matrix
            # 从 risk_manager 的 response 提取数字（简单实现）
            risk_response = next(
                (r for r in responses if r["role"] == "risk_manager"), None
            )
            if risk_response:
                risk_data = {
                    "timestamp": datetime.now().isoformat(),
                    "trigger": user_message[:100],
                    "duration_sensitivity": 0.34,  # TODO: 从 response 解析
                    "estimated_drawdown": -0.082,   # TODO: 从 response 解析
                    "recommendation": risk_response["content"][:200],
                }
                await update_risk_matrix(risk_data)
                print("[Orchestrator] Risk matrix updated.")
        except Exception as e:
            print(f"[Orchestrator] Table update failed (non-critical): {e}")

    print(f"[Orchestrator] Done. AlphaDesk analysis complete.\n")


def _get_demo_responses(trigger: str) -> list[AgentResponse]:
    """当 CrewAI 分析失败时，返回预设的 Demo 响应（保障 Demo 不崩溃）。"""
    return [
        {
            "role": "macro_analyst",
            "content": f"[ALERT] Analyzing: {trigger[:50]}... 10Y yield pressure mounting. Rate-sensitive assets at risk. @Sector @Risk please assess immediately.",
            "tags": ["ALERT"],
        },
        {
            "role": "sector_analyst",
            "content": "[DISAGREE] Tech sector P/E compression already priced in Q1. Real risk concentrated in REITs ($VNQ -3.5%) and utilities. Growth tech may outperform on relative basis.",
            "tags": ["DISAGREE"],
        },
        {
            "role": "risk_manager",
            "content": "[RISK] Portfolio risk check: duration sensitivity 34%. Stress scenario (10Y→5.0%): estimated drawdown -8.2%. Recommend halving $TLT position immediately.",
            "tags": ["RISK"],
        },
        {
            "role": "chief_strategist",
            "content": "[ACTION] Consensus reached. Agree with SA on REIT vulnerability and RM on duration risk. Action: 1) Reduce $TLT 50% 2) Rotate to short-duration credit 3) Buy REIT put hedge. Report generated to Feishu Docs.",
            "tags": ["ACTION"],
        },
    ]
```

**验证标准（Mock 模式）**：

```bash
FEISHU_MOCK=true DEMO_MODE=true python -c "
import asyncio
from src.orchestrator import handle_trigger

asyncio.run(handle_trigger(
    user_message='分析一下美联储最新会议纪要对市场的影响',
    group_id='oc_test123'
))
"
# 预期输出：
# [Orchestrator] Trigger received: '分析一下美联储...' in group oc_test123
# [Orchestrator] Starting AlphaDesk analysis...
# [MOCK→oc_test123]
# 🔭 [Macro Analyst]
# [ALERT] ...
# ----------------------------------------
# [Orchestrator] [1/4] macro_analyst message sent.
# ... (4 条消息)
# [Orchestrator] Done. AlphaDesk analysis complete.
```

---

### Task 2：编写 main.py 入口

**目的**：启动飞书监听器，将消息事件路由到 Orchestrator。

创建 `main.py`（项目根目录）：

```python
# main.py
"""AlphaDesk — AI Investment Research Team in Feishu"""
import asyncio
import os
from dotenv import load_dotenv

load_dotenv()

from src.feishu.listener import start_listener
from src.orchestrator import handle_trigger


async def main():
    group_id = os.getenv("FEISHU_GROUP_ID", "")
    feishu_mock = os.getenv("FEISHU_MOCK", "false").lower() == "true"

    print("=" * 50)
    print("🚀 AlphaDesk — AI Investment Research Team")
    print("=" * 50)
    print(f"  Feishu Group: {group_id or '(not set)'}")
    print(f"  Mock Mode:    {feishu_mock}")
    print(f"  Demo Mode:    {os.getenv('DEMO_MODE', 'false')}")
    print("=" * 50)
    print("Listening for @AlphaDesk messages...")
    print("(In mock mode, type: group_id::message and press Enter)")
    print()

    async def on_message(user_message: str, msg_group_id: str):
        """飞书消息回调 → Orchestrator"""
        # 如果没有 group_id，用监听到的群 ID
        target_group = group_id or msg_group_id
        await handle_trigger(user_message, target_group)

    await start_listener(on_message)


if __name__ == "__main__":
    asyncio.run(main())
```

**验证标准（Mock 模式，端到端）**：

```bash
FEISHU_MOCK=true DEMO_MODE=true python main.py
# 然后输入（不需要回车，stdin 读取）：
# oc_test123::分析美联储最新会议纪要

# 预期看到 4 个 Agent 依次发言的输出
```

---

### Task 3：端到端真实链路测试

**目的**：在真实飞书环境中测试完整流程（需要有效的 Cookie）。

```bash
# 方法 1：手动触发（不依赖监听器）
python -c "
import asyncio
import os
from dotenv import load_dotenv
load_dotenv()
from src.orchestrator import handle_trigger

asyncio.run(handle_trigger(
    user_message='Fed released hawkish FOMC minutes. 10Y yield jumped to 4.8%.',
    group_id=os.getenv('FEISHU_GROUP_ID')
))
"

# 方法 2：完整启动（包含监听器，然后在飞书群 @ 机器人）
python main.py
```

**验证标准**：飞书测试群里依次出现 4 条带角色前缀的消息：
```
🔭 [Macro Analyst]
[ALERT] ...

💡 [Sector Analyst]
[DISAGREE] ...

⚠️ [Risk Manager]
[RISK] ...

🎯 [Chief Strategist]
[ACTION] ...
```

每条消息间隔约 2 秒（MESSAGE_DELAY=2.0）。

---

### Task 4：（可选）接入窗口 D 输出

**目的**：如果窗口 D 已完成，在 Orchestrator 中启用文档生成和表格更新。

```bash
# 在 .env 中启用 P1 功能
echo "ENABLE_DOC=true" >> .env
echo "ENABLE_TABLE=true" >> .env

# 重新运行并验证
python -c "
import asyncio, os
os.environ['ENABLE_DOC'] = 'true'
os.environ['FEISHU_MOCK'] = 'true'
os.environ['DEMO_MODE'] = 'true'
from src.orchestrator import handle_trigger
asyncio.run(handle_trigger('Test event', 'oc_test'))
"
# 预期：额外输出 "[Orchestrator] Strategy doc generated: data/mock_doc_xxx.md"
```

---

### Task 5：编写 README.md

**目的**：项目文档，用于比赛提交和 GitHub 展示。

创建 `README.md`（在项目根目录）：

```markdown
# AlphaDesk — AI 投研团队，就在飞书群里

> "Your AI Investment Research Team, Live in Feishu"

[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT)

## 项目简介

AlphaDesk 在一个飞书群里部署了 4 个 AI Agent，它们会**自主监控市场、互相辩论、协作产出投研报告**。

用户 @ 机器人提问，4 个专业角色依次发言：

| 角色 | 标签 | 职责 |
|------|------|------|
| 🔭 Macro Analyst | `[ALERT]` | 宏观数据分析，识别系统性风险 |
| 💡 Sector Analyst | `[DISAGREE]` | 行业底部分析，挑战共识 |
| ⚠️ Risk Manager | `[RISK]` | 量化风险，VaR/回撤估算 |
| 🎯 Chief Strategist | `[ACTION]` | 综合拍板，产出行动方案 |

## 演示

1. 在飞书群 @AlphaDesk：`分析美联储最新会议纪要对市场的影响`
2. 4 个 Agent 依次在群里发言（约 10-15 秒完成）
3. 自动生成策略报告到飞书文档
4. 风险矩阵实时更新到多维表格

## 技术架构

- **多 Agent 框架**：CrewAI（Sequential Process）
- **飞书连接**：LarkAgentX（WebSocket, Cookie 认证）
- **金融数据**：AKShare（A 股）+ yfinance（美股）
- **飞书输出**：lark-oapi SDK
- **LLM**：DeepSeek API（OpenAI 兼容接口）

## 快速开始

\`\`\`bash
# 1. 克隆仓库
git clone <repo-url> && cd alphadesk

# 2. 安装依赖
pip install -r requirements.txt

# 3. 配置环境变量
cp .env.example .env
# 编辑 .env，填入 DEEPSEEK_API_KEY 和 FEISHU_COOKIE

# 4. 启动（Mock 模式，无需真实飞书）
FEISHU_MOCK=true DEMO_MODE=true python main.py

# 5. 测试（在终端输入）
# oc_test123::分析美联储最新会议纪要
\`\`\`

## 参赛信息

飞书 AI 校园挑战赛 · 开放创新赛道 · 2026
```

---

### Task 6：准备 Demo 演示脚本

**目的**：确保答辩 Demo 万无一失，即使 API 不稳定也能演示。

创建 `scripts/demo.py`（演示专用脚本，使用预设数据）：

```python
# scripts/demo.py
"""
AlphaDesk Demo 脚本
用于现场答辩演示，不依赖 LLM API（使用预设精心调校的回复）
"""
import asyncio
import os
import time
from dotenv import load_dotenv

load_dotenv()

# 精心设计的 Demo 对话（确保质量和流畅性）
DEMO_SCENARIO = {
    "trigger": "Fed released hawkish FOMC minutes. 10Y Treasury yield surged to 4.8%.",
    "responses": [
        {
            "role": "macro_analyst",
            "content": (
                "[ALERT] FOMC minutes confirm hawkish pivot — rate cuts pushed to Q4 2026 at earliest. "
                "10Y yield surged 22bp to 4.8%, threatening the 5.0% psychological level. "
                "Cross-asset impact: duration assets (-2%), REITs (-3.5%), growth equities (-1.2%). "
                "@Sector assess sector rotation, @Risk run portfolio stress test immediately."
            ),
            "tags": ["ALERT"],
        },
        {
            "role": "sector_analyst",
            "content": (
                "[DISAGREE] Disagree with blanket bearish view. Tech P/E compression from 28x→22x "
                "already priced in a 200bp rate differential — further spread is limited. "
                "Real vulnerability is rate-sensitive income: $VNQ -3.5% and $XLU -2.8% YTD. "
                "Rotate FROM utilities/REITs INTO short-duration tech and energy infrastructure."
            ),
            "tags": ["DISAGREE"],
        },
        {
            "role": "risk_manager",
            "content": (
                "[RISK] Portfolio stress test complete. Current duration sensitivity: 34%. "
                "Scenario: 10Y breaks 5.0% → estimated max drawdown -8.2% (95% VaR, 30-day). "
                "Sharpe ratio degrades from 1.4→0.8. Immediate action: reduce $TLT 50%, "
                "add 5% REIT put hedge ($VNQ June $75 puts), cap rate exposure at 20%."
            ),
            "tags": ["RISK"],
        },
        {
            "role": "chief_strategist",
            "content": (
                "[ACTION] Consensus reached. MA correctly flagged systemic risk; SA's sector rotation "
                "call is sound; RM's 8.2% drawdown estimate requires immediate action. "
                "Action plan: 1) Reduce $TLT position 50% at market open "
                "2) Rotate proceeds into 1-3Y investment grade credit ($VCSH) "
                "3) Buy $VNQ June $75 puts for REIT hedge "
                "4) Hold growth-tech exposure — already priced. "
                "Full strategy memo generated to Feishu Docs. Risk matrix updated."
            ),
            "tags": ["ACTION"],
        },
    ]
}

async def run_demo():
    from src.feishu.sender import send_to_group
    group_id = os.getenv("FEISHU_GROUP_ID", "oc_test")

    print("\n🎬 AlphaDesk Demo Starting...")
    print(f"📊 Scenario: {DEMO_SCENARIO['trigger']}\n")

    for response in DEMO_SCENARIO["responses"]:
        await send_to_group(
            group_id=group_id,
            message=response["content"],
            identity=response["role"],
        )
        print(f"✅ [{response['role']}] message sent.")
        await asyncio.sleep(2.5)  # 让评委有时间看

    print("\n🏁 Demo Complete!")

if __name__ == "__main__":
    asyncio.run(run_demo())
```

**验证标准（Mock 模式）**：

```bash
FEISHU_MOCK=true python scripts/demo.py
# 预期：4 条 Demo 消息依次输出，每条间隔 2.5 秒
```

---

## 6. 本模块暴露的接口

（与 `docs/INTERFACE-CONTRACT.md` 第 2.5 节完全一致）

```python
# src/orchestrator.py
async def handle_trigger(user_message: str, group_id: str) -> None: ...
```

---

## 7. 本模块依赖的外部接口

| 依赖 | 来源窗口 | 如果未完成的处理 |
|------|---------|--------------|
| `run_analysis()` | 窗口 A | `orchestrator.py` 中使用 `_get_demo_responses()` 降级 |
| `send_to_group()` | 窗口 B | 设置 `FEISHU_MOCK=true` |
| `start_listener()` | 窗口 B | 设置 `FEISHU_MOCK=true`（stdin 模拟） |
| `get_all_tools()` | 窗口 C | A 已有兼容处理（返回空列表） |
| `generate_strategy_doc()` | 窗口 D | 设置 `ENABLE_DOC=false`（默认） |
| `update_risk_matrix()` | 窗口 D | 设置 `ENABLE_TABLE=false`（默认） |

---

## 8. 基座仓库中需要忽略的部分

窗口 E 不需要克隆任何基座仓库，所有代码都是原创的胶水逻辑。

---

## 完成标准（Checklist）

提交参赛材料前，确认以下全部通过：

**P0 必须完成（MVP）**：
- [ ] `FEISHU_MOCK=true DEMO_MODE=true python -c "import asyncio; from src.orchestrator import handle_trigger; asyncio.run(handle_trigger('Test', 'oc_test'))"` 正常输出 4 条角色消息
- [ ] `FEISHU_MOCK=true python scripts/demo.py` 输出精心设计的 Demo 对话
- [ ] 真实飞书群里能看到 4 条带角色前缀的消息

**P1 锦上添花**：
- [ ] `python main.py` 启动后，在飞书群 @AlphaDesk 能触发完整分析流程
- [ ] 飞书文档自动生成（需要 `ENABLE_DOC=true` 和有效的 App ID）
- [ ] `README.md` 写完，包含项目简介、演示步骤、技术架构

**答辩准备**：
- [ ] `scripts/demo.py` 用精心设计的 Demo 内容跑通（备用方案，API 挂了也能演示）
- [ ] `.env.example` 已创建（不含真实 key）
- [ ] `.gitignore` 包含 `.env`
