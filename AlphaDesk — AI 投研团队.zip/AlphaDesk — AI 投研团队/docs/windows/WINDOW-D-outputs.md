# WINDOW-D — 飞书输出集成

> **在开始之前**：先读 `CLAUDE.md` 和 `docs/INTERFACE-CONTRACT.md`，全部理解后再动手。

---

## 1. 模块职责

配置并调通 `larksuite/lark-openapi-mcp`（飞书官方 MCP 服务器），实现策略报告飞书文档自动生成、风险矩阵多维表格写入、以及 Agent 消息卡片构建。当飞书 API 不可用时自动降级到本地文件保存。

**产出目录**：`src/outputs/`  
**Git 分支**：`outputs-dev`（worktree 在 `../alphadesk-outputs/`）

> **优先级说明**：本模块是 P1（锦上添花）功能。窗口 A/B/C 完成后再启动。如果时间紧张，`card_builder.py` 是最高优先级（可改善 Demo 视觉效果），doc/table 次之。

---

## 2. 基座仓库

### larksuite/lark-openapi-mcp（主要）

飞书官方出品的 MCP 服务器，已封装飞书文档创建、多维表格操作等全部 API。

**我们不写飞书 API 调用代码，而是通过 MCP 协议让 Agent 调用。**

```bash
# 安装
npm install -g @larksuiteoapi/lark-mcp

# 启动（在另一个终端）
npx -y @larksuiteoapi/lark-mcp mcp \
  -a $FEISHU_APP_ID \
  -s $FEISHU_APP_SECRET \
  -t im.v1.message.create,docx.v1.document.create,bitable.v1.app_table.list
```

### larksuite/cli（辅助验证）

飞书官方 CLI，用于快速验证权限和 API 可用性，不需要写代码。

```bash
npm install -g @larksuite/cli
# 或使用 npx：npx @larksuite/cli
```

---

## 3. 环境变量需求

```bash
# .env 文件中（窗口 D 需要额外字段）
FEISHU_APP_ID=cli_xxxxx              # 必须：飞书应用 App ID
FEISHU_APP_SECRET=xxxxx              # 必须：飞书应用 App Secret
FEISHU_BITABLE_APP_TOKEN=xxxxx       # 可选：多维表格 App Token（update_risk_matrix 需要）
FEISHU_BITABLE_TABLE_ID=xxxxx        # 可选：多维表格 Table ID
FEISHU_DOC_FOLDER_TOKEN=xxxxx        # 可选：文档存放的文件夹 Token

# 如果没有 App ID/Secret，设置以下变量启用本地 fallback 模式：
# FEISHU_APP_ID 不设置 → 自动使用本地 mock 模式
```

> **重要**：窗口 D 需要飞书开放平台的 App ID + App Secret。如果用户尚未创建飞书应用，本窗口的文档/表格功能无法测试。**但 `card_builder.py` 是纯函数（无 IO），可以独立测试**。

---

## 4. 依赖安装

```bash
# Python 依赖
pip install lark-oapi python-dotenv

# Node.js 依赖（飞书 MCP + CLI）
npm install -g @larksuiteoapi/lark-mcp
# 验证安装
npx @larksuiteoapi/lark-mcp --version

# 可选：飞书 CLI
npm install -g @larksuite/cli

# 验证 Python SDK
python -c "import lark_oapi; print(f'lark-oapi {lark_oapi.__version__} OK')"
```

---

## 5. 逐步任务列表

---

### Task 0：了解 lark-openapi-mcp 的能力范围

**目的**：在写代码之前，先用 CLI 验证飞书 API 权限和可用性。

```bash
# Step A：如果没有 App ID/Secret，跳过 Task 0，直接从 Task 4（card_builder）开始

# Step B：配置飞书应用（需要在飞书开放平台完成）
# 1. 登录 https://open.feishu.cn/
# 2. 创建企业自建应用（或找到已有应用）
# 3. 开启以下权限：
#    - im:message（发消息）
#    - docs:doc（创建/编辑文档）
#    - bitable:app（多维表格读写）
#    - calendar:calendar（日历，可选）
# 4. 将机器人添加到测试飞书群
# 5. 获取 App ID 和 App Secret，写入 .env

# Step C：用 lark-mcp 启动 MCP 服务器（在另一个终端）
npx -y @larksuiteoapi/lark-mcp mcp \
  -a $FEISHU_APP_ID \
  -s $FEISHU_APP_SECRET \
  -t im.v1.message.create,docx.v1.document.create,bitable.v1.app_table.list

# Step D：验证 MCP 服务器启动正常
# 预期终端输出：MCP server started on ... （或类似成功信息）
```

**验证标准**：MCP 服务器正常启动，无错误。

---

### Task 1：用飞书 Python SDK 发一条测试消息

**目的**：验证 App ID/Secret 和群 ID 有效（比 MCP 更容易调试）。

```python
# /tmp/test_feishu_sdk.py
import os
from dotenv import load_dotenv
load_dotenv("/Users/yyy/Desktop/飞书AI校园挑战赛/.env")

import lark_oapi as lark
from lark_oapi.api.im.v1 import *

def test_send_message():
    client = lark.Client.builder() \
        .app_id(os.getenv("FEISHU_APP_ID")) \
        .app_secret(os.getenv("FEISHU_APP_SECRET")) \
        .build()

    request = CreateMessageRequest.builder() \
        .receive_id_type("chat_id") \
        .request_body(CreateMessageRequestBody.builder()
            .receive_id(os.getenv("FEISHU_GROUP_ID"))
            .msg_type("text")
            .content('{"text":"🧪 AlphaDesk SDK test message"}')
            .build()) \
        .build()

    response = client.im.v1.message.create(request)
    if response.success():
        print(f"✅ Message sent successfully. Message ID: {response.data.message_id}")
    else:
        print(f"❌ Failed: code={response.code}, msg={response.msg}")

test_send_message()
```

```bash
python /tmp/test_feishu_sdk.py
```

**验证标准**：飞书测试群出现消息，终端输出 `✅ Message sent successfully`。

---

### Task 2：创建 MCP 客户端封装模块

**目的**：封装飞书 Python SDK 调用，为 doc_generator 和 table_writer 提供底层方法。

创建 `src/outputs/feishu_client.py`：

```python
# src/outputs/feishu_client.py
import os
import json
from dotenv import load_dotenv
import lark_oapi as lark
from lark_oapi.api.docx.v1 import *
from lark_oapi.api.bitable.v1 import *
from lark_oapi.api.im.v1 import *

load_dotenv()

_client: lark.Client | None = None

def get_client() -> lark.Client:
    """返回飞书 SDK 客户端实例（单例）。"""
    global _client
    if _client is None:
        app_id = os.getenv("FEISHU_APP_ID", "")
        app_secret = os.getenv("FEISHU_APP_SECRET", "")
        if not app_id or not app_secret:
            raise ValueError(
                "FEISHU_APP_ID and FEISHU_APP_SECRET must be set in .env. "
                "Set FEISHU_APP_ID='' to use mock mode."
            )
        _client = lark.Client.builder() \
            .app_id(app_id) \
            .app_secret(app_secret) \
            .build()
    return _client

def is_feishu_available() -> bool:
    """检查飞书 API 是否可用（有 App ID/Secret）。"""
    return bool(os.getenv("FEISHU_APP_ID")) and bool(os.getenv("FEISHU_APP_SECRET"))

async def create_document(title: str, content_markdown: str) -> str:
    """
    创建飞书文档，返回文档链接。
    Mock 模式：保存到本地 markdown 文件。
    """
    if not is_feishu_available():
        return _mock_save_doc(title, content_markdown)

    client = get_client()
    # 飞书文档创建 API
    request = CreateDocumentRequest.builder() \
        .request_body(CreateDocumentRequestBody.builder()
            .title(title)
            .folder_token(os.getenv("FEISHU_DOC_FOLDER_TOKEN", ""))
            .build()) \
        .build()

    response = client.docx.v1.document.create(request)
    if response.success():
        doc_id = response.data.document.document_id
        return f"https://feishu.cn/docx/{doc_id}"
    else:
        print(f"[create_document] Error: {response.code} {response.msg}")
        return _mock_save_doc(title, content_markdown)

def _mock_save_doc(title: str, content: str) -> str:
    """Mock：将文档内容保存为本地 markdown 文件。"""
    import time
    timestamp = int(time.time())
    os.makedirs("data", exist_ok=True)
    filepath = f"data/mock_doc_{timestamp}.md"
    with open(filepath, "w", encoding="utf-8") as f:
        f.write(f"# {title}\n\n{content}")
    print(f"[MOCK] Document saved to {filepath}")
    return filepath

async def append_bitable_record(app_token: str, table_id: str, fields: dict) -> str:
    """
    向多维表格追加一行记录，返回记录 ID。
    Mock 模式：保存到本地 JSON。
    """
    if not is_feishu_available():
        return _mock_save_table(fields)

    client = get_client()
    request = CreateAppTableRecordRequest.builder() \
        .app_token(app_token) \
        .table_id(table_id) \
        .request_body(AppTableRecord.builder()
            .fields(fields)
            .build()) \
        .build()

    response = client.bitable.v1.app_table_record.create(request)
    if response.success():
        return response.data.record.record_id
    else:
        print(f"[append_bitable_record] Error: {response.code} {response.msg}")
        return _mock_save_table(fields)

def _mock_save_table(fields: dict) -> str:
    """Mock：将记录追加到本地 JSON 文件。"""
    import time
    os.makedirs("data", exist_ok=True)
    filepath = "data/mock_risk_matrix.json"
    records = []
    if os.path.exists(filepath):
        with open(filepath) as f:
            records = json.load(f)
    records.append({"timestamp": time.time(), "fields": fields})
    with open(filepath, "w") as f:
        json.dump(records, f, ensure_ascii=False, indent=2, default=str)
    print(f"[MOCK] Record saved to {filepath}")
    return f"mock_record_{int(time.time())}"
```

**验证标准**：

```bash
python -c "from src.outputs.feishu_client import is_feishu_available; print(f'Feishu available: {is_feishu_available()}')"
# 预期输出（没有配置 App ID 时）：Feishu available: False
```

---

### Task 3：创建 doc_generator.py

**目的**：实现 `generate_strategy_doc()`，将 4 个 Agent 的输出格式化为飞书文档。

创建 `src/outputs/doc_generator.py`：

```python
# src/outputs/doc_generator.py
from src.agents.types import AgentResponse
from src.outputs.feishu_client import create_document

ROLE_DISPLAY_NAME = {
    "macro_analyst":    "🔭 Macro Analyst",
    "sector_analyst":   "💡 Sector Analyst",
    "risk_manager":     "⚠️ Risk Manager",
    "chief_strategist": "🎯 Chief Strategist",
}

def _format_as_markdown(responses: list[AgentResponse]) -> str:
    """将 AgentResponse 列表格式化为 Markdown 报告。"""
    from datetime import datetime
    date_str = datetime.now().strftime("%Y-%m-%d %H:%M")

    lines = [
        f"## AlphaDesk Investment Research Report",
        f"*Generated at {date_str}*",
        "",
        "---",
        "",
    ]

    for resp in responses:
        display_name = ROLE_DISPLAY_NAME.get(resp["role"], resp["role"])
        tags_str = " ".join(f"`[{t}]`" for t in resp["tags"]) if resp["tags"] else ""
        lines.extend([
            f"### {display_name} {tags_str}",
            "",
            resp["content"],
            "",
            "---",
            "",
        ])

    return "\n".join(lines)

async def generate_strategy_doc(
    responses: list[AgentResponse],
    doc_title: str
) -> str:
    """
    根据 4 个 Agent 的分析结果，自动生成飞书文档（策略备忘录）。
    接口定义见 docs/INTERFACE-CONTRACT.md 第 2.4 节。
    """
    content_markdown = _format_as_markdown(responses)
    doc_link = await create_document(doc_title, content_markdown)
    return doc_link
```

**验证标准（Mock 模式）**：

```bash
python -c "
import asyncio
from src.outputs.doc_generator import generate_strategy_doc

MOCK_RESPONSES = [
    {'role': 'macro_analyst',    'content': '[ALERT] Test macro alert.', 'tags': ['ALERT']},
    {'role': 'sector_analyst',   'content': '[DISAGREE] Counter view.',  'tags': ['DISAGREE']},
    {'role': 'risk_manager',     'content': '[RISK] Drawdown -8%.',      'tags': ['RISK']},
    {'role': 'chief_strategist', 'content': '[ACTION] Action plan.',     'tags': ['ACTION']},
]

async def test():
    link = await generate_strategy_doc(MOCK_RESPONSES, 'AlphaDesk Test Report')
    print(f'Doc link: {link}')

asyncio.run(test())
"
# 预期输出（Mock 模式）：Doc link: data/mock_doc_xxxxx.md
```

---

### Task 4：创建 table_writer.py

**目的**：实现 `update_risk_matrix()`，将风险数据写入多维表格。

创建 `src/outputs/table_writer.py`：

```python
# src/outputs/table_writer.py
import os
from src.outputs.feishu_client import append_bitable_record

async def update_risk_matrix(risk_data: dict) -> str:
    """
    将风险矩阵数据写入飞书多维表格。
    接口定义见 docs/INTERFACE-CONTRACT.md 第 2.4 节。

    risk_data 格式见 INTERFACE-CONTRACT.md 第 3.3 节。
    """
    app_token = os.getenv("FEISHU_BITABLE_APP_TOKEN", "")
    table_id  = os.getenv("FEISHU_BITABLE_TABLE_ID", "")

    # 映射字段名（多维表格列名需要与实际创建的表格一致）
    fields = {
        "触发事件":       risk_data.get("trigger", ""),
        "时间戳":         risk_data.get("timestamp", ""),
        "久期敏感度":     risk_data.get("duration_sensitivity", 0),
        "预估最大回撤":   risk_data.get("estimated_drawdown", 0),
        "建议操作":       risk_data.get("recommendation", ""),
        "VIX":           risk_data.get("vix", 0),
        "标普变动%":      risk_data.get("sp500_change", 0),
    }

    record_id = await append_bitable_record(app_token, table_id, fields)
    return record_id
```

**验证标准（Mock 模式）**：

```bash
python -c "
import asyncio
from src.outputs.table_writer import update_risk_matrix

MOCK_RISK = {
    'timestamp': '2026-04-16T10:30:00',
    'trigger': 'Fed hawkish minutes',
    'duration_sensitivity': 0.34,
    'estimated_drawdown': -0.082,
    'recommendation': 'Reduce TLT 50%',
    'vix': 18.5,
    'sp500_change': -0.008
}

asyncio.run(update_risk_matrix(MOCK_RISK))
"
# 预期输出：[MOCK] Record saved to data/mock_risk_matrix.json
```

---

### Task 5：创建 card_builder.py（优先级最高，纯函数无 IO）

**目的**：构建飞书 interactive card JSON，美化每个 Agent 的发言（P1 功能，但无需飞书 API）。

创建 `src/outputs/card_builder.py`：

```python
# src/outputs/card_builder.py
from src.agents.types import RoleType, TagType

# 角色对应的飞书卡片主题色
ROLE_COLOR = {
    "macro_analyst":    "blue",
    "sector_analyst":   "green",
    "risk_manager":     "red",
    "chief_strategist": "orange",
}

ROLE_DISPLAY = {
    "macro_analyst":    "🔭 Macro Analyst",
    "sector_analyst":   "💡 Sector Analyst",
    "risk_manager":     "⚠️ Risk Manager",
    "chief_strategist": "🎯 Chief Strategist",
}

TAG_COLOR = {
    "ALERT":    "red",
    "DISAGREE": "yellow",
    "COUNTER":  "yellow",
    "RISK":     "red",
    "ACTION":   "green",
}

def build_agent_card(
    role: RoleType,
    content: str,
    tags: list[TagType]
) -> dict:
    """
    构建飞书 interactive card JSON。
    接口定义见 docs/INTERFACE-CONTRACT.md 第 2.4 节。
    此函数是纯函数（无 IO），无需 Mock 模式。
    """
    color = ROLE_COLOR.get(role, "blue")
    display_name = ROLE_DISPLAY.get(role, role)

    # 构建 tag 文本
    tag_elements = []
    for tag in tags:
        tag_elements.append({
            "tag": "text",
            "text": f"[{tag}] ",
            "text_color": TAG_COLOR.get(tag, "grey"),
        })

    card = {
        "config": {"wide_screen_mode": True},
        "header": {
            "title": {
                "tag": "plain_text",
                "content": display_name,
            },
            "template": color,
        },
        "elements": [
            {
                "tag": "div",
                "text": {
                    "tag": "lark_md",
                    "content": content,
                }
            },
        ]
    }

    # 如果有 tags，在底部添加 tag 标记
    if tags:
        tag_text = " | ".join(f"**[{t}]**" for t in tags)
        card["elements"].append({
            "tag": "note",
            "elements": [{
                "tag": "plain_text",
                "content": tag_text,
            }]
        })

    return card
```

**验证标准（无需任何外部服务）**：

```bash
python -c "
import json
from src.outputs.card_builder import build_agent_card

card = build_agent_card(
    role='macro_analyst',
    content='[ALERT] Fed minutes show hawkish pivot. 10Y yield at 4.8%.',
    tags=['ALERT']
)
print(json.dumps(card, indent=2, ensure_ascii=False))
assert card['header']['template'] == 'blue'
assert 'ALERT' in str(card)
print('✅ card_builder test passed')
"
# 预期输出：格式化的 JSON + ✅ card_builder test passed
```

---

### Task 6：创建 src/outputs/__init__.py

创建 `src/outputs/__init__.py`：

```python
# src/outputs/__init__.py
from src.outputs.doc_generator import generate_strategy_doc
from src.outputs.table_writer import update_risk_matrix
from src.outputs.card_builder import build_agent_card

__all__ = ["generate_strategy_doc", "update_risk_matrix", "build_agent_card"]
```

**验证标准**：

```bash
python -c "from src.outputs import generate_strategy_doc, update_risk_matrix, build_agent_card; print('outputs module OK')"
# 预期输出：outputs module OK
```

---

## 6. 本模块暴露的接口

（与 `docs/INTERFACE-CONTRACT.md` 第 2.4 节完全一致）

```python
# src/outputs/doc_generator.py
async def generate_strategy_doc(
    responses: list[AgentResponse],
    doc_title: str
) -> str: ...  # 返回文档链接或本地路径

# src/outputs/table_writer.py
async def update_risk_matrix(risk_data: dict) -> str: ...  # 返回记录 ID 或本地路径

# src/outputs/card_builder.py
def build_agent_card(
    role: RoleType,
    content: str,
    tags: list[TagType]
) -> dict: ...  # 返回飞书 card JSON
```

---

## 7. 本模块依赖的外部接口（当前用 Mock）

| 依赖 | 来源窗口 | Mock 方案 |
|------|---------|---------|
| `AgentResponse`, `RoleType`, `TagType` 类型 | 窗口 A | `from src.agents.types import ...` |

**外部服务依赖**：

| 服务 | 需要 | Mock 方案 |
|------|------|---------|
| 飞书 App ID/Secret | 文档生成 + 表格写入 | 保存到本地文件 |
| 飞书多维表格 Token | `update_risk_matrix` | 追加到本地 JSON |

---

## 8. 基座仓库中需要忽略的部分

本窗口不依赖任何需要"改造"的开源基座，而是直接使用官方 SDK 和 npm 包。

**不需要克隆**：lark-openapi-mcp 直接 npm install，lark_oapi 直接 pip install。

---

## 完成标准（Checklist）

优先级顺序：card_builder > doc_generator > table_writer

- [ ] `python -c "from src.outputs.card_builder import build_agent_card; build_agent_card('macro_analyst', 'test', ['ALERT']); print('OK')"` 无报错
- [ ] `python -c "from src.outputs import generate_strategy_doc, update_risk_matrix, build_agent_card; print('OK')"` 无报错
- [ ] Mock 模式下 `generate_strategy_doc` 将文档保存到 `data/mock_doc_*.md`
- [ ] Mock 模式下 `update_risk_matrix` 将记录追加到 `data/mock_risk_matrix.json`
- [ ] （有飞书 App 时）真实模式下文档创建成功并返回飞书文档链接
