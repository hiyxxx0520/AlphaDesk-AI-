# WINDOW-B — 飞书消息收发连接器

> **在开始之前**：先读 `CLAUDE.md` 和 `docs/INTERFACE-CONTRACT.md`，全部理解后再动手。

---

## 1. 模块职责

用 LarkAgentX（Cookie 认证，无需官方应用）实现飞书群消息的收发。消息以**单账号 + 角色前缀**方式发出，监听器在被 @ 时触发回调。本模块可在 Mock 模式下独立运行。

**产出目录**：`src/feishu/`  
**Git 分支**：`feishu-dev`（worktree 在 `../alphadesk-feishu/`）

---

## 2. 基座仓库

### cv-cat/LarkAgentX

这是逆向工程飞书 WebSocket 协议的 Python 库，用个人账号 Cookie 认证，不需要创建飞书开放平台应用。

**改造路径**：

| LarkAgentX 的能力 | 我们的用途 |
|-----------------|----------|
| WebSocket 消息接收 | 监听群消息，检测 @ 触发 |
| 发送群消息 | 发送角色前缀消息 |
| Cookie 认证 | 使用个人飞书账号 |

**不需要改造的部分**：LarkAgentX 的内部 WebSocket 实现、认证逻辑、Protobuf 解析。

---

## 3. 环境变量需求

```bash
# .env 文件中必须有以下字段（窗口 B 最小集）
FEISHU_COOKIE=session=xxx; _stoken=xxx; ...  # 必须，从浏览器获取
FEISHU_GROUP_ID=oc_xxxxxxxxxx                # 必须，目标飞书群 ID
FEISHU_MOCK=false                             # 可选，true = 只打印不发真实消息
```

---

## 4. 依赖安装

```bash
# Step 1：克隆 LarkAgentX 到临时位置并检查安装方式
git clone https://github.com/cv-cat/LarkAgentX /tmp/larkagentx-ref
cd /tmp/larkagentx-ref
cat README.md  # 查看安装说明

# Step 2：根据 README 安装（通常是以下之一）
pip install -e /tmp/larkagentx-ref
# 或
pip install larkagentx
# 或（如果有 setup.py/pyproject.toml）
cd /tmp/larkagentx-ref && pip install .

# Step 3：安装其他依赖
pip install python-dotenv

# Step 4：验证安装
python -c "import larkagentx; print('LarkAgentX installed')"
# 如果包名不同，根据实际 clone 的内容调整
```

> **注意**：LarkAgentX 是逆向项目，包名和安装方式请以 clone 后的 README 为准。如果无法 pip install，直接把 larkagentx 目录复制到项目根目录下使用（`sys.path.insert(0, '/tmp/larkagentx-ref')`）。

---

## 5. 逐步任务列表

---

### Task 0：克隆 LarkAgentX，跑通基础示例

**目的**：理解 LarkAgentX 的 API 和使用方式，再封装为我们的接口。

```bash
# Step A：克隆项目
git clone https://github.com/cv-cat/LarkAgentX /tmp/larkagentx-ref
cd /tmp/larkagentx-ref

# Step B：查看项目结构
ls -la
cat README.md           # 必读：了解 Cookie 获取方式和基本 API
ls examples/ 2>/dev/null || echo "no examples dir"
cat main.py 2>/dev/null || ls *.py  # 找入口文件

# Step C：了解核心 API
# 重点查找以下内容：
grep -r "send" . --include="*.py" | head -20     # 发送消息的 API
grep -r "listen\|on_message\|event" . --include="*.py" | head -20  # 接收消息的 API
grep -r "Cookie\|cookie\|session" . --include="*.py" | head -20    # Cookie 认证方式

# Step D：理解 group_id 格式
# 飞书群 ID 通常是 "oc_xxxxxxxxxx" 格式
# 在飞书 Web 版 URL 中可以找到：https://applink.feishu.cn/client/chat?open_chat_id=oc_xxxx
```

**验证标准**：你理解了 LarkAgentX 的以下 3 点：
1. 如何用 Cookie 初始化客户端
2. 如何向指定 group_id 发送文本消息
3. 如何监听接收到的消息

---

### Task 1：获取飞书 Cookie

**目的**：从浏览器获取飞书个人账号的 Cookie，用于 LarkAgentX 认证。

**操作步骤**：

```
1. 在浏览器打开飞书 Web 版：https://feishu.cn（或你的组织域名）
2. 登录你的飞书账号
3. 打开浏览器开发者工具（F12 或 Cmd+Option+I）
4. 切换到 "Application"（Chrome）或 "Storage"（Firefox）标签
5. 在左侧找到 "Cookies" → "https://feishu.cn"（或你的域名）
6. 找到并复制以下 Cookie（关键的通常是 "session" 或 "_stoken"）：
   - session=xxx
   - _stoken=xxx
   （具体 Cookie 名称请参考 LarkAgentX README 中的说明）
7. 将完整的 Cookie 字符串写入 .env：
   FEISHU_COOKIE=session=xxx; _stoken=xxx; [其他 cookie]
```

**验证标准**：

```bash
python -c "
import os
from dotenv import load_dotenv
load_dotenv()
cookie = os.getenv('FEISHU_COOKIE', '')
print(f'Cookie length: {len(cookie)}')
print(f'Has session: {\"session\" in cookie}')
"
# 预期输出：
# Cookie length: [>50 的数字]
# Has session: True
```

---

### Task 2：找到飞书测试群的 group_id

**目的**：确定消息要发往哪个群。

```
方法 1：飞书 Web 版 URL
  - 在浏览器打开飞书，进入目标群聊
  - 查看 URL，找到 open_chat_id 参数
  - 例：https://applink.feishu.cn/client/chat?open_chat_id=oc_xxxxxxxx
  - 复制 "oc_" 开头的 ID

方法 2：通过 LarkAgentX 的会话列表 API
  - 先用 LarkAgentX 拉取所有群聊列表
  - 找到你创建的测试群

方法 3：先发一条消息，从收到的消息体中提取 group_id
```

```bash
# 将找到的 group_id 写入 .env
echo "FEISHU_GROUP_ID=oc_xxxxxxxxxx" >> .env
```

**验证标准**：

```bash
python -c "
import os; from dotenv import load_dotenv; load_dotenv()
gid = os.getenv('FEISHU_GROUP_ID', '')
print(f'Group ID: {gid}')
print(f'Valid format: {gid.startswith(\"oc_\")}')
"
# 预期输出：
# Group ID: oc_xxxxxxxxxx
# Valid format: True
```

---

### Task 3：用 LarkAgentX 测试发送一条消息

**目的**：在封装接口之前，先直接用 LarkAgentX 的原生 API 发一条消息，确认 Cookie 和 group_id 有效。

**操作**：在 `/tmp/larkagentx-ref` 中，根据 README 的示例写一个测试脚本：

```python
# /tmp/test_send.py（在参考仓库目录内测试，不是项目目录）
import os
from dotenv import load_dotenv
load_dotenv("/Users/yyy/Desktop/飞书AI校园挑战赛/.env")

# 根据 LarkAgentX 实际 API 调整以下代码
# 可能的 API 形式（以实际 README 为准）：
#
# 形式 1：
# from larkagentx import LarkBot
# bot = LarkBot(cookie=os.getenv("FEISHU_COOKIE"))
# bot.send_message(chat_id=os.getenv("FEISHU_GROUP_ID"), text="🧪 AlphaDesk test message")
#
# 形式 2：
# from larkagentx.client import Client
# client = Client(cookie=os.getenv("FEISHU_COOKIE"))
# client.send_text(group_id=os.getenv("FEISHU_GROUP_ID"), text="🧪 test")

# 阅读 README 并使用正确的 API
```

**验证标准**：飞书测试群里出现消息 "🧪 AlphaDesk test message"，无报错。

---

### Task 4：创建 sender.py，封装 send_to_group()

**目的**：在 LarkAgentX 原生 API 基础上，封装为标准接口（含角色前缀、mock 模式）。

创建 `src/feishu/sender.py`：

```python
# src/feishu/sender.py
import asyncio
import os
from dotenv import load_dotenv
from src.agents.types import RoleType, TagType

load_dotenv()

# 角色前缀映射（接口契约定义，此处是权威定义）
ROLE_PREFIX: dict[str, str] = {
    "macro_analyst":    "🔭 [Macro Analyst]",
    "sector_analyst":   "💡 [Sector Analyst]",
    "risk_manager":     "⚠️ [Risk Manager]",
    "chief_strategist": "🎯 [Chief Strategist]",
}

FEISHU_MOCK = os.getenv("FEISHU_MOCK", "false").lower() == "true"
FEISHU_COOKIE = os.getenv("FEISHU_COOKIE", "")

def _get_client():
    """
    返回 LarkAgentX 客户端实例。
    根据 clone 的实际 API 调整此函数内部实现。
    """
    # TODO：根据 /tmp/larkagentx-ref/README.md 确认正确的初始化方式
    # 示例（以实际 API 为准）：
    # from larkagentx import LarkBot
    # return LarkBot(cookie=FEISHU_COOKIE)
    raise NotImplementedError("根据 LarkAgentX README 实现此函数")

async def send_to_group(
    group_id: str,
    message: str,
    identity: RoleType,
    message_type: str = "text"
) -> bool:
    """
    以对应角色前缀发送消息到指定飞书群。
    接口定义见 docs/INTERFACE-CONTRACT.md 第 2.2 节。
    """
    prefix = ROLE_PREFIX.get(identity, f"[{identity}]")
    full_message = f"{prefix}\n{message}"

    if FEISHU_MOCK:
        print(f"\n[MOCK→{group_id}]")
        print(full_message)
        print("-" * 40)
        return True

    try:
        client = _get_client()
        # TODO：根据 LarkAgentX 实际 API 调整发送方式
        # 示例（以实际 API 为准）：
        # client.send_message(chat_id=group_id, text=full_message)
        return True
    except Exception as e:
        print(f"[send_to_group] Error: {e}")
        return False


# 快速测试
if __name__ == "__main__":
    import asyncio
    from dotenv import load_dotenv
    load_dotenv()

    group_id = os.getenv("FEISHU_GROUP_ID", "oc_test")

    async def test():
        # Mock 模式测试（不需要真实 Cookie）
        os.environ["FEISHU_MOCK"] = "true"

        for role in ["macro_analyst", "sector_analyst", "risk_manager", "chief_strategist"]:
            result = await send_to_group(
                group_id=group_id,
                message=f"[ALERT] This is a test message from {role}.",
                identity=role,
            )
            print(f"send_to_group({role}) -> {result}")

    asyncio.run(test())
```

**验证标准（Mock 模式）**：

```bash
FEISHU_MOCK=true python -m src.feishu.sender
# 预期输出：
# [MOCK→oc_test]
# 🔭 [Macro Analyst]
# [ALERT] This is a test message from macro_analyst.
# ----------------------------------------
# send_to_group(macro_analyst) -> True
# ... (4 个角色各一条)
```

---

### Task 5：创建 listener.py，封装 start_listener()

**目的**：监听飞书群消息，在被 @ 时触发回调。

创建 `src/feishu/listener.py`：

```python
# src/feishu/listener.py
import asyncio
import os
import sys
from typing import Callable, Awaitable
from dotenv import load_dotenv

load_dotenv()

FEISHU_MOCK  = os.getenv("FEISHU_MOCK", "false").lower() == "true"
FEISHU_COOKIE = os.getenv("FEISHU_COOKIE", "")

def _is_bot_mention(message_text: str) -> bool:
    """
    判断消息是否包含 @ 机器人。
    根据 LarkAgentX 的消息格式调整判断逻辑。
    """
    # 常见的触发词（根据实际测试调整）
    triggers = ["@AlphaDesk", "@alphadesk", "alphadesk"]
    lower = message_text.lower()
    return any(t.lower() in lower for t in triggers)

def _clean_message(message_text: str) -> str:
    """去除 @ 部分，返回用户实际想说的内容。"""
    import re
    # 去除 @XXX 格式
    cleaned = re.sub(r'@\S+', '', message_text).strip()
    return cleaned

async def start_listener(
    callback: Callable[[str, str], Awaitable[None]]
) -> None:
    """
    启动飞书消息监听，当机器人被 @ 时触发回调。
    接口定义见 docs/INTERFACE-CONTRACT.md 第 2.2 节。
    """
    if FEISHU_MOCK:
        print("[Listener] Mock mode: reading from stdin. Format: group_id::message")
        print("[Listener] Example: oc_test123::分析一下美联储最新会议纪要")
        print("[Listener] Ctrl+C to stop.\n")
        while True:
            try:
                line = await asyncio.get_event_loop().run_in_executor(
                    None, sys.stdin.readline
                )
                line = line.strip()
                if not line:
                    continue
                if "::" in line:
                    group_id, user_message = line.split("::", 1)
                    print(f"[Listener] Received: '{user_message}' from group {group_id}")
                    await callback(user_message, group_id)
                else:
                    print("[Listener] Invalid format. Use: group_id::message")
            except KeyboardInterrupt:
                print("\n[Listener] Stopped.")
                break
        return

    # 真实模式：使用 LarkAgentX 监听
    # TODO：根据 /tmp/larkagentx-ref/README.md 实现
    # 示例（以实际 API 为准）：
    #
    # from larkagentx import LarkBot
    # bot = LarkBot(cookie=FEISHU_COOKIE)
    #
    # @bot.on_message
    # async def on_msg(event):
    #     text = event.get("text", "")
    #     chat_id = event.get("chat_id", "")
    #     if _is_bot_mention(text):
    #         clean = _clean_message(text)
    #         await callback(clean, chat_id)
    #
    # await bot.start()
    raise NotImplementedError("根据 LarkAgentX README 实现真实监听逻辑")
```

**验证标准（Mock 模式）**：

```bash
FEISHU_MOCK=true python -c "
import asyncio
from src.feishu.listener import start_listener

async def my_callback(msg, gid):
    print(f'Callback triggered: msg={msg!r}, group={gid}')

asyncio.run(start_listener(my_callback))
"
# 然后在终端输入：oc_test123::分析美联储
# 预期输出：Callback triggered: msg='分析美联储', group='oc_test123'
```

---

### Task 6：实现真实飞书发送（根据 LarkAgentX 实际 API）

**目的**：完成 `sender.py` 中 `_get_client()` 和发送逻辑的实现。

```bash
# 参照 /tmp/larkagentx-ref/README.md 和 examples/
# 重点查找：
# 1. 客户端初始化方式
# 2. 发送文本消息的方法名
# 3. 参数格式（chat_id 还是 group_id？text 还是 content？）
```

在 `src/feishu/sender.py` 中，将 `_get_client()` 和 `send_to_group()` 中的 TODO 补全。

**验证标准**：

```bash
# 真实模式（需要有效 Cookie 和 group_id）
python -c "
import asyncio, os
from dotenv import load_dotenv
load_dotenv()
from src.feishu.sender import send_to_group

async def test():
    result = await send_to_group(
        group_id=os.getenv('FEISHU_GROUP_ID'),
        message='[ALERT] AlphaDesk integration test.',
        identity='macro_analyst'
    )
    print(f'Send result: {result}')

asyncio.run(test())
"
# 预期：飞书群出现消息 "🔭 [Macro Analyst]\n[ALERT] AlphaDesk integration test."
```

---

### Task 7：实现真实飞书监听（根据 LarkAgentX 实际 API）

**目的**：完成 `listener.py` 中真实模式的 WebSocket 监听逻辑。

在 `src/feishu/listener.py` 中，将 TODO 部分替换为实际的 LarkAgentX 事件监听代码。

**验证标准**：

```bash
# 真实模式：启动监听
FEISHU_MOCK=false python -c "
import asyncio
from src.feishu.listener import start_listener

async def test_callback(msg, gid):
    print(f'[TRIGGER] msg={msg!r}, group={gid}')

asyncio.run(start_listener(test_callback))
"
# 然后在飞书测试群里发 "@AlphaDesk 分析美联储"
# 预期终端输出：[TRIGGER] msg='分析美联储', group='oc_xxx'
```

---

## 6. 本模块暴露的接口

（与 `docs/INTERFACE-CONTRACT.md` 第 2.2 节完全一致，不得修改签名）

```python
# src/feishu/sender.py
ROLE_PREFIX: dict[str, str]  # 角色前缀映射（其他模块可 import 使用）

async def send_to_group(
    group_id: str,
    message: str,
    identity: RoleType,
    message_type: str = "text"
) -> bool: ...

# src/feishu/listener.py
async def start_listener(
    callback: Callable[[str, str], Awaitable[None]]
) -> None: ...
```

---

## 7. 本模块依赖的外部接口（当前用 Mock）

| 依赖 | 来源窗口 | Mock 方案 |
|------|---------|---------|
| `AgentResponse`, `RoleType` 类型 | 窗口 A | `from src.agents.types import RoleType` — 如果 A 未完成，临时用 `str` 替代 |

---

## 8. 基座仓库中需要忽略的部分

LarkAgentX 中不需要关注的部分：

| 功能 | 原因 |
|------|------|
| LarkAgentX 自带的 AI 功能（如有） | 我们用自己的 CrewAI |
| 数据库存储（如有） | MVP 不需要持久化 |
| 多账号管理（如有） | 我们只用单账号 + 前缀方案 |
| Web UI（如有） | 我们只需要 Python API |

---

## 完成标准（Checklist）

在进行窗口 E 集成前，确认以下全部通过：

- [ ] `FEISHU_MOCK=true python -m src.feishu.sender` 输出 4 个角色的带前缀消息，无报错
- [ ] Mock 模式下 `start_listener` 能从 stdin 读取并触发 callback
- [ ] 真实模式（需要有效 Cookie）：飞书群里能收到带角色前缀的消息
- [ ] `from src.feishu.sender import send_to_group, ROLE_PREFIX` 无 ImportError
- [ ] `from src.feishu.listener import start_listener` 无 ImportError
- [ ] Cookie 只从 `.env` 读取，不硬编码
