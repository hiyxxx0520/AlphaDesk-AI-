# AlphaDesk — 接口契约

> **权威文档**：所有模块间接口以本文件为准。任何窗口不得单方面修改接口定义。
> 修改需通知所有相关窗口并同步更新 CLAUDE.md。

---

## 1. 核心数据类型

### 1.1 AgentResponse

```python
# 位置：src/agents/types.py
# 所有模块统一使用此定义，不得重新定义

from typing import TypedDict, Literal

RoleType = Literal[
    "macro_analyst",
    "sector_analyst",
    "risk_manager",
    "chief_strategist"
]

TagType = Literal[
    "ALERT",      # 紧急市场信号（Macro Analyst 常用）
    "DISAGREE",   # 反对上一个观点
    "COUNTER",    # 提供反向论据
    "RISK",       # 风险警报（Risk Manager 专用）
    "ACTION"      # 最终行动决策（Chief Strategist 专用）
]

class AgentResponse(TypedDict):
    role:    RoleType        # 发言角色标识符
    content: str             # 消息正文（英文为主，3-5 句话）
    tags:    list[TagType]   # 角色标签，可多个
```

### 1.2 角色前缀映射（窗口 B 使用）

```python
# 位置：src/feishu/sender.py（从此处 import，不要重复定义）

ROLE_PREFIX: dict[RoleType, str] = {
    "macro_analyst":    "🔭 [Macro Analyst]",
    "sector_analyst":   "💡 [Sector Analyst]",
    "risk_manager":     "⚠️ [Risk Manager]",
    "chief_strategist": "🎯 [Chief Strategist]",
}

# 最终发送到飞书群的消息格式：
# f"{ROLE_PREFIX[role]}\n{content}"
```

---

## 2. 模块间函数签名

### 2.1 窗口 A — CrewAI 多 Agent 核心

```python
# 位置：src/agents/crew.py
# 调用方：窗口 E（orchestrator.py）

def run_analysis(
    trigger_event: str,
    market_data: dict | None = None
) -> list[AgentResponse]:
    """
    触发一轮完整的 4-Agent 投研分析。

    参数：
        trigger_event: 触发事件的自然语言描述
                       例：'Fed released hawkish FOMC minutes, 10Y yield jumped to 4.8%'
        market_data:   可选的市场数据字典（由窗口 C 的工具获取）
                       例：{'sp500': -0.8, 'usd_cny': 7.25, 'vix': 18.5}

    返回：
        按发言顺序排列的 4 个 AgentResponse 列表：
        [macro_analyst, sector_analyst, risk_manager, chief_strategist]

    示例返回值：
        [
            {
                "role": "macro_analyst",
                "content": "[ALERT] Fed minutes show hawkish pivot...",
                "tags": ["ALERT"]
            },
            {
                "role": "sector_analyst",
                "content": "[DISAGREE] Tech P/E compression already priced in...",
                "tags": ["DISAGREE"]
            },
            {
                "role": "risk_manager",
                "content": "[RISK] Portfolio duration sensitivity at 34%...",
                "tags": ["RISK"]
            },
            {
                "role": "chief_strategist",
                "content": "[ACTION] Consensus reached. Action plan: 1) Reduce TLT 50%...",
                "tags": ["ACTION"]
            }
        ]
    """
```

### 2.2 窗口 B — 飞书消息收发

```python
# 位置：src/feishu/sender.py
# 调用方：窗口 E（orchestrator.py）

async def send_to_group(
    group_id: str,       # 飞书群 ID，格式 "oc_xxxxxxxxxx"
    message: str,        # 消息正文（不含角色前缀，函数内部添加）
    identity: RoleType,  # 角色标识，用于查找前缀
    message_type: str = "text"  # "text" | "interactive"（卡片，P1功能）
) -> bool:
    """
    以对应角色前缀发送消息到指定飞书群。

    消息最终格式（发到群里）：
        🔭 [Macro Analyst]
        [ALERT] Fed minutes show hawkish pivot...

    返回：
        True = 发送成功，False = 发送失败（已打印错误）

    Mock 模式（FEISHU_MOCK=true 时）：
        print(f"[MOCK→{group_id}] {ROLE_PREFIX[identity]}\\n{message}")
        return True
    """
```

```python
# 位置：src/feishu/listener.py
# 调用方：窗口 E（main.py / orchestrator.py）

from typing import Callable, Awaitable

async def start_listener(
    callback: Callable[[str, str], Awaitable[None]]
) -> None:
    """
    启动飞书消息监听，当机器人被 @ 时触发回调。

    参数：
        callback: 异步回调函数，签名为 callback(user_message, group_id)
                  user_message: 用户发送的消息文本（已去除 @机器人 部分）
                  group_id:     消息所在的群 ID

    触发条件：
        消息中包含 @机器人 的文本（具体检测方式见 listener.py 实现）

    Mock 模式（FEISHU_MOCK=true 时）：
        从 stdin 读取输入，格式 "group_id::message"
        例：oc_test123::分析一下美联储最新会议纪要
    """
```

### 2.3 窗口 C — 金融数据工具层

```python
# 位置：src/tools/__init__.py
# 调用方：窗口 A（crew.py 在 Agent 初始化时调用）

from crewai.tools import BaseTool

def get_all_tools() -> list[BaseTool]:
    """
    返回所有可用的 CrewAI Tools 实例列表。

    当前包含：
        - AKShareTool：A 股行情 + 中国宏观数据
        - YFinanceTool：美股 + 全球市场数据

    每个 Tool 的 _run(query: str) -> str 支持的查询格式：
        "get_price:000001"      → A 股实时价格（AKShare）
        "get_price:AAPL"        → 美股实时价格（yfinance）
        "get_index:000300"      → 指数数据（AKShare）
        "get_macro:cpi"         → 中国 CPI（AKShare）
        "get_forex:USDCNY"      → 汇率（AKShare）

    离线模式（DEMO_MODE=true 时）：
        返回 DemoDataTool，从 data/demo_data.json 读取预缓存数据
    """
```

### 2.4 窗口 D — 飞书输出集成

```python
# 位置：src/outputs/doc_generator.py
# 调用方：窗口 E（orchestrator.py，P1 功能）

async def generate_strategy_doc(
    responses: list[AgentResponse],
    doc_title: str   # 例："AlphaDesk Strategy Report - 2026-04-16"
) -> str:
    """
    根据 4 个 Agent 的分析结果，自动生成飞书文档（策略备忘录）。

    返回：
        飞书文档的访问链接，例 "https://xxx.feishu.cn/docs/xxxxxxxx"

    Mock 模式（FEISHU_APP_ID 未设置时）：
        将 markdown 内容写入 data/mock_doc_{timestamp}.md
        返回本地文件路径
    """
```

```python
# 位置：src/outputs/table_writer.py

async def update_risk_matrix(
    risk_data: dict
) -> str:
    """
    将风险矩阵数据写入飞书多维表格。

    risk_data 格式：
        {
            "timestamp": "2026-04-16T10:30:00",
            "trigger": "Fed hawkish minutes",
            "duration_sensitivity": 0.34,
            "estimated_drawdown": -0.082,
            "recommendation": "Reduce TLT 50%",
            "vix": 18.5,
            "sp500_change": -0.008
        }

    返回：多维表格链接

    Mock 模式：写入 data/mock_risk_matrix.json，返回本地路径
    """
```

```python
# 位置：src/outputs/card_builder.py
# 调用方：窗口 E（通过 send_to_group(message_type="interactive") 传入）

def build_agent_card(
    role: RoleType,
    content: str,
    tags: list[TagType]
) -> dict:
    """
    构建飞书 interactive card JSON（富文本卡片）。

    返回符合飞书卡片消息规范的 dict，可直接传入飞书 API。

    卡片设计：
        - 标题：角色名 + emoji（如 "🔭 Macro Analyst"）
        - 颜色主题：
            macro_analyst    → blue
            sector_analyst   → green
            risk_manager     → red
            chief_strategist → orange
        - 正文：content
        - 标签 badge：tags 中的每个 TagType

    注意：此函数是纯函数（无 IO），不需要 mock 模式。
    """
```

### 2.5 窗口 E — Orchestrator

```python
# 位置：src/orchestrator.py

async def handle_trigger(
    user_message: str,   # 用户在飞书群发送的消息（已去除 @ 部分）
    group_id: str        # 消息所在的飞书群 ID
) -> None:
    """
    主编排函数。从飞书监听器回调，协调整个分析流程：
    1. 调用 run_analysis(user_message) → list[AgentResponse]
    2. 逐条调用 send_to_group()，每条之间 delay 1-2 秒
    3. （P1）调用 generate_strategy_doc() 生成飞书文档
    4. （P1）调用 update_risk_matrix() 更新多维表格

    无返回值，副作用是向飞书群发送 4 条消息。
    """
```

---

## 3. Mock 数据示例

### 3.1 run_analysis() 返回值 Mock

```json
[
  {
    "role": "macro_analyst",
    "content": "[ALERT] Fed minutes show hawkish pivot. 10Y yield surged to 4.8%, signaling rate cuts delayed to Q4 2026. Rate-sensitive assets under broad pressure. @Sector @Risk please assess.",
    "tags": ["ALERT"]
  },
  {
    "role": "sector_analyst",
    "content": "[DISAGREE] Not a blanket sell. Tech P/E compression already priced in Q1. Real risk concentrated in REITs and utilities — $VNQ and $XLU showing vulnerability. Growth tech may outperform on relative basis.",
    "tags": ["DISAGREE"]
  },
  {
    "role": "risk_manager",
    "content": "[RISK] Portfolio risk check complete. Duration sensitivity: 34%. Estimated drawdown if 10Y breaks 5.0%: -8.2%. Recommend halving $TLT position. Risk matrix updated to bitable.",
    "tags": ["RISK"]
  },
  {
    "role": "chief_strategist",
    "content": "[ACTION] Consensus reached. Agreed with SA on REIT vulnerability and RM on duration risk. Action plan: 1) Reduce $TLT 50% 2) Rotate to short-duration credit 3) Buy REIT put hedge. Full report generated to Feishu Docs.",
    "tags": ["ACTION"]
  }
]
```

### 3.2 market_data 参数 Mock

```json
{
  "sp500_change_pct": -0.8,
  "nasdaq_change_pct": -1.2,
  "us_10y_yield": 4.8,
  "usd_cny": 7.25,
  "vix": 18.5,
  "gold_price": 2320.5,
  "crude_oil_price": 82.3
}
```

### 3.3 risk_data 参数 Mock

```json
{
  "timestamp": "2026-04-16T10:30:00",
  "trigger": "Fed hawkish FOMC minutes",
  "duration_sensitivity": 0.34,
  "estimated_drawdown": -0.082,
  "recommendation": "Reduce TLT 50%, rotate to short-duration credit",
  "vix": 18.5,
  "sp500_change": -0.008
}
```

---

## 4. 环境变量完整清单

```bash
# LLM
DEEPSEEK_API_KEY=sk-xxxx          # DeepSeek API Key（必须）
LLM_BASE_URL=https://api.deepseek.com  # 可切换为豆包等兼容接口
LLM_MODEL=deepseek-chat            # 模型名

# 飞书
FEISHU_COOKIE=session=xxx; ...     # 窗口 B：LarkAgentX Cookie 认证
FEISHU_GROUP_ID=oc_xxxxxxxxxx      # 目标飞书群 ID
FEISHU_APP_ID=cli_xxxxx            # 窗口 D：官方 App ID（可选，D 窗口需要）
FEISHU_APP_SECRET=xxxxx            # 窗口 D：官方 App Secret（可选）
FEISHU_BITABLE_APP_TOKEN=xxxxx     # 窗口 D：多维表格 App Token（可选）
FEISHU_BITABLE_TABLE_ID=xxxxx      # 窗口 D：多维表格 Table ID（可选）

# 模式控制
FEISHU_MOCK=false                  # true = 不发真实飞书消息，只打印到终端
DEMO_MODE=false                    # true = 金融工具返回缓存 Demo 数据

# 网络（如需代理）
HTTP_PROXY=http://127.0.0.1:7890
HTTPS_PROXY=http://127.0.0.1:7890
```

---

## 5. 文件命名与导入规范

```python
# 正确的导入方式（各模块从固定路径导入）
from src.agents.types import AgentResponse, RoleType, TagType
from src.agents.crew import run_analysis
from src.feishu.sender import send_to_group, ROLE_PREFIX
from src.feishu.listener import start_listener
from src.tools import get_all_tools
from src.outputs.doc_generator import generate_strategy_doc
from src.outputs.table_writer import update_risk_matrix
from src.outputs.card_builder import build_agent_card
```
