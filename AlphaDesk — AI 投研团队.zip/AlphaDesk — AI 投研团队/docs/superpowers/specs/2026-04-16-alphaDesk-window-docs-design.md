# AlphaDesk 窗口任务文档生成 — 设计文档

**日期**：2026-04-16  
**状态**：已批准，执行中

---

## 背景

AlphaDesk 是飞书 AI 校园挑战赛参赛项目，在飞书群里部署 4 个 AI Agent 角色（Macro Analyst / Sector Analyst / Risk Manager / Chief Strategist）自主讨论投研观点。项目采用多窗口并行开发策略，本设计文档记录 5 个窗口任务文档的生成规范。

## 核心决策（已确认）

| 决策项 | 选择 | 原因 |
|--------|------|------|
| 窗口 B 飞书方案 | LarkAgentX（方案 2，Cookie 认证） | 用户飞书账号仅完成注册，无官方应用 |
| 多身份发送 | 单账号 + 角色前缀文本 | 无法立即获取多个飞书账号 |
| CrewAI 流程 | Sequential Process | MVP 最简实现，botextractai 示例相同模式 |
| 文档方案 | 方案 C（契约锁定 + 步骤指引） | 接口锁死保一致，步骤指引保灵活 |
| 数据类型 | Python TypedDict | 轻量无依赖，hackathon MVP |
| LLM 后端 | DeepSeek API（OpenAI 兼容） | 便宜快速，env var 可切换 |

## 生成文件清单

```
飞书AI校园挑战赛/
├── CLAUDE.md
├── docs/
│   ├── INTERFACE-CONTRACT.md
│   └── windows/
│       ├── WINDOW-A-agents.md
│       ├── WINDOW-B-feishu.md
│       ├── WINDOW-C-tools.md
│       ├── WINDOW-D-outputs.md
│       └── WINDOW-E-integration.md
```

## 窗口文档模板（8 节）

1. 模块职责（1 句话）
2. 基座仓库（clone → 跑示例 → 改哪些文件）
3. 环境变量需求
4. 依赖安装（完整命令）
5. 逐步任务列表（Task 0 = 基座仓库跑通）
6. 本模块暴露的接口（与 INTERFACE-CONTRACT 100% 一致）
7. 本模块依赖的外部接口（当前用 mock）
8. 基座仓库中需要忽略的部分

## 窗口间依赖

- A / B / C：并行，各自有完整 mock，可独立运行
- D：依赖飞书 API 可用，有本地 fallback
- E：依赖 A + B 完成后启动
