# AlphaDesk — AI 投研团队 · 飞书 AI 校园挑战赛

> 读完本文件后，你对整个项目有完整认知，可以直接进入自己负责的模块开发。

---

## 项目概述

在飞书群里部署 4 个角色的 AI Agent，自主监控市场、互相辩论、协作产出投研报告。

- **参赛截止**：2026-04-17 23:59（极度紧张，MVP 优先）
- **复赛**：2026-05-06 | **决赛答辩**：2026-05-14
- **核心原则**：不从零开发，用开源积木拼装，核心工作量放在 Prompt 设计和金融逻辑上

### 4 个 Agent 角色

| 角色 | 英文名 | 标签 | 分析框架 |
|------|--------|------|----------|
| 宏观分析师 | Macro Analyst | `[ALERT]` | Top-down，监控央行/收益率/地缘 |
| 行业研究员 | Sector Analyst | `[DISAGREE]` | Bottom-up，挑战共识观点 |
| 风控官 | Risk Manager | `[RISK]` | VaR / 回撤 / 压力测试 |
| 首席策略师 | Chief Strategist | `[ACTION]` | 多因子综合，最终决策 |

---

## 目录结构

```
飞书AI校园挑战赛/           ← 项目根（git root）
├── AGENTS.md               ← 本文件，所有窗口必读
├── .env                    ← 真实凭证（不提交 git）
├── .env.example            ← 环境变量模板
├── pyproject.toml
├── requirements.txt
│
├── src/
│   ├── __init__.py
│   ├── agents/             ← 窗口 A 负责
│   │   ├── __init__.py
│   │   ├── types.py        ← AgentResponse TypedDict
│   │   ├── agents.py       ← 4 个 Agent 定义
│   │   ├── tasks.py        ← 4 个 Task 定义
│   │   └── crew.py         ← Crew 编排，暴露 run_analysis()
│   ├── feishu/             ← 窗口 B 负责
│   │   ├── __init__.py
│   │   ├── sender.py       ← send_to_group()
│   │   └── listener.py     ← start_listener()
│   ├── tools/              ← 窗口 C 负责
│   │   ├── __init__.py     ← get_all_tools()
│   │   ├── akshare_tool.py
│   │   └── yfinance_tool.py
│   ├── outputs/            ← 窗口 D 负责
│   │   ├── __init__.py
│   │   ├── doc_generator.py
│   │   ├── table_writer.py
│   │   └── card_builder.py
│   └── orchestrator.py     ← 窗口 E 负责
│
├── config/
│   └── settings.py         ← LLM 配置 + 所有 env 读取
├── data/
│   └── demo_data.json      ← 离线 Demo 缓存数据
├── tests/
└── docs/
    ├── INTERFACE-CONTRACT.md   ← 接口契约（权威文档）
    └── windows/
        ├── WINDOW-A-agents.md
        ├── WINDOW-B-feishu.md
        ├── WINDOW-C-tools.md
        ├── WINDOW-D-outputs.md
        └── WINDOW-E-integration.md
```

---

## 基座仓库清单

| 窗口 | 基座仓库 | 本地参考路径 |
|------|---------|------------|
| A | `botextractai/ai-crewai-multi-agent` | `/tmp/botextractai-ref/` |
| A（参考） | `wyne1/financial-analyst-crewai` | `/tmp/wyne1-ref/` |
| B | `cv-cat/LarkAgentX` | `/tmp/larkagentx-ref/` |
| C | botextractai tools/ 封装模式（同上） | 参考 A 的 clone |
| D | `larksuite/lark-openapi-mcp`（npm） | 全局安装 |

---

## 接口约定

**权威文档**：`docs/INTERFACE-CONTRACT.md`

所有模块间函数签名以该文件为准。如有冲突，以 INTERFACE-CONTRACT.md 为准，不得在窗口内单方面修改。

### 核心数据类型（速查）

```python
# src/agents/types.py
from typing import TypedDict, Literal

RoleType = Literal["macro_analyst", "sector_analyst", "risk_manager", "chief_strategist"]
TagType  = Literal["ALERT", "DISAGREE", "COUNTER", "RISK", "ACTION"]

class AgentResponse(TypedDict):
    role:    RoleType
    content: str
    tags:    list[TagType]
```

### 模块间函数签名（速查）

```python
# 窗口 A
def run_analysis(trigger_event: str, market_data: dict | None = None) -> list[AgentResponse]: ...

# 窗口 B
async def send_to_group(group_id: str, message: str, identity: RoleType, message_type: str = "text") -> bool: ...
async def start_listener(callback: Callable[[str, str], Awaitable[None]]) -> None: ...

# 窗口 C
def get_all_tools() -> list[BaseTool]: ...

# 窗口 D
async def generate_strategy_doc(responses: list[AgentResponse], doc_title: str) -> str: ...
async def update_risk_matrix(risk_data: dict) -> str: ...
def build_agent_card(role: RoleType, content: str, tags: list[TagType]) -> dict: ...

# 窗口 E
async def handle_trigger(user_message: str, group_id: str) -> None: ...
```

---

## LLM 配置

- **主力**：DeepSeek API（OpenAI 兼容接口）
  - `base_url = "https://api.deepseek.com"`
  - `model = "deepseek-chat"`
  - `api_key = os.getenv("DEEPSEEK_API_KEY")`
- **备选**：豆包/Doubao（如赛方要求字节系产品则切换）
- **配置方式**：全部走 `.env` + `config/settings.py`，不硬编码

---

## 飞书方案说明

- **窗口 B 方案**：LarkAgentX（方案 2），Cookie 认证，无需创建官方应用
- **多身份策略**：单账号 + 角色前缀文本（不是多账号）
  ```python
  ROLE_PREFIX = {
      "macro_analyst":    "🔭 [Macro Analyst]",
      "sector_analyst":   "💡 [Sector Analyst]",
      "risk_manager":     "⚠️ [Risk Manager]",
      "chief_strategist": "🎯 [Chief Strategist]",
  }
  ```
- **消息格式**：`{ROLE_PREFIX[role]}\n{content}`

---

## 代码规范（MVP 模式）

- **类型提示**：Python 3.11+ 语法（`X | None` 而非 `Optional[X]`）
- **MVP 优先**：能跑就行，不追求代码完美
- **配置**：全部走环境变量 + `config/settings.py`，不硬编码 API key
- **错误处理**：只在系统边界（外部 API 调用）加 try/except，内部逻辑不过度包装
- **网络环境**：日本东京，部分 API 可能需要代理（HTTP_PROXY / HTTPS_PROXY）

---

## Superpowers 调整（MVP 模式）

- **TDD 简化**：只对模块间接口函数写测试，内部实现不强制测试覆盖
- **Code review 放宽**：spec compliance 审查保留，code quality style 问题不阻塞
- **brainstorm 限时**：设计讨论 ≤ 15 分钟，不追求完美设计
- **Task 粒度**：每个 task 5-10 分钟（而非默认 2-5 分钟）

---

## Git Worktree 分支

```bash
# 在项目根目录执行（只需一次）
git init && git add -A && git commit -m "init: project structure and docs"

# 为各窗口创建 worktree
git worktree add ../alphadesk-agents  agents-dev    # 窗口 A
git worktree add ../alphadesk-feishu  feishu-dev    # 窗口 B
git worktree add ../alphadesk-tools   tools-dev     # 窗口 C
git worktree add ../alphadesk-outputs outputs-dev   # 窗口 D
# 窗口 E 在 main 分支工作
```

| 分支 | 目录 | 负责窗口 |
|------|------|---------|
| `main` | `飞书AI校园挑战赛/` | 窗口 E（集成） |
| `agents-dev` | `../alphadesk-agents/` | 窗口 A |
| `feishu-dev` | `../alphadesk-feishu/` | 窗口 B |
| `tools-dev` | `../alphadesk-tools/` | 窗口 C |
| `outputs-dev` | `../alphadesk-outputs/` | 窗口 D |

---

## 注意事项

- 飞书凭证（Cookie / App ID / App Secret）在 `.env` 文件中，**不提交 git**
- `.gitignore` 必须包含 `.env` 和 `__pycache__/`
- 每个窗口只修改自己负责目录内的文件，减少 merge 冲突
- `docs/INTERFACE-CONTRACT.md` 是共享文件，修改需通知所有窗口
