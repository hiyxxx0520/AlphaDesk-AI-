import os
import sys
from functools import lru_cache
from pathlib import Path

from dotenv import load_dotenv

from src.agents.types import RoleType

PACKAGE_ROOT = Path(__file__).resolve().parents[2]
PROJECT_ROOT = Path(__file__).resolve().parents[3]

load_dotenv(PACKAGE_ROOT / ".env")
load_dotenv(PROJECT_ROOT / ".env")

ROLE_PREFIX: dict[RoleType, str] = {
    "macro_analyst": "🔭 [Macro Analyst]",
    "sector_analyst": "💡 [Sector Analyst]",
    "risk_manager": "⚠️ [Risk Manager]",
    "chief_strategist": "🎯 [Chief Strategist]",
}

LARKAGENTX_PATH = os.getenv("LARKAGENTX_PATH", "/tmp/larkagentx-ref")


def _is_mock_mode() -> bool:
    return os.getenv("FEISHU_MOCK", "false").lower() == "true"


def _get_cookie() -> str:
    return os.getenv("FEISHU_COOKIE", "").strip()


def _ensure_larkagentx_path() -> None:
    if LARKAGENTX_PATH not in sys.path:
        sys.path.insert(0, LARKAGENTX_PATH)


@lru_cache(maxsize=1)
def _get_client():
    """
    Return a cached LarkAgentX client instance.

    LarkAgentX uses numeric chat IDs internally, even though the higher-level
    interface contract names this field `group_id`.
    """
    cookie = _get_cookie()
    if not cookie:
        raise ValueError("FEISHU_COOKIE is not set")

    _ensure_larkagentx_path()

    from app.api.auth import LarkAuth
    from app.api.lark_client import LarkClient

    auth = LarkAuth(cookie)
    return LarkClient(auth)


async def send_to_group(
    group_id: str,
    message: str,
    identity: RoleType,
    message_type: str = "text",
) -> bool:
    """
    Send one message to a Feishu chat with a role prefix.

    The interface matches docs/INTERFACE-CONTRACT.md exactly.
    """
    prefix = ROLE_PREFIX[identity]
    full_message = f"{prefix}\n{message}"

    if _is_mock_mode():
        print(f"[MOCK→{group_id}] {full_message}")
        return True

    if not group_id:
        print("[send_to_group] Error: empty group_id")
        return False

    if message_type != "text":
        print(
            f"[send_to_group] Warning: message_type={message_type!r} "
            "is not supported by LarkAgentX yet, falling back to text."
        )

    try:
        client = _get_client()
        response = client.send_msg(full_message, str(group_id))
        ok = response.status_code == 200
        if not ok:
            print(
                f"[send_to_group] Error: status_code={response.status_code} "
                f"body={response.text[:300]}"
            )
        return ok
    except Exception as exc:
        print(f"[send_to_group] Error: {exc}")
        return False


if __name__ == "__main__":
    import asyncio

    async def test() -> None:
        group_id = os.getenv("FEISHU_GROUP_ID", "oc_test")
        for role in ROLE_PREFIX:
            result = await send_to_group(
                group_id=group_id,
                message=f"[ALERT] This is a test message from {role}.",
                identity=role,
            )
            print(f"send_to_group({role}) -> {result}")

    asyncio.run(test())
