import asyncio
import os
import re
import sys
from pathlib import Path
from typing import Awaitable, Callable

from dotenv import load_dotenv

PACKAGE_ROOT = Path(__file__).resolve().parents[2]
PROJECT_ROOT = Path(__file__).resolve().parents[3]

load_dotenv(PACKAGE_ROOT / ".env")
load_dotenv(PROJECT_ROOT / ".env")

LARKAGENTX_PATH = os.getenv("LARKAGENTX_PATH", "/tmp/larkagentx-ref")


def _is_mock_mode() -> bool:
    return os.getenv("FEISHU_MOCK", "false").lower() == "true"


def _ensure_larkagentx_path() -> None:
    if LARKAGENTX_PATH not in sys.path:
        sys.path.insert(0, LARKAGENTX_PATH)


def _is_bot_mention(message_text: str) -> bool:
    """
    Detect whether the incoming text looks like an @AlphaDesk trigger.
    """
    triggers = ["@AlphaDesk", "@alphadesk", "AlphaDesk", "alphadesk"]
    lower = message_text.lower()
    return any(trigger.lower() in lower for trigger in triggers)


def _clean_message(message_text: str) -> str:
    """Remove @mentions and surrounding whitespace from a message."""
    cleaned = re.sub(r"@\S+", "", message_text).strip()
    return re.sub(r"\s+", " ", cleaned).strip()


async def start_listener(
    callback: Callable[[str, str], Awaitable[None]],
) -> None:
    """
    Start Feishu message listening and invoke callback(user_message, group_id)
    when the bot is mentioned.
    """
    if _is_mock_mode():
        print("[Listener] Mock mode: reading from stdin. Format: group_id::message")
        print("[Listener] Example: oc_test123::分析一下美联储最新会议纪要")
        print("[Listener] Ctrl+C to stop.")
        while True:
            try:
                line = await asyncio.to_thread(sys.stdin.readline)
            except KeyboardInterrupt:
                print("\n[Listener] Stopped.")
                return

            if not line:
                await asyncio.sleep(0.05)
                continue

            line = line.strip()
            if not line:
                continue

            if "::" not in line:
                print("[Listener] Invalid format. Use: group_id::message")
                continue

            group_id, user_message = line.split("::", 1)
            print(f"[Listener] Received: {user_message!r} from group {group_id}")
            await callback(user_message, group_id)
        return

    _ensure_larkagentx_path()

    from app.api.auth import LarkAuth
    from app.api.lark_client import LarkClient

    cookie = os.getenv("FEISHU_COOKIE", "").strip()
    if not cookie:
        raise ValueError("FEISHU_COOKIE is not set")

    auth = LarkAuth(cookie)
    client = LarkClient(auth)

    async def message_handler(
        user_name: str,
        user_id: str,
        content: str,
        is_group_chat: bool,
        group_name: str | None,
        chat_id: str,
    ) -> None:
        del user_name, user_id, group_name

        if not is_group_chat:
            return
        if not content or not _is_bot_mention(content):
            return

        clean = _clean_message(content)
        if not clean:
            return

        print(f"[Listener] Triggered: msg={clean!r}, group={chat_id}")
        try:
            await callback(clean, str(chat_id))
        except BaseException as exc:
            print(f"[Listener] Callback error: {exc!r}")
            raise

    await client.connect_websocket(message_handler)


if __name__ == "__main__":
    async def _callback(msg: str, gid: str) -> None:
        print(f"Callback triggered: msg={msg!r}, group={gid}")

    asyncio.run(start_listener(_callback))
