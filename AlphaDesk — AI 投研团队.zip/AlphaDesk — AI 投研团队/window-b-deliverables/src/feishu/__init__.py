"""Window B Feishu package scaffold."""
