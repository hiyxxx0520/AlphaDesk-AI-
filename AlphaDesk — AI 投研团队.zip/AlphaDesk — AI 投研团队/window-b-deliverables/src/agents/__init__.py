"""Shared agent types for Window B standalone usage."""

from src.agents.types import AgentResponse, RoleType, TagType

__all__ = ["AgentResponse", "RoleType", "TagType"]
