# Window B Deliverables

This folder mirrors the `window-a-deliverables` packaging style for Window B.

Included:
- `pyproject.toml`
- `requirements.txt`
- `config/settings.py`
- `src/feishu/` scaffold
- `tests/` scaffold

Current status:
- The main repository does not yet contain `src/feishu/` implementation files.
- This folder is prepared as the dedicated delivery package for Window B.
- Detailed spec remains in `docs/windows/WINDOW-B-feishu.md`.
