import asyncio
import io
import os
import sys
from pathlib import Path


PROJECT_ROOT = Path(__file__).resolve().parents[1]
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))


def test_send_to_group_mock() -> None:
    os.environ["FEISHU_MOCK"] = "true"

    from src.feishu.sender import send_to_group

    result = asyncio.run(
        send_to_group(
            group_id="oc_test123",
            message="[ALERT] mock send",
            identity="macro_analyst",
        )
    )
    assert result is True


def test_clean_message() -> None:
    from src.feishu.listener import _clean_message

    assert _clean_message("@AlphaDesk 分析 美联储") == "分析 美联储"


def test_listener_mock_once() -> None:
    os.environ["FEISHU_MOCK"] = "true"

    from src.feishu.listener import start_listener

    events: list[tuple[str, str]] = []

    async def callback(msg: str, gid: str) -> None:
        events.append((msg, gid))
        raise KeyboardInterrupt

    original_stdin = sys.stdin
    sys.stdin = io.StringIO("oc_test123::分析美联储\n")
    try:
        try:
            asyncio.run(start_listener(callback))
        except KeyboardInterrupt:
            pass
    finally:
        sys.stdin = original_stdin

    assert events == [("分析美联储", "oc_test123")]
