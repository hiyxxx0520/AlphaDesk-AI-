# AlphaDesk — 飞书 AI 校园挑战赛参赛项目总纲

> **本文档用途**：供 Claude Code 读取后，全面理解项目背景、技术方案与执行计划，并直接进入开发阶段。
> **最后更新**：2026-04-15

---

## 1. 比赛信息

| 项目 | 内容 |
|------|------|
| 比赛名称 | 飞书 AI 校园挑战赛 |
| 主办方 | 字节跳动·飞书 |
| 参赛赛道 | **开放创新赛道**（用 Agent + 飞书，构建 AI 助手） |
| 报名截止 | 2026-04-17 23:59（待确认，务必尽快提交） |
| 入围公布 | 2026-04-22 |
| 复赛 | 2026-05-06 |
| 决赛答辩 | 2026-05-14 |
| 参赛规模 | 1-5 人 / 队（我们目前 2 人） |
| 提交内容 | Demo / 项目 / 产品 / 设计作品 + 展示视频 + GitHub/产品页面 |
| 评分维度 | 创新性、实用价值、技术实现、用户体验 |

---

## 2. 团队能力画像

| 成员 | 核心能力 |
|------|----------|
| 成员A（我） | 金融工程硕士，AI 工具深度使用者，Prompt Engineering，前端/全栈开发能力（偏 vibe coding），熟悉 Claude Code / Cursor 等 AI 编程工具 |
| 成员B（队友） | 待补充（预留位） |

**团队整体优势**：
- 金融/量化专业背景（衍生品市场竞赛获奖、国家奖学金）
- AI 工具使用 + Prompt Engineering 能力强
- 具备前端/全栈开发能力
- 对 Harness Engineering 等前沿概念有研究

**团队限制**：
- 编程基础不算深厚，依赖 AI 辅助编程
- 时间极其紧张（距报名截止仅 ~2 天）
- 需要快速 MVP，不追求完美代码

---

## 3. 项目方案：AlphaDesk — AI 投研团队

### 3.1 核心创意（一句话）

在一个飞书群里部署 4 个不同角色的 AI Agent，它们会**自主监控市场、互相辩论、协作产出投研报告**——用户打开群聊，看到的不是一个机器人回答问题，而是一整个"投研团队"在自主运转。

### 3.2 为什么这个方案有竞争力

1. **视觉冲击力极强**：评委打开飞书群，看到 4 个 AI 角色自主争论市场走势，每个角色有自己的观点和分析框架，这个画面本身就是 demo
2. **只有飞书能做**：多个 Agent 在同一个群里互相 @、引用、辩论——这是飞书群聊的独特能力，普通 AI 对话窗口无法实现
3. **"自主触发"而非"被动问答"**：Agent 自己监控到市场异动就主动开始讨论，用户可以旁观也可以随时参与
4. **金融专业壁垒**：CS 学生做不出有说服力的宏观分析逻辑、风险计算框架。金融工程背景是不可替代的护城河
5. **全平台联动**：对话 → 飞书文档（策略报告） → 多维表格（风险矩阵） → 日历（评审会议），展示飞书生态深度整合

### 3.3 四个 Agent 角色设计

| 角色 | 英文名 | 职责 | 分析框架 | 性格特征 |
|------|--------|------|----------|----------|
| 宏观分析师 | Macro Analyst | 监控宏观数据、央行动态、地缘政治 | 自上而下（Top-down） | 谨慎、数据驱动、关注系统性风险 |
| 行业研究员 | Sector Analyst | 行业深度分析、个股研究、估值比较 | 自下而上（Bottom-up） | 善于反驳、关注被忽视的细节 |
| 风控官 | Risk Manager | 计算组合风险敞口、压力测试、止损建议 | 量化风控（VaR、回撤分析） | 保守、总是先看风险 |
| 首席策略师 | Chief Strategist | 综合各方观点、做出最终策略建议 | 多因子综合 | 决断力强、善于调和分歧 |

### 3.4 典型工作流（Demo 演示链路）

```
触发事件（如：美联储发布会议纪要）
    |
    v
[Macro Analyst] 在飞书群发出警报：
  "Fed minutes 显示鹰派信号，10Y 收益率冲击 4.8%，利率敏感资产全面承压。
   @Sector @Risk 请关注。"
    |
    v
[Sector Analyst] 回复（带有不同观点）：
  "不同意一刀切的判断。科技股 P/E 压缩已经在 Q1 充分定价，
   真正的风险集中在 REITs 和公用事业。建议关注 $VNQ 和 $XLU。"
    |
    v
[Risk Manager] 跑数据后回复：
  "跑完组合风险检查——当前组合利率敏感度 34%。
   若收益率突破 5.0%，预估回撤 -8.2%。
   建议将 $TLT 仓位减半。风险矩阵已同步到多维表格。"
    |
    v
[Chief Strategist] 综合拍板：
  "综合各方观点。同意 SA 对 REITs 的判断和 RM 的久期风控建议。
   行动方案：1) 减仓 $TLT 50%  2) 转向短久期信用债  3) 买入 REIT 看跌期权对冲。
   完整策略报告已生成到飞书文档。"
    |
    v
[自动输出]
  |-- 飞书文档：策略备忘录（自动生成）
  |-- 多维表格：风险矩阵（实时更新）
  |-- 日历：团队评审会议（自动创建）
  +-- 告警机器人：阈值触发器（已设置）
```

---

## 4. 技术架构（基于开源项目魔改）

### 4.1 核心原则

**不从零开发，用开源积木拼装，最大化复用，核心工作量放在 Prompt 设计和金融逻辑上。**

### 4.2 技术栈总览

```
Layer 1: Multi-Agent Engine
  - Framework: CrewAI (Python)
  - 4 Agents with role-specific prompts
  - Process: Sequential + Hierarchical
  - Tools: AKShare / yfinance (market data)

Layer 2: Feishu Connector
  - Base: cv-cat/LarkAgentX (Python)
  - WebSocket message listener
  - Multi-identity message sender
  - Function calling support

Layer 3: Feishu Output Integration
  - larksuite/lark-openapi-mcp (Official MCP)
  - Auto-generate Feishu Docs (strategy memo)
  - Update Base tables (risk matrix)
  - Create calendar events (review meetings)

Layer 4: Data Sources
  - AKShare (A-shares, CN macro data)
  - yfinance (US stocks, global markets)
  - NewsAPI or RSS (financial news triggers)

LLM Backend (choose one):
  - 豆包/Doubao (火山引擎, 字节系, 比赛可能加分)
  - DeepSeek (国产模型, 性价比高)
  - Qwen/通义千问 (阿里系)
  - Claude/GPT (效果最好但海外模型, 按需选择)
```

### 4.3 关键 GitHub 仓库

| 仓库 | 用途 | 语言 | 关键说明 |
|------|------|------|----------|
| `crewAIInc/crewAI` | 多 Agent 编排框架 | Python | 角色扮演式 Agent 协作，有现成的 financial analysis 示例 |
| `cv-cat/LarkAgentX` | 飞书 Bot 框架 | Python | 逆向飞书 WebSocket，无需官方机器人配置，Cookie 认证即可用 |
| `larksuite/lark-openapi-mcp` | 飞书官方 MCP | Node.js | 官方出品，Agent 可调用飞书全量 API（文档、表格、日历等） |
| `larksuite/cli` | 飞书官方 CLI | Node.js | 200+ 命令，22 个 AI Agent Skills，MIT 协议 |
| `botextractai/ai-crewai-multi-agent` | CrewAI 金融分析示例 | Python | SEC 报告分析，可直接参考 Agent 定义和 Task 设计 |
| `Vigneshmaradiya/ai-agent-comparison` | CrewAI/AutoGen 金融对比 | Python | 同一个股票分析任务在 3 个框架上的实现 |

### 4.4 备选方案

如果 LarkAgentX 的逆向方案不稳定，备选路线：
- **飞书开放平台自建应用** + 飞书官方 Bot SDK（`larksuite/oapi-sdk-python`）
- **OpenClaw + 飞书插件**（2026 年最火的开源 AI Agent 平台，飞书有官方插件）

---

## 5. 开发计划（48 小时冲刺）

### Phase 1: 基础搭建（Day 1 上午，~4h）

**目标**：跑通飞书消息收发 + CrewAI 本地运行

- [ ] Fork 并配置 LarkAgentX，获取飞书 Cookie/Token，确认消息收发正常
- [ ] 安装 CrewAI，基于 financial analysis 示例跑通 4 Agent 本地对话
- [ ] 确认 LLM backend 可用（推荐先用 DeepSeek API）
- [ ] 安装 AKShare，测试基本行情数据获取

### Phase 2: 核心拼装（Day 1 下午 + Day 2 上午，~8h）

**目标**：CrewAI 输出 -> 飞书群消息

- [ ] 设计并调试 4 个 Agent 的 system prompt（最核心的工作，见 Section 6）
- [ ] 编写 Orchestrator 模块：CrewAI 每个 Agent 输出以不同身份发到飞书群
- [ ] 实现触发机制：用户 @机器人 + 关键词 -> 启动 Crew 分析流程
- [ ] 接入 AKShare 作为 CrewAI 的 Tool
- [ ] 飞书消息支持富文本卡片格式

### Phase 3: 增值功能 + Demo（Day 2 下午，~4h）

**目标**：完善输出层 + 录制 Demo

- [ ] （可选）接入 Lark MCP，自动生成飞书文档 / 更新多维表格
- [ ] （可选）简单"自主触发"逻辑（定时检查市场异动）
- [ ] 准备 Demo 演示脚本，录制展示视频
- [ ] 撰写项目说明（README + 报名材料）
- [ ] 提交报名

### 优先级排序

**P0 必须完成（MVP）**：
1. 4 个 Agent 能在飞书群里以不同身份发言
2. 用户 @机器人 能触发一轮完整的投研讨论
3. 对话内容有真实的金融分析深度

**P1 锦上添花**：
4. 飞书文档自动生成
5. 多维表格风险矩阵
6. 自主触发（定时任务）
7. 飞书卡片消息美化

---

## 6. Agent Prompt 设计指南

> 这是整个项目最核心的部分。Prompt 质量直接决定 Demo 说服力。

### 6.1 通用规则

- 所有 Agent 使用英文输出（金融术语更自然），可考虑中英混合
- 每个 Agent 回复控制在 3-5 句话（群聊节奏感）
- Agent 之间必须有观点碰撞，不能全部附和
- 回复要包含具体数据和标的（如 "$TLT"、"-8.2% drawdown"）
- 使用标签开头增加辨识度：[ALERT]、[DISAGREE]、[RISK]、[ACTION]

### 6.2 各角色 Prompt 框架

#### Macro Analyst

```
Role: You are a senior macro analyst on an investment research team.
Framework: Top-down analysis. You monitor central bank policies, yield curves,
  inflation data, geopolitical events, and cross-asset correlations.
Personality: Cautious, data-driven, focused on systemic risks.
Communication style:
  - Start with the key macro signal/event
  - Cite specific data points (yield levels, rate probabilities, CPI numbers)
  - Flag which asset classes are most affected
  - Tag other team members when their input is needed (@Sector, @Risk)
  - Keep responses to 3-5 sentences max
  - Use [ALERT] tag for breaking developments
```

#### Sector Analyst

```
Role: You are a sector specialist and equity research analyst.
Framework: Bottom-up analysis. You focus on industry dynamics, company fundamentals,
  relative valuations, and sector rotation patterns.
Personality: Contrarian, detail-oriented, often challenges the consensus view.
Communication style:
  - Often DISAGREE with the macro view to provide alternative perspectives
  - Cite specific tickers, P/E ratios, sector ETFs
  - Distinguish between what is already priced in vs. genuine new risk
  - Use [DISAGREE] or [COUNTER] tags when challenging other analysts
  - Keep responses to 3-5 sentences max
```

#### Risk Manager

```
Role: You are the portfolio risk manager.
Framework: Quantitative risk analysis - VaR, duration sensitivity, drawdown estimation,
  correlation analysis, stress testing.
Personality: Conservative, always highlights downside first, speaks in numbers.
Communication style:
  - Run specific calculations (portfolio sensitivity %, estimated drawdown)
  - Provide concrete hedging recommendations with position sizes
  - Reference risk metrics (VaR, Sharpe degradation, max drawdown)
  - Use [RISK] tag for risk alerts
  - Always end with a specific, actionable recommendation
  - Keep responses to 3-5 sentences max
```

#### Chief Strategist

```
Role: You are the Chief Investment Strategist who synthesizes all perspectives.
Framework: Multi-factor synthesis. You weigh macro, fundamental, and risk inputs
  to form a coherent actionable strategy.
Personality: Decisive, diplomatic, good at resolving disagreements.
Communication style:
  - Acknowledge each team member's key point
  - Clearly state where you agree/disagree and why
  - Produce a numbered action plan (3-5 specific steps)
  - Mention that a full report is being generated to Feishu Docs
  - Use [ACTION] tag for final decisions
  - Keep responses to 4-6 sentences max
```

### 6.3 对话编排逻辑（伪代码）

```python
def run_analysis(trigger_event):
    # Step 1: Macro Analyst first analyzes the event
    macro_response = macro_agent.analyze(trigger_event)
    send_to_feishu(macro_response, identity="Macro Analyst")

    # Step 2: Sector Analyst provides alternative perspective
    sector_response = sector_agent.respond(
        context=macro_response,
        instruction="Challenge or refine the macro view with sector-specific insights"
    )
    send_to_feishu(sector_response, identity="Sector Analyst")

    # Step 3: Risk Manager runs risk assessment
    risk_response = risk_agent.assess(
        context=[macro_response, sector_response],
        portfolio_data=get_portfolio_data()
    )
    send_to_feishu(risk_response, identity="Risk Manager")

    # Step 4: Chief Strategist synthesizes all views
    strategy_response = strategist_agent.synthesize(
        context=[macro_response, sector_response, risk_response]
    )
    send_to_feishu(strategy_response, identity="Chief Strategist")

    # Step 5: Auto-generate outputs (P2 priority)
    generate_feishu_doc(strategy_response)
    update_risk_table(risk_response)
```

---

## 7. 项目命名与包装

| 项目 | 内容 |
|------|------|
| 项目名 | **AlphaDesk** |
| Tagline | "Your AI Investment Research Team, Live in Feishu" |
| 中文副标题 | AI 投研团队，就在飞书群里 |
| 核心卖点 | 多 Agent 自主协作 x 金融专业深度 x 飞书生态深度整合 |

---

## 8. Demo 演示脚本（答辩用）

### 开场（30秒）
"传统的 AI 助手是你问它答。AlphaDesk 不一样——我们在飞书群里部署了一整个 AI 投研团队。4 个专业角色，各有观点，自主讨论，实时协作。"

### 现场演示（2-3分钟）
1. 打开飞书群，@AlphaDesk 说 "分析一下美联储最新会议纪要对市场的影响"
2. 等待 4 个 Agent 依次发言——观众看到它们在辩论
3. 打开自动生成的飞书文档（策略报告）
4. 打开多维表格（风险矩阵数据已更新）
5. 展示日历（评审会议已自动创建）

### 总结（30秒）
"AlphaDesk 的核心不是一个更聪明的 chatbot，而是一个有组织结构的 AI 团队。每个成员有自己的分析框架和立场，通过辩论产出比单一 AI 更全面、更可靠的投资建议。这是只有飞书的群聊生态才能实现的场景。"

---

## 9. 风险与应对

| 风险 | 概率 | 应对方案 |
|------|------|----------|
| LarkAgentX 逆向方案不稳定 | 中 | 转用飞书开放平台官方 Bot SDK 或 OpenClaw 飞书插件 |
| LLM API 延迟导致对话体验差 | 中 | 使用更快的模型（如 DeepSeek V3），或预生成部分对话内容做 Demo |
| 时间不够完成全部功能 | 高 | 优先保证 MVP（4 Agent 群聊对话），其余功能在复赛前补齐 |
| 金融数据源不稳定 | 低 | AKShare 备选 yfinance，或预缓存一组示范数据 |
| 比赛要求使用特定飞书产品 | 低 | 确认赛道规则后灵活调整技术选型 |

---

## 10. 给 Claude Code 的执行指令

当你（Claude Code）读完本文档后，请按以下优先级执行：

### 立即执行（P0）

1. **创建项目目录结构**，初始化 Python 项目（pyproject.toml / requirements.txt）
2. **安装核心依赖**：crewai, akshare, requests
3. **实现 CrewAI 四 Agent 本地对话**：基于 Section 6 的 Prompt 框架，创建 4 个 Agent + 对应 Task + Crew，在终端跑通一轮完整对话
4. **编写 AKShare 数据获取工具**：封装成 CrewAI Tool，Agent 可以调用获取实时行情

### 紧接执行（P1）

5. **实现飞书消息发送**：参考 LarkAgentX 或飞书 Bot SDK，实现向指定飞书群发送消息
6. **拼装 Orchestrator**：将 CrewAI 对话结果按角色分别发到飞书群
7. **实现触发机制**：飞书群里 @机器人 + 关键词 -> 启动分析流程

### 有余力则做（P2）

8. 接入 Lark MCP 实现飞书文档自动生成
9. 多维表格写入
10. 飞书卡片消息美化
11. 定时自主触发逻辑

### 注意事项

- **LLM 选择**：优先尝试 DeepSeek API（便宜、快、效果好），如果比赛要求用字节系产品则切换到豆包
- **代码风格**：不追求完美，MVP 优先，能跑就行
- **网络环境**：开发环境在日本（东京），可能需要配置代理访问某些服务
- **飞书账号**：需要用户自己在飞书开放平台创建应用并提供 App ID 和 App Secret

---

## 附录 A：相关资源链接

- CrewAI 官方文档：https://docs.crewai.com
- CrewAI GitHub：https://github.com/crewAIInc/crewAI
- LarkAgentX：https://github.com/cv-cat/LarkAgentX
- 飞书官方 MCP：https://github.com/larksuite/lark-openapi-mcp
- 飞书 CLI：https://github.com/larksuite/cli
- 飞书开放平台：https://open.feishu.cn
- AKShare 文档：https://akshare.akfamily.xyz
- CrewAI 金融分析示例：https://github.com/botextractai/ai-crewai-multi-agent
- CrewAI + Telegram 股票分析参考：https://finecwg.github.io/computer-science/stock-analysis/

## 附录 B：飞书生态关键概念

- **飞书 aily**：飞书的智能伙伴平台，Bot 形态常驻联系人列表
- **飞书妙搭**：自然语言驱动的业务系统生成器
- **飞书多维表格**：类 Airtable 的数据库+表格产品，支持 AI 搭建
- **Lark CLI**：飞书官方命令行工具，200+ 命令，为 AI Agent 设计
- **OpenClaw**：2026 年最火的开源 AI Agent 平台，飞书是其首选接入平台
- **飞书开放平台**：飞书的开发者平台，提供 API、Bot、Webhook 等能力
