import json
import os
import sys
from pathlib import Path


PROJECT_ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(PROJECT_ROOT))


def print_section(title: str) -> None:
    print(f"\n=== {title} ===")


def pretty_print(label: str, raw: str) -> None:
    print(f"{label}:")
    try:
        print(json.dumps(json.loads(raw), ensure_ascii=False, indent=2))
    except json.JSONDecodeError:
        print(raw)


def main() -> None:
    from src.tools import get_all_tools
    from src.tools.akshare_tool import AKShareTool
    from src.tools.yfinance_tool import YFinanceTool

    print_section("Registered Tools")
    tools = get_all_tools()
    print(f"Count: {len(tools)}")
    for tool in tools:
        print(f"- {tool.name}")

    print_section("Live Mode")
    os.environ["DEMO_MODE"] = "false"
    pretty_print("AKShare get_price:000001", AKShareTool()._run("get_price:000001"))
    pretty_print("AKShare get_forex:USDCNY", AKShareTool()._run("get_forex:USDCNY"))
    pretty_print("yfinance get_price:AAPL", YFinanceTool()._run("get_price:AAPL"))
    pretty_print("yfinance get_info:AAPL", YFinanceTool()._run("get_info:AAPL"))

    print_section("Demo Mode")
    os.environ["DEMO_MODE"] = "true"
    pretty_print("AKShare get_price:000001", AKShareTool()._run("get_price:000001"))
    pretty_print("AKShare get_index:000300", AKShareTool()._run("get_index:000300"))
    pretty_print("yfinance get_price:SPY", YFinanceTool()._run("get_price:SPY"))


if __name__ == "__main__":
    main()
