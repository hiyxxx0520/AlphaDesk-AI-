# AlphaDesk — AI 投研团队

> 飞书群里的 4 个 AI Agent，自主监控市场、互相辩论、协作产出投研报告。

## 角色设计

| 角色 | 标签 | 分析框架 |
|------|------|----------|
| 🔭 Macro Analyst | `[ALERT]` | Top-down，央行/收益率/地缘 |
| 💡 Sector Analyst | `[DISAGREE]` | Bottom-up，挑战共识观点 |
| ⚠️ Risk Manager | `[RISK]` | VaR / 回撤 / 压力测试 |
| 🎯 Chief Strategist | `[ACTION]` | 多因子综合，最终决策 |

## 快速启动

### 1. 安装依赖

```bash
pip install -r requirements.txt
```

### 2. 配置环境变量

复制 `.env.example` 为 `.env`，填写真实凭证：

```bash
cp .env.example .env
```

关键字段：

| 变量 | 说明 |
|------|------|
| `DEEPSEEK_API_KEY` | DeepSeek API Key（必须） |
| `FEISHU_COOKIE` | 飞书 Cookie，LarkAgentX 认证 |
| `FEISHU_GROUP_ID` | 目标飞书群 ID |
| `FEISHU_MOCK` | `true` = 只打印到终端，不发飞书 |
| `DEMO_MODE` | `true` = 使用缓存数据，不请求真实行情 |

### 3. Demo 演示（无需真实 API Key）

```bash
python3 scripts/demo.py
```

自定义触发事件：

```bash
python3 scripts/demo.py "分析美联储最新加息决议对A股的影响"
```

**Demo 模式输出示例：**

```
🔭 [Macro Analyst]
[ALERT] Trigger captured: Fed released hawkish FOMC minutes...

💡 [Sector Analyst]
[DISAGREE] Broad de-risking may be overdone...

⚠️ [Risk Manager]
[RISK] Portfolio duration sensitivity is high...

🎯 [Chief Strategist]
[ACTION] Team synthesis complete. Action plan: 1) Reduce $TLT 50%...
```

### 4. 真实飞书群模式

配置好 `.env` 后启动监听：

```bash
python3 main.py
```

在飞书群 @AlphaDesk 触发分析，4 个 Agent 会依次发言。

### 5. Mock 模式（stdin 触发）

```bash
FEISHU_MOCK=true python3 main.py
# 然后输入：
7629645459308645336::分析美联储最新议息会议
```

## 目录结构

```
src/
├── agents/          # CrewAI 4-Agent 核心（crew.py 入口）
├── feishu/          # 飞书消息收发（LarkAgentX）
├── tools/           # 金融数据工具（AKShare + yFinance）
├── outputs/         # 飞书文档/表格输出（P1 功能）
└── orchestrator.py  # 主编排逻辑
main.py              # 生产入口
scripts/demo.py      # Demo 演示脚本
config/settings.py   # 环境变量读取
```

## 环境变量完整清单

```bash
# LLM
DEEPSEEK_API_KEY=sk-xxxx
LLM_BASE_URL=https://api.deepseek.com
LLM_MODEL=deepseek-chat

# 飞书基础
FEISHU_COOKIE=session=xxx; ...
FEISHU_GROUP_ID=oc_xxxxxxxxxx

# 飞书 P1 功能（可选）
FEISHU_APP_ID=cli_xxxxx
FEISHU_APP_SECRET=xxxxx
FEISHU_BITABLE_APP_TOKEN=xxxxx
FEISHU_BITABLE_TABLE_ID=xxxxx
FEISHU_DOC_FOLDER_TOKEN=xxxxx

# 模式控制
FEISHU_MOCK=false        # true = 只打印，不发真实消息
DEMO_MODE=false          # true = 金融工具用缓存数据
ENABLE_DOC=false         # true = 开启飞书文档/表格写入
MESSAGE_DELAY=1.5        # Agent 发言间隔（秒）
```

## 降级策略

| 条件 | 行为 |
|------|------|
| `DEEPSEEK_API_KEY` 为空或 placeholder | `run_analysis()` 自动使用 mock 响应 |
| `FEISHU_MOCK=true` | 消息打印到终端，不调用 LarkAgentX |
| `FEISHU_APP_ID` 未设置 | 文档/表格写入本地 `data/` 目录 |
| LarkAgentX 不可用 | `send_to_group()` 返回 `False`，不崩溃 |
